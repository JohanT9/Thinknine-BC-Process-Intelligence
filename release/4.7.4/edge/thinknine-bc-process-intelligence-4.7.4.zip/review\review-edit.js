(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.T9ReviewEdit = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  const DEFAULT_DELAY = 750;

  function createSession(taskId, field, value, revision = null) {
    return {
      taskId,
      field,
      originalValue: value ?? "",
      draftValue: value ?? "",
      sourceRevision: revision
    };
  }

  function update(session, value) {
    return { ...session, draftValue: value };
  }

  function result(session) {
    return {
      taskId: session.taskId,
      field: session.field,
      value: session.draftValue,
      changed: session.draftValue !== session.originalValue
    };
  }

  function hasRevisionConflict(session, currentRevision) {
    return session?.sourceRevision !== null &&
      session?.sourceRevision !== currentRevision;
  }

  function commandFromKey(event, editing) {
    if (editing && event.key === "Escape") return "cancel";
    if (editing && event.key === "Enter") {
      const multiline = event.target?.tagName?.toLowerCase() === "textarea";
      if (multiline && !event.ctrlKey && !event.metaKey) return null;
      return "commit";
    }
    if (!editing && event.key === "Enter") return "start";
    return null;
  }

  function bind(container, options) {
    function context(target) {
      const card = target?.closest?.("[data-review-task-id]");
      if (!card) return null;
      const control = target.closest?.("[data-edit-field]") || null;
      return { card, control, taskId: card.dataset.reviewTaskId };
    }

    function start(details) {
      const control = details.control ||
        details.card.querySelector?.('[data-edit-field="instruction"]');
      if (!control) return;
      options.start({
        ...details,
        control,
        field: control.dataset.editField
      });
    }

    function handleDoubleClick(event) {
      const details = context(event.target);
      if (!details?.control) return;
      start(details);
    }

    function handleKeydown(event) {
      const details = context(event.target);
      if (!details) return;
      const editing = details.control?.dataset.editing === "true";
      const command = commandFromKey(event, editing);
      if (!command || (!details.control && event.target !== details.card)) return;
      event.preventDefault();
      if (command === "start") start(details);
      else if (command === "commit") options.commit(details);
      else options.cancel(details);
    }

    function handleInput(event) {
      const details = context(event.target);
      if (details?.control?.dataset.editing === "true") {
        options.update({ ...details, value: details.control.value });
      }
    }

    function handleFocusOut(event) {
      const details = context(event.target);
      if (details?.control?.dataset.editing === "true") {
        if (event.relatedTarget?.closest?.("[data-instruction-format-toolbar]") &&
            event.relatedTarget.closest("[data-review-task-id]") === details.card) {
          return;
        }
        options.commit(details);
      }
    }

    container.addEventListener("dblclick", handleDoubleClick);
    container.addEventListener("keydown", handleKeydown);
    container.addEventListener("input", handleInput);
    container.addEventListener("focusout", handleFocusOut);
    return () => {
      container.removeEventListener("dblclick", handleDoubleClick);
      container.removeEventListener("keydown", handleKeydown);
      container.removeEventListener("input", handleInput);
      container.removeEventListener("focusout", handleFocusOut);
    };
  }

  function createAutoSave(save, options = {}) {
    const delay = options.delay ?? DEFAULT_DELAY;
    const setTimer = options.setTimer || setTimeout;
    const clearTimer = options.clearTimer || clearTimeout;
    let timer = null;

    async function run() {
      timer = null;
      try {
        await save();
      } catch (error) {
        options.onError?.(error);
      }
    }

    return {
      schedule() {
        if (timer !== null) clearTimer(timer);
        timer = setTimer(run, delay);
      },
      flush() {
        if (timer === null) return Promise.resolve();
        clearTimer(timer);
        return run();
      },
      cancel() {
        if (timer !== null) clearTimer(timer);
        timer = null;
      },
      pending() {
        return timer !== null;
      }
    };
  }

  function createSaveQueue(save) {
    let chain = Promise.resolve();
    let lastOperation = Promise.resolve();
    let latestRevision = 0;
    let pendingCount = 0;

    function enqueue(payload) {
      const revision = ++latestRevision;
      pendingCount += 1;
      const operation = chain.then(() => save(payload, revision));
      chain = operation.catch(() => undefined);
      lastOperation = operation.finally(() => {
        pendingCount -= 1;
      });
      return lastOperation.then(value => ({
        value,
        revision,
        latest: revision === latestRevision
      }));
    }

    return {
      enqueue,
      flush() {
        return lastOperation.then(() => undefined);
      },
      pending() {
        return pendingCount > 0;
      },
      revision() {
        return latestRevision;
      }
    };
  }

  function createPersistenceCoordinator(options) {
    async function flush() {
      await options.autoSave.flush();
      await options.saveQueue.flush();
    }

    async function saveExplicitly(saveOptions) {
      await flush();
      await options.save(saveOptions);
      await options.saveQueue.flush();
    }

    return { flush, saveExplicitly };
  }

  function isCurrentSave(details) {
    return Boolean(
      details.latest &&
      details.currentSession &&
      details.currentReview === details.savedReview &&
      details.currentReview?.updatedAt === details.savedUpdatedAt
    );
  }

  return {
    DEFAULT_DELAY,
    bind,
    commandFromKey,
    createAutoSave,
    createSaveQueue,
    createPersistenceCoordinator,
    isCurrentSave,
    hasRevisionConflict,
    createSession,
    result,
    update
  };
});
