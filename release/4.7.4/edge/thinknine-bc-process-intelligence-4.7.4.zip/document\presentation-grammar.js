(function (root, factory) {
  const semantic = typeof module === "object" && module.exports
    ? require("./semantic-document")
    : root.T9DocumentModel;
  const api = factory(semantic);
  if (typeof module === "object" && module.exports) module.exports = api;
  root.T9PresentationGrammar = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function (semantic) {
  const GRAMMAR_VERSION = "1.1.0";
  const cache = new WeakMap();

  function clone(value) {
    return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
  }

  function run(text, role = "text") {
    return {
      text: String(text ?? ""),
      role,
      ...(role === "value" ? { bold: true } : {}),
      ...(["shortcut", "identifier"].includes(role) ? { monospace: true } : {})
    };
  }

  function quoted(value) {
    return { ...run(String(value ?? "").replace(/^['"“]|['"”]$/gu, ""),
      "interface"), italic: true };
  }

  function sentence(...runs) {
    const filtered = runs.flat().filter(value => value?.text !== "");
    return { text: filtered.map(value => value.text).join(""), runs: filtered };
  }

  function legacyRuns(value) {
    const source = String(value ?? "");
    const result = [];
    const pattern = /(__([\s\S]+?)__|\*\*([\s\S]+?)\*\*|`([^`]+?)`|["“]([^"”]+?)["”])/g;
    let cursor = 0;
    let match;
    while ((match = pattern.exec(source))) {
      if (match.index > cursor) result.push(run(source.slice(cursor, match.index)));
      if (match[2] !== undefined) result.push(run(match[2], "value"));
      else if (match[3] !== undefined) result.push(quoted(match[3]));
      else if (match[4] !== undefined) result.push(run(match[4], technicalRole(match[4])));
      else result.push(quoted(match[5]));
      cursor = match.index + match[0].length;
    }
    if (cursor < source.length || !result.length) result.push(run(source.slice(cursor)));
    return result.filter(value => value.text !== "");
  }

  function technicalRole(value) {
    return /^(?:ctrl|cmd|alt|shift|enter|esc|escape|tab|delete|backspace|f\d+)(?:\b|\+)/iu
      .test(String(value)) ? "shortcut" : "identifier";
  }

  function presentationFor(action, fallbackText, documentLanguage = "sv-SE") {
    const english = documentLanguage === "en-US";
    const words = english
      ? { choose: "Choose ", enter: "Enter ", in: " in ", andChoose: ", and choose ",
        searchText: "search text", enable: "Enable ", disable: "Disable " }
      : { choose: "Välj ", enter: "Ange ", in: " i ", andChoose: " och välj ",
        searchText: "söktext", enable: "Aktivera ", disable: "Inaktivera " };
    const actionType = action?.actionType || action?.taskType;
    const value = String(action?.selectedValue ?? action?.instructionValue ??
      action?.value ?? "").trim();
    const field = String(action?.targetField ?? action?.fieldCaption ?? "").trim();
    const selectLabels = {
      SelectCustomer: field || (english ? "Customer" : "Kund"),
      SelectItem: field || (english ? "Item No." : "Artikelnummer"),
      SelectVendor: field || (english ? "Vendor" : "Leverantör"),
      SelectLocation: field || (english ? "Location" : "Lagerställe"),
      SelectDimension: field || "Dimension"
    };
    if (actionType === "SearchAndOpenPage") {
      const search = String(action?.searchCaption || (english ? "Search" : "Sök")).trim();
      const searchField = String(action?.searchFieldCaption || field ||
        (english ? "Tell me what you want to do." :
          "Berätta vad du vill göra.")).trim();
      const result = String(action?.resultCaption || action?.selectedCaption ||
        action?.pageCaption || "").trim();
      if (result) {
        return sentence(run(words.choose, "action"), quoted(search),
          run(english ? ", enter " : ", ange "),
          value ? run(value, "value") : run(words.searchText),
          run(words.in), quoted(searchField), run(words.andChoose),
          quoted(result), run("."));
      }
    }
    if (selectLabels[actionType] && value) {
      return sentence(run(words.choose, "action"), quoted(selectLabels[actionType]),
        run(" "), run(value, "value"), run("."));
    }
    if (["EnterQuantity", "EnterItemNumber", "SelectDate", "EnterFieldValue"].includes(
      actionType) && value && field) {
      return sentence(run(words.enter, "action"), run(value, "value"),
        run(words.in), quoted(field), run("."));
    }
    if (["SelectOption", "SelectLookupValue"].includes(actionType) &&
        value) {
      return field
        ? sentence(run(words.choose, "action"), quoted(field), run(" "),
          run(value, "value"), run("."))
        : sentence(run(words.choose, "action"), run(value, "value"), run("."));
    }
    if (["EnableCheckbox", "DisableCheckbox"].includes(actionType) &&
        field) {
      return sentence(run(actionType === "EnableCheckbox"
        ? words.enable : words.disable, "action"), quoted(field), run("."));
    }
    if (actionType === "RunActionPath" && Array.isArray(action?.actionPath) &&
        action.actionPath.length && action.actionPath.every(item =>
          typeof item === "string" && item.trim())) {
      const pathRuns = [];
      action.actionPath.forEach((caption, index) => {
        if (index) pathRuns.push(run(" → "));
        pathRuns.push(quoted(caption.trim()));
      });
      return sentence(run(words.choose, "action"), pathRuns, run("."));
    }
    const runs = legacyRuns(fallbackText);
    return sentence(runs);
  }

  function processBlock(block, action, documentLanguage) {
    const result = clone(block);
    const blockAction = result.kind === "step"
      ? result.semanticAction || result.interaction || action
      : action;
    if (result.kind === "paragraph" && typeof result.text === "string") {
      if (result.preserveUserText || result.provenance === "user-edited") {
        // Preserve literal authored text even when no rich-text runs were stored.
        if (!Array.isArray(result.presentationRuns)) {
          result.presentationRuns = [run(result.text)];
        }
      } else {
        const presentation = presentationFor(blockAction, result.text,
          documentLanguage);
        result.text = presentation.text;
        result.presentationRuns = presentation.runs;
      }
    }
    if (Array.isArray(result.blocks)) {
      result.blocks = result.blocks.map(child => processBlock(
        child,
        result.kind === "step" && child.kind === "paragraph"
          ? child.preserveUserText ? null : blockAction
          : action,
        documentLanguage
      ));
    }
    if (Array.isArray(result.items)) {
      result.items = result.items.map(item => ({ ...item,
        blocks: Array.isArray(item.blocks)
          ? item.blocks.map(child => processBlock(child, blockAction,
            documentLanguage)) : item.blocks }));
    }
    if (Array.isArray(result.rows)) {
      result.rows = result.rows.map(row => ({ ...row,
        cells: Array.isArray(row.cells) ? row.cells.map(cell => ({ ...cell,
          blocks: Array.isArray(cell.blocks)
            ? cell.blocks.map(child => processBlock(child, blockAction,
              documentLanguage)) : cell.blocks
        })) : row.cells }));
    }
    return result;
  }

  function process(document) {
    const cacheable = document && typeof document === "object" &&
      Object.isFrozen(document);
    if (cacheable && cache.has(document)) return cache.get(document);
    const normalized = semantic.normalize(document);
    const documentLanguage = normalized.metadata?.documentLanguage === "en-US"
      ? "en-US" : "sv-SE";
    const result = semantic.normalize({
      ...clone(normalized),
      sections: normalized.sections.map(section => ({ ...clone(section),
        blocks: section.blocks.map(block => processBlock(block, null,
          documentLanguage)) })),
      provenance: {
        ...clone(normalized.provenance),
        transformations: [...new Set([
          ...(normalized.provenance?.transformations || []),
          "presentation-grammar"
        ])],
        presentationGrammarVersion: GRAMMAR_VERSION
      }
    });
    if (cacheable) cache.set(document, result);
    return result;
  }

  return { GRAMMAR_VERSION, legacyRuns, presentationFor, process };
});
