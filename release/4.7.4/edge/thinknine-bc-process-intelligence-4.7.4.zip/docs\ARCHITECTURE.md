# BC Process Studio Architecture 4.7

## Canonical Business Central process taxonomy

The reusable Business Central classification catalog is defined by
`engine/process-taxonomy-schema.js`, `engine/process-taxonomy.js`, and the
representative BC seed. It is independent of individual recordings and of the
renderer-neutral Process Model. Recordings contain only stable taxonomy entity
references. See [BUSINESS_CENTRAL_PROCESS_TAXONOMY.md](BUSINESS_CENTRAL_PROCESS_TAXONOMY.md).

## Language ownership

`src/engine/language-registry.js` owns active locales, aliases, short codes, native names, and UI/document capabilities. Recording, Canonical Recording, Review, the Knowledge Base, and UI selectors consume this registry rather than maintaining separate language allowlists. Translation catalogs and language-specific presentation rules remain in their presentation layers.

## UI design-system boundary

`src/ui/design-system.css` is the single source of truth for shared visual
semantics: colour, typography, spacing, sizing, controls, focus, status,
responsive behaviour and forced-colour support. HTML pages own structure and
page-specific layout; UI JavaScript owns orchestration and interaction. The
design system contains no recording, review, documentation or export rules.

The production build copies the source stylesheet into `dist`; generated files
remain build output. Existing embedded CSS is transitional layout code and must
not become a second shared theme. The complete component and migration contract
is documented in `docs/UI_DESIGN_SYSTEM.md`.

## Observed Business Central URL context

`src/engine/business-central-url-context.js` owns the deterministic parsing of
the active recording tab's Business Central URL. At session start the recorder
reads only observable URL facts: the environment path segment and the decoded
`company` query parameter. It stores those values in the session settings and
updates the separate environment and company fields used by the dashboard and
filename variables `{environment}` and `{company}`. Non-Business Central URLs,
malformed URLs and missing values fall back
without blocking capture. This is capture context, not page or entity semantic
classification.

Single-step screenshot repair is initiated by the Review UI and validated by
the Step Editor domain service. Existing or newly captured recording media is
referenced through a sparse Step Override. A supplementary capture never creates
or rewrites a raw or Canonical Event; it remains derived repair evidence with
explicit provenance and Review history.

## Product identity boundary

`src/engine/product-brand.js` is the canonical source for current product and module terminology. UI and export surfaces use **BC Process Studio**. Stable technical identifiers—including the npm package name, extension listing identity, storage keys, `T9*` namespaces, schema versions, file-compatible release names and built-in theme ID `thinknine`—remain unchanged to preserve existing installations and data.

## Bug Reporting UX orchestration

The extension popup presents Process Documentation and Bug Reporting as separate user intents. Both use the same recorder and Canonical Recording. Finishing Bug Reporting invokes shared interpretation and Bug Report services, persists a local draft, and opens the Technical Report Workspace; UI code does not recreate evidence or report semantics.

While recording, the popup consumes a derived, read-only live-status contract
from the recorder background service. It reports capture progress, connection,
Business Central context and bounded warnings without reading or changing raw
events. The contract deliberately omits entered values and URL query data;
Canonical Recording remains the evidence source of truth.

The active top-level Business Central document also hosts an isolated recording
indicator in a closed Shadow DOM. It consumes the same live-status contract and
never interprets or persists events. Indicator interactions are excluded before
the recorder's pointer/click pipeline, and its Stop action delegates to the
existing popup naming flow. Child frames and non-recording tabs never render it.
The background capture boundary temporarily hides the indicator for two paint
frames before taking a screenshot and restores it afterwards, so recorder UI
never becomes part of documentation evidence.

BC Knowledge Base preserves `recordingPurpose` as routing metadata. Opening a
`bug-report` recording resolves its stable Bug Report identity and opens
Technical Report Workspace; it must never enter process Review, Semantic
Document or Word export. Documentation recordings continue through the process
pipeline. Historical sessions without a purpose retain the documentation
fallback.

## Current architecture baseline

This section is authoritative. Later version-labelled sections retain useful
decision history; they are not parallel current architectures.

Packaging is outside the domain/document pipeline. One `src` tree produces the
Manifest V3 runtime in `dist`; Edge Add-ons or enterprise browser policy owns
production installation and updates. Customer evidence/state remains in
`chrome.storage.local` under the stable extension identity. There is currently
no native Windows component and therefore no justified installer. See
[Packaging and update architecture](PACKAGING_AND_UPDATE_ARCHITECTURE.md).

Canonical Recording also supports an additive explicit `recordingPurpose` and
remains the single evidence source for both documentation and Bug Reporting.
Bug Reports are renderer-neutral derived models with independent identity,
schema, lifecycle and persistence; they reference Canonical Events, derived
Steps and screenshot assets rather than copying evidence. See
[Bug Reporting architecture](BUG_REPORTING_ARCHITECTURE.md) and
[Bug Report model](BUG_REPORT_MODEL.md).

During Bug Recording only, a browser-side BC Error Detector observes supported
modal error semantics. The background composition root serializes a separate
local diagnostic-evidence record, appends a traceable Canonical `bc-error`
event, and attaches a dedicated screenshot. The detector does not normalize,
group or semantically interpret events; the diagnostic extractor does not
mutate Canonical Recording. Bug Reports reference this evidence. See
[BC error capture](BC_ERROR_CAPTURE.md) and
[BC diagnostic evidence](BC_DIAGNOSTIC_EVIDENCE.md).

Raw AL call stacks flow into a browser-neutral, synchronous, versioned parser
and Technical Diagnostics projector. These derived Bug Reporting services do
not mutate evidence, participate in ordinary documentation, depend on UI or
renderers, or call external services. Results can be recomputed from raw data.

Bug Report Generator is the single Technical Report projection owner. A
dedicated Workspace and text adapters consume that projection; neither rebuilds
report semantics. Human edits persist to Bug Report while captured evidence and
derived diagnostics retain separate provenance.

```text
CAPTURE
Browser events → Raw Event Persistence → Canonical Recording

INTERPRETATION
Canonical Recording → Page Identification → Event Normalization
  → Step Grouping → Semantic Interpretation → generated steps

DOCUMENTATION
Generated + manual Review state → Resolved Steps → hierarchy
  → Review Projector → Semantic Document → Semantic Interaction compatibility
  → Language Excellence → Presentation Grammar → Screenshot Selection
  → profile/theme → Document Planner → Document Plan

OUTPUT
Document Plan → Document Workspace
Document Plan + prepared media → Word Adapter

FUTURE PROCESS DOMAIN (not the document production path)
Resolved Steps → Process Model → future Process Renderers
```

Raw Event Persistence is authoritative intake. **Canonical Recording** is the
canonical captured-evidence model: immutable event and screenshot identity from
which interpretation can be regenerated. **Semantic Document** is the canonical
renderer-neutral document representation: document meaning after Review
resolution and before planning/rendering. “Canonical” therefore names authority
inside two different domains; neither model replaces the other.

`dashboard.js` is the browser Composition Root. A non-DOM shell invokes the same
interpretation through `session-interpretation-pipeline.js`. Domain modules do
not import dashboard code. Workspace and Word consume one Document Plan and do
not independently interpret recording evidence, wording, screenshots, or layout.

## Current legacy compatibility path

Pre-canonical recordings and Reviews remain readable through explicitly bounded
adapters: legacy event projections, `sourceEventNos`/`legacyEventNos`, legacy task
consolidation, old screenshot references, marker parsing, and the quarantined old
exporter. Compatibility metadata must not masquerade as Canonical Event IDs.
New recordings use canonical IDs end to end. No compatibility path may mutate
Canonical Recording, Semantic Document, or the current Document Plan.

## Historical architecture record

The remaining milestone sections below document how the current boundaries were
introduced. Where their diagrams conflict with the baseline above, the baseline
is current and the older diagram is historical context.

## Canonical domains and evidence safety

Raw Event Persistence is the authoritative intake source for new captures.
Canonical Recording is its immutable captured-evidence projection and the
permanent source consumed by derived layers.
Semantic Document is the canonical renderer-neutral document representation.
The two “canonical” contracts belong to different domains; document projection
never replaces recording evidence.

The capture boundary writes Raw Event Persistence before identification,
Canonical Recording, and legacy events/screenshots. Serialized persistence
queues expose pending/failure
diagnostics. Stop performs bounded settlement and validates Event counts,
ordering, identity, and screenshot references before the immutable finish write.
Derived interpretation, Review, Workspace, and Word remain read-only consumers.

## BC UI Identification boundary

After durable Raw Event intake, `bc-ui-identification.js` exclusively owns
technical-first Page, Control, Action, and Entity identity. Dashboard consumes
structured identities through compatibility adapters and contains no primary BC
caption-recognition rules. Caption fallback is language-grouped inside the
engine and is used only when stronger technical evidence is absent.

`page-identity.js` defines the shared page-field contract used by Canonical
Recording and BC UI Identification. Legacy `pageId` remains opaque and
backward-compatible. Only a positive numeric value corroborated by the captured
Business Central `page` URL parameter becomes `pageObjectId`. Captions and
semantic entities never become object IDs, and table identity is never inferred
from page identity. The recorder captures the source URL value and caption but
assigns no entity, page type, table ID, or record type.

`page-identification-engine.js` is the single page-classification owner. It
validates and resolves optional Knowledge Pack `pageDefinitions`, applies exact
ID, scoped caption, runtime, and generic precedence, and returns explicit
provenance/confidence. Equal-priority semantic conflicts produce diagnostics and
safe fallback. BC UI Identification delegates to it; Entity Memory consumes its
resolved entity before legacy caption fallback; Screenshot Intelligence only
transports resolved context. See
[Page Identification Engine](PAGE_IDENTIFICATION_ENGINE.md).

Unknown standard, AppSource, tenant, customer, Aptean, frame, and control-add-in
pages follow the same pipeline. They receive a stable non-semantic page context
and remain eligible for recording, screenshots, Review generation, document
generation, Workspace use, and export. Historical recordings are enriched in
memory and their persisted Canonical Recording is not rewritten.

Localized aliases and explicit customer overrides remain Knowledge Pack data.
The Page Identification Engine is their only resolver. Entity Memory owns only
continuity, the dashboard only invokes pack loading, and semantic `pagePatterns`
remain scoped to action/field interpretation rather than page classification.

### Final page-identification integration review

The release review verified the complete path from observable recorder facts to
Canonical Recording, in-memory identification, normalization, Step Groups,
Semantic Actions, Review, Semantic Document, Document Plan, Workspace, and Word.
Renderers consume the validated plan and neither classify pages nor reconstruct
page semantics. Screenshot Intelligence uses stable page identity for continuity
only. `src` remains authoritative; `dist` is regenerated by `scripts/build.js`.

Representative standard, localized, unknown, legacy, Aptean-fixture, customer,
and frame/control-add-in flows completed without losing raw evidence or exposing
sensitive query/business values in identification diagnostics. The verified
configured registry remains deliberately small; semantic-only warehouse,
manufacturing, and Aptean rules are not misrepresented as verified page records.

## Event Normalization boundary

Event Normalization 2.5.0 is the sole owner of browser-mechanic coalescing. It
consumes durable Raw Events and BC UI Identification, emits immutable normalized
interactions, and never groups them into Steps. React/MUI focus comparison is
capture evidence; only normalization may classify a verified difference as a
`value-change`.

Step Grouping 1.8.0 attaches additive result verification, observed before/after
state, and recorder-owned interaction identity to capture packets.
Observed navigation, dialog, value, selection, toggle, and error outcomes flow
to Semantic Actions and Review without modifying Canonical Recording or
overwriting the consultant's expected-result text.

The recorder creates an opaque `interactionId` at the observable start of a
pointer, keyboard, or field interaction. Raw Event Persistence stores it
unchanged. Canonical Recording preserves it as additive schema-v1 metadata,
Event Normalization propagates it, and Step Grouping uses matching IDs as an
explicit boundary. Semantic rules consume the completed group and never create
or reinterpret recorder interaction identity.

Capture Packet 1.6.0 treats a matching recorder ID as authoritative across
framework noise and unknown supporting mechanics. It records plural interaction
events, result events, screenshot evidence roles, and a result-oriented preferred
screenshot. It also carries directly observed state facts and exact differences
without inferring process meaning. Semantic Actions and Review tasks preserve
the packet metadata;
renderers do not reconstruct it.

Capture Packet Integrity 1.2.0 is the single validation owner for packet
identity, reference ownership, evidence ordering, screenshot roles, result
traceability, observed-state ownership, state coverage, and completeness. It
detects and reports invalid derived
relationships without repairing or rewriting Canonical evidence. Runtime and CI
consume the same immutable diagnostic contract.

Verified interaction results project through Review into a system-derived
Semantic Document callout owned by the corresponding Step. Document Workspace
and Word consume the same planned component. The editable document-level
expected result remains human-owned and is never replaced by observed evidence.

### React and control-add-in capture reliability

The recorder installs delegated capture-phase listeners at `window` level in
every supported frame. Interactive targets are resolved through `composedPath()`
and bounded ancestry. Installing before the application at the earliest DOM
capture boundary prevents handlers above `document` from hiding observable
interactions; open Shadow DOM remains supported. No React internals, Fiber data,
MUI class identities, page-world patches, polling, or per-control listeners are
used.

Recording state is persisted by the background worker and observed through
`chrome.storage.onChanged` by every injected frame. This closes the lifecycle
gap where `tabs.sendMessage` updated only the top frame after a control-add-in
frame had already initialized. Frames mounted later still initialize through
`T9_GET_STATE`; periodic pings recover state and inventory after worker restart.

Editable controls retain their initial observable value on `focusin`. On
`focusout`, a `field-change` Raw Event is emitted only when the value changed and
no equivalent native `input` or `change` commit was already emitted. Event
Normalization remains the owner of the `value-change` classification.

Capture Surface Mode 1.0 is the single owner of the recorder's technical
surface mode. It deterministically selects `standard-bc` or `control-addin`
from observable frame paths, automation, React-root, Material UI, and
control-add-in markers. A nested frame alone is insufficient, so normal Business Central
frames retain the standard path. The enhanced mode expands delegated target
resolution for observable ARIA roles such as `switch`, `treeitem`, `slider`,
and `combobox`; it does not inspect React Fiber, patch the page world, poll the
DOM, or classify business meaning.

Each accepted Raw Event may carry additive `captureSurface` evidence with the
selected mode, deterministic version, confidence, and observable activation
signals. Version 1.1 also recognizes standard ARIA add-in surfaces (`switch`,
`treeitem`, `slider`, `combobox`, and presentation wrappers) when proprietary
React/MUI markers are absent. Native controls remain on the standard BC path.
mode version, matched signals, and deterministic confidence. Canonical
Recording preserves this evidence in the original raw event. Semantic
classification remains downstream, and absence of mode evidence remains fully
backward compatible.

Capture diagnostics are opt-in and bounded. They retain event/control shape,
frame/document identity, acceptance state, rejection reason, and source-event
identity, but never entered values or URL query strings. Supported inherited
`about:blank` documents use the registered origin fallback. Cross-origin frames
outside the Business Central host patterns are explicitly unsupported until a
verified narrow host permission is added. Closed Shadow DOM remains opaque by
browser design.

The `webNavigation` permission is used only to enumerate the browser's actual
frame tree and compare it with content-script pings. It grants no additional
host access. URLs are reduced to origin and path before diagnostics are stored.

## Documentation hierarchy

Resolved Steps may be organized into exactly Section → Subtask → Step. Hierarchy
owns logical presentation; Planner owns styling, and evidence order remains intact.

## Notes and visual annotations

Notes attach prose to documentation identities. Annotations attach normalized
geometry to screenshot assets. They remain separate Review models and resolve
through the shared Semantic Document and media-composition pipeline.

## Manual documentation boundary

Manual Steps are Review-owned documentation state with no fabricated evidence.
They are anchor-resolved alongside generated steps before Structure and Content
Overrides, then enter the shared document pipeline as ordinary Resolved Steps.

## Resolved structure

Generated steps remain unchanged. Review Structure Overrides apply Hide, Merge,
and Split before sparse content overrides. The resulting resolved structure is
the sole input to document analysis, planning, Workspace, and Word.

## Step Editing boundary

The Review layer owns sparse Step Overrides. Derived Step plus Step Override
resolves before document projection. Evidence layers remain immutable, and
Workspace and Word consume the same Resolved Step.

## Screenshot Selection Engine

```text
Step Group + canonical asset metadata + Review intent + profile
  -> Screenshot Selection Engine -> selected reference
  -> Presentation Document -> Planner -> Workspace / Word
```

`screenshot-selection-engine.js` is the single automatic choice owner.
`screenshot-intelligence.js` adapts Semantic Document blocks and legacy metadata,
then applies the returned reference; it no longer owns ranking policy. Planner
and both renderers receive the same already-selected Semantic Document.

## Event â†’ Step Grouping

```text
Canonical Evidence -> Identification -> Normalization -> Step Grouping
  -> Semantic Interaction Rules -> existing document pipeline
```

`event-step-grouping.js` is the single owner of candidate documentation-step
boundaries for normalized input. Its versioned, immutable state machine groups
same-control committed edits and only verifiable lookup round-trips. Strong
action, navigation, page, unrelated-control, and ambiguity boundaries remain
small and safe. Semantic rules receive Step Groups through a dedicated adapter;
legacy task consolidation remains a compatibility fallback.

Each Step Group now also exposes an additive capture-packet contract. The packet
separates the user's primary interaction from its verified immediate result and
screenshot evidence. Duplicate same-action mechanics are consumed here, while
unknown mechanics without documentable meaning remain diagnostic support rather
than generating placeholder steps. The packet can nominate the result-bearing
capture event, but Screenshot Intelligence remains the sole owner of final
document screenshot selection.

## Event Normalization

```text
Canonical Raw Event -> BC UI Identification -> Event Normalization
  -> Semantic Interaction Rules -> existing document pipeline
```

`event-normalization.js` owns business-neutral UI mechanics. It derives an
immutable recording projection and never writes Canonical Recording. Consecutive
input/change/focusout evidence for one control and committed value is mechanically
coalesced at the final source position; all contributing canonical IDs remain.
The dashboard transports normalized mechanics alongside legacy fields, allowing
Semantic Interaction Rules to prefer the stable contract while retaining old
recording fallbacks.

## BC UI Identification

```text
Canonical Raw Event -> BC UI Identification -> compatible event projection
  -> Semantic Interaction Rules -> existing document pipeline
```

`bc-ui-identification.js` deterministically derives immutable, versioned UI
structure from captured browser evidence. The result is stored beside—not
inside—the canonical event's unchanged `raw` payload and references the stable
canonical event ID. Identification describes page, control, action, observable
hierarchy, frame context, evidence, and qualitative confidence.

The content recorder performs only target-local and eight-ancestor-bounded
capture. Captions never become technical identities. Existing dashboard caption
fallbacks may read identification, but interpretation and language remain owned
by downstream layers.

## Raw Event Persistence

```text
Browser interaction -> capture normalization -> canonical raw persistence
  -> Canonical Recording -> semantic interpretation -> document pipeline
```

`raw-event-persistence.js` is the sole owner of canonical write serialization.
Every mutation reloads the last durable recording, applies one append,
association, or finalization operation, and saves it before the next operation.
The canonical write precedes the temporary legacy event projection. Stop blocks
new acceptance, drains accepted writes and screenshot associations, then writes
the completion boundary.

Capture frames assign a UUID to each source delivery plus frame-local sequence.
Canonical insertion sequence is authoritative ordering; timestamps and source
sequences remain evidence rather than sorting keys. Exact source IDs reject
message redelivery, while semantically repeated interactions remain distinct.

Review and every document layer operate on projections. Their mutations never
flow back into Canonical Recording. See `RAW_EVENT_PERSISTENCE.md` for the full
storage, recovery, privacy, and immutability contracts.

## Presentation Grammar 4.6 R3.2

```text
Review → Projector → Semantic Document → Semantic Interaction Rules
  → Language Excellence → Presentation Grammar → Screenshot Intelligence
  → Document Profile → Theme → Planner → Workspace / Word
```

`presentation-grammar.js` is the sole owner of renderer-neutral visual text
grammar. It consumes the Language Excellence document and returns an immutable
Semantic Document containing natural paragraph text plus explicit presentation
runs. Actions, interface elements, values, shortcuts and identifiers have
distinct roles; no renderer parses semantic action intent.
Interface-role runs contain the observed label without surrounding quotation
marks and use italic emphasis consistently in Review Studio, Document Workspace
and Word. Legacy generated labels in `**markers**` or quotation marks are
normalized to that same presentation in memory without migrating recordings.

Planner transports the runs unchanged. Document Workspace maps the contracts to
semantic DOM elements, while the Word adapter maps the same contracts to DOCX
text properties. Both retain the plain concatenated sentence for accessibility.
Review Studio renders the same generated runs before projection. When a
consultant explicitly formats an instruction, Review owns that reversible
override as structured `instructionRuns`; the projector alone translates it to
Semantic Document `presentationRuns`. This keeps font and emphasis choices out
of raw recording events and avoids renderer-specific HTML in the domain model.
The layer does not change workflow structure, screenshots, source references,
planning or persistence. Legacy marker parsing is a compatibility boundary only
and remains outside both renderers.

## Review Workspace Refinement 4.6 R4

R4 changes presentation and interaction composition only. Review domain
commands, selection, history, annotation persistence, Semantic Document and the
export pipeline remain unchanged. The toolbar continues to derive command state
from `review-toolbar.js`; HTML disclosure changes do not create a second state
owner.

Primary commands remain in the toolbar's first focus sequence. Secondary
commands retain their stable IDs and command attributes inside a native
`details` disclosure. The toolbar binding owns arrow navigation and Escape focus
restoration. Native Tab order remains intact.

Editor refinement uses existing controls and listeners. `scrollIntoView` with
nearest alignment followed by focus with `preventScroll` avoids viewport jumps.
Annotation geometry uses native progressive disclosure and introduces no new
editor state. Responsive and accessibility behavior is CSS-only, adding no DOM
observers, polling, layout measurement or render pass.

## Semantic Interaction Rules Engine 4.6 R3

```text
Review → Review Projector → Semantic Document → Semantic Interaction Rules
  → Language Excellence → Screenshot Intelligence → Document Profile → Theme
  → Document Planner → Components / Diagnostics → Document Workspace / Word
```

`semantic-interaction-engine.js` is the single owner of interaction
consolidation. The Review adapter delegates its compatibility view to this same
engine; it contains no rules. The ordered registry evaluates specific rules
before generic rules. Equal-priority conflicts and unsafe inference fall back to
the original sequence.

Each result is an immutable Semantic Action containing stable action and source
identities, ordered event references, selected value, target field, every
screenshot and annotation reference, raw interactions and preserved future
metadata. The projector carries interaction semantics without interpreting
them. The engine never consumes Review directly, mutates input, evaluates image
quality or applies profile-specific language.

Focus-only transitions and selection prompts without a resulting value are
non-visible Semantic Actions stored in the workflow section's suppressed trace.
Deterministic focus/record/result sequences become one lookup action. This keeps
technical navigation available for diagnostics without creating document steps.

`screenshot-capture-policy.js` independently decides capture eligibility before
the recorder queue. Non-empty input/change events receive the dedicated
`field-input` category. That category cannot reuse a nearby action capture or a
capture for another field, while repeated events for the same field may share
one image. Focusout remains non-capturing.

Instruction text carries renderer-neutral semantic markers: `__value__` denotes
a manually entered value and `**label**` denotes a UI label. `text-format.js` is
the single parser and emits plain accessible text plus bold run metadata.
Document Workspace and Word consume those runs; Review and Semantic Document do
not store HTML, DOCX runs or renderer-specific formatting.

An immutable projected document revision is processed once and cached by object
identity. Language Excellence consumes the semantic-action document. Screenshot
Intelligence remains the sole image-selection owner. Both Document Workspace
and Word consume the same downstream Document Plan.

## Screenshot Intelligence 4.6 R2

```text
Review → Review Projector → Semantic Document → Language Excellence
  → Screenshot Intelligence → Document Profile → Theme → Document Planner
  → Components / Diagnostics → Document Workspace / Word Adapter
```

`screenshot-intelligence.js` solely owns candidate normalization, explainable
evaluation and selection. It consumes no Review, DOM, image bytes, canvas,
Planner or renderer structure. The composition root derives immutable candidate
metadata from existing recorder events and screenshot paths. Selection returns a
new Semantic Document plus disposable explanations; neither is persisted to
Review.

Review Projector carries stable source-event references and the minimal optional
`screenshotSelection: { mode: "manual", screenshotRef }` contract into step
semantics. A valid manual reference is authoritative. Annotated candidates are
protected, and multiple annotated candidates retain the previous presentation
instead of orphaning annotations.

Review Projector also owns the final semantic-noise boundary for document
content. An automatically generated `Unclassified` task whose only wording is
the empty fallback "Utför uppgiften." (or its English equivalent) is omitted
when it has no screenshot or consultant-owned content. The Review and its source
references remain unchanged. Approved, edited, manual, annotated, commented or
screenshot-backed tasks are always preserved.

The same immutable visibility policy is shared with BC Review Studio so its
cards, numbering, progress and document output cannot disagree. Visibility is
a derived view only; it never deletes tasks from Review storage.

Language output is the selection input. The selected document is the only
document passed to Planner, so Document Workspace and Word cannot select
independently. Results are cached only for immutable document and candidate
identities and per profile; mutable inputs always run again.

## Language Excellence 4.6 R1

The current pipeline extends this baseline with one renderer-neutral document
localization stage:

```text
Review → Review Projector → Semantic Document → Language Excellence
  → Document Language → Presentation Grammar → Screenshot Intelligence
  → Document Planner → Document Workspace / Word
```

`document-language.js` is the single owner of Swedish/English document
localization. Review stores only the selected `documentLanguage`; known generated
system text is localized in memory while observed Business Central labels and
consultant-authored text are preserved. Document Workspace and Word consume the
same localized Document Plan. Older Reviews default to Swedish without a schema
migration.

The recorder naming dialog supplies an explicit `documentLanguage` only when a
session is finalized. Canonical Recording stores it as additive compatibility
metadata before the immutable completion boundary; raw events are untouched.
Review projection and Bug Report projection consume that same value. BC
Knowledge Base indexes the code as metadata and owns only filtering and display,
not localization. Historical Bug Reports remain English; historical process
documents remain Swedish.

```text
Review → Review Projector → Semantic Document
  → Language Excellence → Document Profile → Theme → Document Planner
  → Components / Diagnostics → Document Workspace / Word Adapter
```

`language-excellence.js` is the single owner of deterministic writing rules.
It accepts only Semantic Document plus the selected profile's language contract
and returns a new normalized, recursively immutable Semantic Document. It never
imports Review, UI, Planner or a renderer. Unknown document fields and unknown
future block kinds pass through unchanged.

The composition pipeline retains the projector result as an immutable source and
passes only the language-enhanced copy downstream. Document Profile owns tone
configuration, while the language layer owns wording. Theme and Planner remain
presentation-only. Document Workspace and Word continue consuming the same
validated Document Plan, so no wording logic leaks into either renderer.

Processing is cached by immutable source-document identity and profile tone.
A changed Review produces a new projected document and therefore a new cache
entry; repeated planning for an unchanged revision and profile reuses the same
frozen result. No language output is persisted into Review or screenshot storage.

## Historical architecture baseline: version 4.4

Den semantiska dokumentmodellen är en fristående gräns för dokumentinnehåll:

```text
Review (oförändrad)
  ↓ Review Document Projector
Semantic Document Model
  + Document Theme System
  ↓ Document Planner
Document Plan
  ↓ formatadapter + förberedda medier
Word / framtida PDF-renderare
```

RC2 lägger till en ren och deterministisk projektor som ensam översätter Review
till modellen. Projektorn skapar provenance och separat diagnostik men äger
aldrig Review-objekt eller bilddata. Modell och projektor saknar beroenden till
DOCX, DOM, CSS och canvas. Sedan RC5 är denna projektion den enda aktiva vägen
från Review till Word-export.

RC3 introducerar en parallell, innehållsoberoende källa för dokumentutseende.
Temasystemet definierar endast värden och tokenrelationer. Det inspekterar inte
Review eller Semantic Document och beräknar inte placering, sidbrytning eller
renderarformat. Den framtida Document Planner blir första konsumenten av både
semantisk modell och ett upplöst tema.

RC4 implementerar denna kombination. Planner är en ren transformation och den
enda producenten av Document Plans. Planen innehåller stabila referenser till
semantiskt innehåll samt renderer-neutrala beslut om flöde, komponenter,
gruppering, synlighet och sidintention. Framtida adaptrar är konsumenter och får
inte återskapa planeringslogik.

RC5 gör kedjan till produktionsväg för Word. Word-adaptern tar endast emot den
validerade, immutabla planen och förberedda bildbytes. Dashboarden är composition
root men fattar inga layoutbeslut. DOCX-objekt och Word-enheter förekommer endast
i adaptern; Review-persistence och skärmbildslagring är oförändrade.

RC6 gör planens komponenter explicita och återanvändbara. `document-components`
äger normalisering och immutabilitet, `document-component-registry` äger de
inbyggda definitionerna och utökningspunkten, och
`document-component-validation` äger kontraktskontrollerna. Planner är fortsatt
den enda producenten av komponentinstanser och Document Plans. Komponenterna är
renderer-neutrala och innehåller inga DOCX-, XML-, DOM-, PDF- eller Word-enheter.

RC7 lägger en separat analysgren bredvid rendering:

```text
Semantic Document + Document Plan
  ↓ Document Quality Rules
Immutable diagnostics + quality summary
```

Kvalitetslagret läser endast dokumentet och planen. Findings lagras inte i någon
av dem och påverkar varken Planner eller renderer. Regelregistret kan utökas utan
ändring av exekveringsmotorn, och ett regelundantag isoleras så att exporten
fortsätter.

RC8 aktiverar professionell presentation inom samma ansvarsfördelning:

```text
Semantic Document (vad dokumentet säger)
  + Resolved Theme (visuella tokens)
  ↓ Document Planner
Document Plan (hierarki, gruppering, presentation och flödesintention)
  ↓ Word Adapter
DOCX (formatmappning, ingen planering)
```

Planner äger bildbetoning, sekvensgruppering, metadataformat, sektionsövergångar,
callout-roller, whitespace-intention och `keep`-relationer. Alla visuella värden
kommer från det upplösta temat. Word-adaptern mappar endast dessa beslut till
`docx`-objekt och Word-enheter. Review Projector och Semantic Document ändrades
inte, och kvalitetsdiagnostiken är fortsatt rådgivande och skrivskyddad.

RC9 verifierar ansvaren som produktionsgränser. Ingen renderer läser Review,
Planner skapar inga Word-objekt, projektorn planerar inte presentation och
kvalitetslagret ändrar varken semantik eller plan. Den äldre exportören är
fortsatt karantäniserad för kompatibilitet och laddas inte av dashboarden.

## Document Workspace 4.5

v4.5 introducerar två samordnade arbetsytor över samma dokumentkälla:

```text
Review Workspace (redigering)
  ↓ Review
Review Projector → Semantic Document + Theme → Document Planner → Document Plan
                                                        ↙             ↘
                                      Document Workspace Renderer   Word Adapter
```

Document-level manual content is owned by Review.
`documentFields.expectedResult` is an additive, reversible autosaved override;
an empty value means that the shared default text is used. Review Projector is
the only component that projects the value into the Semantic Document expected
result section. Document Workspace and Word then consume the same Document Plan.
During normalization, historical Reviews may still supply the legacy top-level
`expectedResult` field.

`document-workspace.js` är en ren, deterministisk planrenderer. Den skapar en
immutable och renderer-neutral workspace-modell och känner inte till Review,
DOM eller Word. `document-workspace-view.js` är den tunna DOM-adaptern som
materialiserar modellen. `workspace-controller.js` äger endast aktiv arbetsyta
och synkroniseringsrevision.

Composition root keeps one frozen document-pipeline value for the active Review
revision, profile and expected-result configuration. Review Studio first uses
that value for its document-consistent instruction presentation; opening
Document Workspace reuses the same value instead of repeating projection,
language, presentation, screenshot selection, planning and diagnostics. A
Review invalidation changes the revision key, and closing the Review releases
the retained value. The active profile variant also reuses the pipeline's
already resolved Semantic Document, screenshot selections and plan.
The first Review render stops at the shared frozen presentation-document
boundary. It does not run screenshot selection, theme resolution, planning or
quality diagnostics merely to display formatted instruction text. The full
pipeline accepts that prepared presentation and continues from it when Document
Workspace or Word is requested.
Document Workspace also keeps unannotated screenshots as their existing data
URLs. Only annotated screenshots enter canvas composition. Byte-array conversion
remains isolated to Word export, which avoids a decode/re-encode cycle for every
image while opening the browser workspace.

Dashboarden är fortsatt composition root. Den kör samma pipeline och samma
annotationskomposition för Document Workspace och Word, men äger ingen
dokumentstruktur. Stabilt identifierade plansektioner gör att DOM-adaptern kan
ersätta ändrade avsnitt och återanvända oförändrade avsnitt.

UX2 lägger ett fristående presentationslager efter DOM-adaptern:

```text
Document Plan → pure workspace renderer → stable semantic DOM
                                           ↓
                         Document Workspace Experience
                         (zoom, mode, page, adaptive presentation)
```

`document-workspace-experience.js` äger immutable vypreferenser, zoom- och
navigeringsberäkningar samt lokal preferensserialisering. Dashboarden applicerar
resultatet som CSS, sektionssynlighet och ARIA-state på befintlig DOM. Lagret
kan därför inte ändra Semantic Document, tema, planner, komponenter eller Word.
Vypreferenser använder en separat lokal nyckel och ingår aldrig i Review.

UX3 introducerar `workspace-context.js` som enda ägare av delad
navigationsposition. Kontexten innehåller endast stabila identiteter och
navigationsavsikt. Den äger ingen Review-logik, rendererlogik eller DOM.
Arbetsytorna känner inte till varandra; dashboarden binder deras identiteter vid
composition root. Kontextbyte ändrar endast fokus, markering och position i
redan renderad DOM och passerar aldrig Review Projector, Semantic Document,
Theme, Planner eller Word Adapter.

UX4 lägger en skrivskyddad advisory-projektion bredvid renderingen:

```text
Semantic Document + Document Plan + Quality Diagnostics + Workspace Context
                                ↓
                   Documentation Intelligence
                                ↓
        Qualitative Health + immutable grouped Guidance
```

`documentation-intelligence.js` återanvänder diagnostics och översätter dem till
positivt formulerad vägledning. Modulen läser aldrig Review, muterar inga indata,
blockerar aldrig export och anropar ingen renderer. Dashboarden visar modellen
med stabil ID-reconciliation och använder Workspace Context för navigation.

UX5 inför ett renderer-neutralt förväntningslager mellan Semantic Document och
presentationen:

```text
Semantic Document + Document Profile
              ↓
   cached Resolved Theme + Document Plan variant
              ↓
Documentation Intelligence + Document Workspace
```

`document-profile.js` äger schema, normalisering, register och inbyggda
profiler. En profil beskriver förväntningar men skapar eller ändrar aldrig
dokumentinnehåll. Dashboarden beräknar immutable tema-/planvarianter en gång per
dokumentrevision. Profilbyte väljer en cachad variant, så Review, Semantic
Document och komponenter regenereras inte vid bytet. Word använder fortsatt sin
oförändrade produktionspipeline.

```text
Recorder
  ↓
Noise Filter
  ↓
Context Builder
  ↓
Entity Memory
  ↓
Knowledge Pack
  ↓
Business Tasks
  ↓
Session Graph
  ↓
Confidence Engine
  ↓
Documentation Engine
```

Modulerna är browser-kompatibla IIFE-moduler och kan samtidigt importeras med CommonJS i enhetstester.

## Document Library 4.5 UX6

UX6 lägger ett separat metadataindex bredvid dokumentproduktionskedjan:

```text
Session metadata ───────────────┐
Already materialized Document  ├─→ Document Library metadata index
Health/profile/theme summaries ┘                 ↓
                                      Search/filter/cards/preview

Review → Semantic Document → Planner → Word (oförändrad och on demand)
```

`document-library.js` äger versionerad normalisering, ett förberäknat
sökindex, kombinerbara filter, sortering, profilgruppering och selection state.
Modellen är renderer-neutral, immutable och bevarar okända framtida fält.
`document-library-view.js` är en tunn DOM-adapter för kort och preview.
Dashboarden är composition root och kopplar ett biblioteksprojekt till dess
befintliga session med stabilt `projectId`/`sessionId`.

Biblioteksnyckeln i lokal extension storage innehåller metadata endast. Den får
aldrig innehålla Review, Semantic Document, Document Plan, Word-strukturer,
renderer-state eller skärmbildsbytes. Grundposter projiceras från redan laddad
sessionslista. Rikare metadata materialiseras enbart när den ordinarie Document
Workspace-pipelinen redan har körts; biblioteket initierar den aldrig.

## Batch Operations 4.5 UX7

`document-batch-operations.js` är ett renderer-neutralt kommandolager ovanpå
Document Library-metadata:

```text
Visible library IDs + modifiers → immutable multi-selection
Selected metadata + explicit fields → batch command → normalized metadata
Export intent → dashboard queue → one Review at a time → unchanged Word pipeline
```

Domänen äger urval, range/toggle/select-all, reconciliation, explicit
metadata-patch, exportplan och deleteplan. Den importerar endast
`document-library.js` och känner inte till Review, Semantic Document, Planner,
Document Plan, DOM eller Word. Dashboarden äger bekräftelse, progress,
persistence och externa effekter.

Profil- och temaassignment lagras som presentationsmetadata. Profilbyte
ogiltigförklarar den gamla rådgivande hälsosnapshoten tills ordinarie Document
Workspace senare materialiserar nya förväntningar. Batch-export laddar aldrig
en Review-samling; ett projekt hämtas, renderas och släpps innan nästa startar.

## Workflow Polish 4.5 UX8

UX8 ändrar inga domängränser. Det renodlar dashboardens interaktionsadapter:

```text
Metadata change → rebuild immutable library index → reconcile full view
Selection/focus change → patch visible card state + preview only
Filter/sort change → reuse index → reconcile bounded result DOM
```

`document-library-view.applySelection` uppdaterar endast `data-selected`, native
checkbox, roving tab stop och `aria-current`. Semantiskt kortinnehåll och noder
återanvänds. Dashboarden behåller högst 200 renderade kort men söker och väljer
fortsatt i hela metadataindexet.

Metadata-persistence använder rollback innan synlig reconciliation. Öppning av
Review sparar senaste aktivitet utan att först ersätta det fokuserade kortets
DOM, så returfokus kan bindas till samma stabila projekt-ID. Tangentbordsgenvägar
är UI-kommandon och passerar aldrig Review Projector, Semantic Document,
Documentation Intelligence, Planner eller Word-adaptern.

## Production boundary assessment 4.5 UX9

Ship review confirms the dependency direction remains intact:

```text
Review → Projector → Semantic Document → Profile/Theme → Planner → Components
                                                     ↘ Intelligence (advisory)
                                                      ↘ Document Workspace
                                                       ↘ Word Adapter

Session metadata → Document Library → Batch command plans
                                      ↘ sequential Word orchestration (one Review)
```

Document Library persistence rejects Review, semantic, plan, renderer, Word and
screenshot payloads. Batch Operations imports only the library model and emits
immutable metadata results or stable-ID plans. Dashboard remains the composition
root; it is the only layer that resolves an explicit batch export reference to
one Review and the unchanged Word pipeline.

`async-operations.js` is UI infrastructure only. It owns timeout timer cleanup
and single-flight request coalescing for popup polling, has no product-domain
dependencies and stores no state after a request settles.

## Process Model boundary (4.6)

The renderer-neutral Process Model projects after resolved Sections/Subtasks
and before presentation planning. It separates process semantics from document
organization, preserves source identity, and emits graph data plus validation
diagnostics. Current Planner, Workspace, and Word behavior remains unchanged.
See [PROCESS_MODEL.md](PROCESS_MODEL.md).

## Process Versioning boundary (4.6)

Intentional immutable Process Model snapshots live separately from Canonical
Recording, current Review/Process state, and renderer output. Semantic Diff is
derived from two snapshots or a snapshot and current model. Library integration
is bounded metadata only. See [PROCESS_VERSIONING.md](PROCESS_VERSIONING.md).

## Regeneration boundary (4.6)

Regeneration starts only from a detached Canonical Recording and calls the
existing interpretation owners once. Fresh generated state is reconciled with
authoritative consultant state before validation and atomic pointer replacement.
Review Studio renders that dry-run as an inspectable change set and requires an
explicit approval before replacement. A safety-blocked preview cannot apply.
See [REGENERATE_FROM_RECORDING.md](REGENERATE_FROM_RECORDING.md).

## Canonical semantic recording boundary (4.7)

Canonical Event and asset evidence remains the immutable technical account of
capture. A sibling `semanticInterpretation` projection references stable Event
IDs and reusable Business Central taxonomy entities. It may group many raw UI
actions into one Process Step or describe a document-state transition from one
action. Classification source, confidence, AI provenance, and superseded manual
override history remain explicit. Missing semantics is valid, and normalization
adds an empty container to historical schema-v1 recordings without modifying
stored source data. See
[CANONICAL_SEMANTIC_RECORDING.md](CANONICAL_SEMANTIC_RECORDING.md).

## Business Central process recognition boundary (4.7)

Process Recognition is a deterministic, renderer-neutral consumer of Canonical
Recording, Canonical Semantic Recording and Process Taxonomy. It extracts
document/action/transition evidence, performs partial ordered matching, and
returns explained ranked candidates without mutating capture or Review. Strong
Business Central metadata outranks caption and optional screenshot evidence.
Future AI is a complement behind this result contract and cannot override
reliable metadata. See
[BC_PROCESS_RECOGNITION_ENGINE.md](BC_PROCESS_RECOGNITION_ENGINE.md).

## Multi-level ProcessGraph boundary (4.7)

ProcessGraph presentation passes through the immutable
`document/process-graph-layout.js` contract. It assigns deterministic rows and
columns and describes connector route intent without adding layout information
to the taxonomy, semantic recording, or ProcessGraph source model. HTML and
future SVG/BPMN/Visio adapters may consume this contract independently.
The contract supports adaptive row flow and vertical top-to-bottom flow as
presentation preferences without changing canonical process order.

Node appearance is resolved separately by
`document/process-visual-grammar.js`. The contract translates canonical node
types into renderer-neutral kind, shape, tone, and localized-label intent.
Renderers implement that intent; taxonomy and recording data never store CSS or
library-specific drawing instructions.

Relationship appearance is resolved by
`document/process-route-grammar.js`. It translates canonical transition types
into line, marker, tone, and localized-label intent. Explicit conditions remain
semantic graph data; route styling remains a renderer concern.

Process phase and role grouping is projected by
`document/process-lane-model.js`. It consumes Process Model containers and
semantic role metadata and returns immutable lane membership and segments.
The projector does not reorder nodes and does not create business semantics.

`ui/process-connector-view.js` is the HTML/SVG adapter for graph relationships.
It consumes final DOM bounds plus route grammar intent and draws a noninteractive
connector layer. It does not infer transitions, alter layout, or expose SVG
details to the semantic model.

`ui/process-map-viewport.js` owns renderer viewport calculations only. It
normalizes bounded zoom values and computes fit-to-width scale without mutating
ProcessGraph or layout. Dashboard persists the user preference and requests a
fresh render so connectors are measured after scaling.

`exporters/process-svg-export.js` is the standalone SVG adapter. It consumes the
same visual grammar, route grammar, and lane projection as Review Studio but
owns deterministic export geometry independent of DOM measurements, viewport
zoom, or screen size. `process-export.js` validates and delegates to it.

`ProcessGraph` is the renderer-neutral diagram contract projected from Canonical
Recording, Process Taxonomy, and Semantic Classification. One deterministic
projection produces Business Process, Business Central Process, and User
Procedure graphs with stable cross-level child references. Higher-level nodes
retain every contributing Event ID and can expand into the lower level without
copying evidence. The existing Review Process Model remains unchanged. Diagram
adapters consume ProcessGraph and may not reconstruct semantics from raw Review
or introduce process branches. See
[MULTI_LEVEL_PROCESS_GRAPH.md](MULTI_LEVEL_PROCESS_GRAPH.md).

Process-map theme selection remains outside `ProcessGraph`.
`document/process-map-theme.js` supplies immutable named palettes to the Review
and SVG renderers, ensuring that a presentation preference never alters process
semantics, evidence, or stored recordings. See
[PROCESS_MAP_THEMES.md](PROCESS_MAP_THEMES.md).

`document/process-map-legend.js` projects the node and route grammars used by a
ProcessGraph into a renderer-neutral legend. Review and SVG adapters consume the
same projection, ensuring standalone exports explain their notation without
duplicating semantic inference. See [PROCESS_MAP_LEGEND.md](PROCESS_MAP_LEGEND.md).

Map density is an ephemeral renderer preference shared by Review and SVG
adapters. Standard and Compact modes adjust geometry and secondary presentation
only; density is intentionally excluded from `ProcessGraph`. See
[PROCESS_MAP_DENSITY.md](PROCESS_MAP_DENSITY.md).

Process-map focus mode is UI orchestration only. It expands the existing Review
renderer and preserves its active ProcessGraph, selection, viewport settings,
and connector layer. See [PROCESS_MAP_FOCUS_MODE.md](PROCESS_MAP_FOCUS_MODE.md).

`ui/process-map-search.js` provides pure normalization, matching, and cyclic
navigation helpers. Dashboard applies results to the current rendered map;
search never changes or filters ProcessGraph. See
[PROCESS_MAP_SEARCH.md](PROCESS_MAP_SEARCH.md).

`ui/process-map-minimap.js` projects the existing layout coordinates into a
compact navigation model. It references the same stable node IDs and introduces
no alternate graph or layout ownership. See
[PROCESS_MAP_MINIMAP.md](PROCESS_MAP_MINIMAP.md).

## Business Central Document Lifecycle boundary (4.7)

Document Lifecycle is configurable semantic knowledge between Process Taxonomy
and Process Recognition. Taxonomy owns document identity; Lifecycle owns
representative optional stages, alternative configuration variants, typed
document relationships, and document-state models. Recognition consumes matched
transitions as strong evidence but never treats a lifecycle as mandatory.
Renderers and ProcessGraph do not interpret lifecycle configuration. See
[BUSINESS_CENTRAL_DOCUMENT_LIFECYCLES.md](BUSINESS_CENTRAL_DOCUMENT_LIFECYCLES.md).

## Reference Diagram Dataset Pipeline boundary (4.7)

The semantic reference dataset adds traceable sources, separately licensed
assets, canonical terminology, renderer-neutral ProcessGraphs, fact-level
confidence, verification history, curation and explicit training/evaluation
partitions. It reuses the ProcessGraph and Reference Process Library rather than
introducing competing models. Customer recordings remain separate.

Pipeline stages and extension/query contracts are documented in
`REFERENCE_DIAGRAM_DATASET_PIPELINE.md`. No renderer or AI provider owns domain
meaning, and source images are never assumed redistributable.

Review Studio exposes this semantic layer through the Process Analysis adapter.
The extension background owns matching; `process-analysis-view.js` only renders
the immutable result. Manual confirmation is stored as Review metadata and does
not copy or mutate the reference dataset. See `PROCESS_ANALYSIS_UX.md`.

The Semantic Process Map projector combines the observed and reference
ProcessGraphs into Business, BC Process and User Procedure views. It projects to
the existing Process Model-compatible view contract, so Process Overview remains
the single renderer and does not infer semantics. See `SEMANTIC_PROCESS_MAP_UX.md`.

## Reference Process Library boundary (4.7)

The Reference Process Library is an immutable semantic-example catalog above
Process Taxonomy and Document Lifecycle. It contains no recording evidence or
rendering fields. Its comparison service consumes Canonical Recording plus
Semantic Classification and returns advisory similarity, matched, missing, and
unexpected steps with alternatives. It never mutates a recording or interprets
deviation as failure. Namespaced extension libraries allow future Aptean and
customer patterns without modifying the BC seed. See
[REFERENCE_PROCESS_LIBRARY.md](REFERENCE_PROCESS_LIBRARY.md).

## Application Insights enrichment boundary (4.6)

Optional external telemetry is queried by one provider through versioned query
definitions after explicit user action. It is persisted per BC error under the
Bug Report, never in Canonical Recording. The Technical Report projection joins
local and external references into a derived timeline without merging stores or
claiming causation. Authentication is Entra authorization code with PKCE; no
confidential credential or token is persisted. See
[APPLICATION_INSIGHTS_ENRICHMENT.md](APPLICATION_INSIGHTS_ENRICHMENT.md).
# Optional AI Technical Analysis

Bug Reporting can invoke a renderer-neutral Technical Analysis Provider after
explicit consent. A deterministic policy/input layer separates authoritative
capture, telemetry, diagnostics, human content, and derived AI output. UI only
orchestrates; an Entra-protected broker owns confidential credentials. AI has no
autonomous tools and cannot modify Canonical Recording or Bug Report evidence.
See `AI_TECHNICAL_ANALYSIS.md`.

Issue Package is a downstream renderer/provider-neutral projection of the same
Technical Report. Azure DevOps and GitHub adapters map that package without
owning report semantics. External systems are write-only initial destinations;
no synchronization or read-back can overwrite the Bug Report.
