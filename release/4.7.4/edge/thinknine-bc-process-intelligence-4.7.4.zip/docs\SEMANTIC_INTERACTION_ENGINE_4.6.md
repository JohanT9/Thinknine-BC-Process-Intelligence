# Documentation Excellence v4.6 R3 — Semantic Interaction Rules Engine

## Remaining low-level compatibility responsibility

For Step Group input, none: mechanical lookup, focus, selection, result, and
commit boundaries belong exclusively to Event Step Grouping. The engine receives
one structure at a time, such as `kind: "lookup-interaction"` with
`targetControl`, `selectedValue`, and `sourceEventIds`, and applies only business
interpretation such as Customer, Item, Vendor, or Quantity.

The engine retains an explicitly temporary adapter for historical ungrouped
Review/document interactions. Only that path may scan adjacent legacy lookup
captions, selected-record text, matching field results, or focus-only noise. No
such scan runs in `processStepGroups`.

Within that adapter, an explicit structured `Select` interaction is authoritative
for the chosen lookup value and wins over preceding search/filter text. Modern
Step Groups use `selection.value` before descriptive `selection.caption`, so a
Business Central row number remains the documented value while the row caption
remains supporting context.

Legacy Business Central accessibility text may prefix the selection with sort
metadata, for example `Nr, sorterade i Stigande order Välj posten "905"`. The
adapter extracts the quoted record value from the embedded selection phrase and
consolidates it with the preceding lookup step; the sort/search wording is not a
separate documentation action.

The legacy item-number shape `EnterFieldValue → embedded RunAction selection →
repeated EnterFieldValue` is likewise one interaction. When the selected and
resulting values match, it becomes `Ange <value> i Artikel Nr`; the mechanical
`Sortera efter Nr` controls are not exposed as separate steps. This compatibility
rule does not replace or reinterpret structured modern `Select` interactions.

A complete `SearchAndOpenPage` followed immediately by a repeated entry in the
same Tell Me/search field is also one interaction. The search action absorbs
the duplicate field step, retains all source evidence, keeps the result-oriented
screenshot, and uses the later field evidence to replace a generic search-text
placeholder. A different value or a non-search field remains a separate step.

The Business Central manual-price menu path is documented as one action:
`Åtgärder → Funktion → Manuellt pris`. Some React surfaces do not emit a
separate interaction for the intermediate `Funktion` menu. The compatibility
rule therefore also accepts the exact adjacent endpoints `Åtgärder → Manuellt
pris`, retains only their real source references, and uses the final focused-menu
screenshot. It does not match when any unrelated action occurs between them.
An immediately repeated `Manuellt pris` capture is retained as evidence on the
same Semantic Action and suppressed as a duplicate visible step. The preferred
image remains the first capture where the final menu choice is visibly focused.

Two adjacent action observations with the same caption and the same explicit
recorder `interactionId` are represented as one Semantic Action. This handles
the case where one user gesture is delivered once as action evidence and once
as result evidence. Both Capture Packets, source events and screenshots remain
attached to the consolidated action. The rule does not use timing or caption
similarity as a substitute for identity: repeated actions with different
interaction identities, different captions, or menu-parent actions remain
separate. Specific menu-path rules continue to have higher priority.

Instructions with `user-edited` provenance pass through semantic rules unchanged.
Reset restores the latest generated semantic instruction.

## Purpose

Semantic Actions remain generated inputs. Structure resolution can reshape their
document presentation but never changes the semantic interpretation itself.

The engine now exposes `processStepGroups` as its primary normalized-recording
entry point. A renderer-neutral adapter maps group structure into the established
rule contract without generating final wording in the grouping layer. Semantic
Actions retain Step Group and canonical source IDs. Existing task-sequence
consolidation remains temporarily available for legacy Reviews and recordings
lacking modern grouping metadata.

Semantic Actions may expose primary mechanics and target context to Screenshot
Selection, but the rules engine never ranks or chooses screenshot assets.

The engine converts deterministic low-level interaction sequences into concise
business actions. It improves representation only: rules never invent values,
change workflow meaning, mutate Review, remove provenance or inspect images.

## Pipeline

```text
Review
→ Review Projector
→ Semantic Document
→ Semantic Interaction Rules Engine
→ Language Excellence
→ Screenshot Intelligence
→ Document Profile / Theme / Planner
→ Document Workspace / Word
```

Existing Reviews require no migration. Older tasks without interaction metadata
pass through unchanged. The existing customer, item and quantity rules were
migrated unchanged; the previous task adapter now delegates to this engine.

## Rule contract and registry

Every immutable rule defines `ruleId`, numeric `priority`, `match(context)` and
`consolidate(context)`. Match only identifies safe candidates. Consolidate
returns one immutable Semantic Action and the exact number of consumed ordered
interactions. Rules are independently testable and deterministic.

The built-in registry orders rules by descending priority:

| Rule | Priority |
| --- | ---: |
| Sales price/discount menu path | 110 |
| Manual price menu path | 110 |
| Duplicate action observation | 108 |
| Close dialog with visible control | 105 |
| Customer selection | 100 |
| Item selection | 95 |
| Vendor selection | 90 |
| Location selection | 85 |
| Dimension selection | 80 |
| Quantity entry | 75 |
| Date selection | 70 |
| Checkbox enable/disable | 60 |
| Option selection | 50 |
| Generic lookup | 20 |
| Generic field entry | 10 |

Specific rules therefore win over generic rules. If multiple matching rules
share the highest priority, the engine preserves the original interaction
instead of guessing. Invalid rule results also fall back safely.

Focus-only `ChangeField` interactions are represented as suppressed semantic
trace rather than visible steps. A focus transition followed by a deterministic
record selection and matching field result becomes one generic lookup action.
A selection prompt without a selected value is also suppressed. Actual typed
values, option changes and record selections remain visible.

Recorder deduplication includes the input source, preventing a later focusout
from replacing evidence of real input. For backward compatibility, a non-empty
field value remains instructional even when an older recording contains only
focusout provenance. Generic lookup labels remove the technical `Sortera efter`
prefix, producing wording such as `Välj Nr "136"`.

The recorder's separate screenshot capture policy captures non-empty input and
change events but not focusout. Field input cannot reuse a nearby action image
or another field's image, ensuring that a retained value step can reference the
screen state in which its value was entered.

## Semantic Action model

A Semantic Action contains:

- stable `actionId`, `actionType`, rule identity and engine version;
- display text, selected value and target field;
- stable source task IDs, step numbers and ordered event references;
- all screenshot and annotation references;
- cloned raw interactions for complete traceability;
- preserved unknown future semantic-action metadata.

Stable source identities do not depend on workflow position. Original Review,
screenshot bytes and annotation storage are never modified.

## Rendering and language boundaries

The engine exposes all candidate screenshot references but never scores them.
Screenshot Intelligence remains responsible for image selection. Language
Excellence receives Semantic Actions and remains responsible for wording only.
Rules are independent of Document Profiles, themes, planners, Word and the
Document Workspace.

Both visual document inspection and Word export flow through the same semantic
action document and validated Document Plan. This prevents renderer-specific
consolidation and preserves output parity.

## Performance

Only workflow step candidates are scanned. A projected immutable document
revision is processed once and cached by object identity. Profile variants reuse
the same result; a changed Review produces a new projection and cache entry.

## Extension strategy

A future consolidation adds one rule and registers its priority. It requires no
projector, language, screenshot, planner or renderer changes. New rules must
prove their intent deterministically, preserve every source reference and use a
priority distinct enough to avoid ambiguous ownership.

## Compatibility and guarantees

- Existing Reviews require no migration.
- Existing rules were migrated unchanged.
- Traceability is fully preserved.
- Rules never invent information.
- Semantic Actions preserve workflow meaning.
- Unknown future metadata survives processing.
- Suppressed UI mechanics remain available as ordered semantic trace.
- Screenshot Intelligence remains responsible for image selection.
- Language Excellence remains responsible for wording.

## Process Model consumer

Generated activities may reference stable Semantic Action IDs. The Process
Model does not reinterpret rule output, turn every UI mechanic into an activity,
or infer branches from captions or controls. See
[PROCESS_MODEL.md](PROCESS_MODEL.md).

## Regeneration

Semantic rules run through their existing owner and record their component
version in the Derived Revision. Fresh generated semantics can improve without
overwriting explicit consultant fields. See
[REGENERATE_FROM_RECORDING.md](REGENERATE_FROM_RECORDING.md).
