(function (root, factory) {
  const pageIdentity = typeof module === "object" && module.exports
    ? require("./page-identity") : root.T9PageIdentity;
  const languages = typeof module === "object" && module.exports
    ? require("./language-registry") : root.T9LanguageRegistry;
  const taxonomySchema = typeof module === "object" && module.exports
    ? require("./process-taxonomy-schema") : root.T9ProcessTaxonomySchema;
  const semanticModel = typeof module === "object" && module.exports
    ? require("./canonical-semantic-model") : root.T9CanonicalSemanticModel;
  const api = factory(pageIdentity, languages, taxonomySchema, semanticModel);
  if (typeof module === "object" && module.exports) module.exports = api;
  root.T9CanonicalRecording = api;
})(typeof globalThis !== "undefined" ? globalThis : this,
  function (pageIdentity, languages, taxonomySchema, semanticModel) {
  "use strict";
  const SCHEMA_VERSION = 1;
  const RECORDING_PURPOSES = Object.freeze({
    DOCUMENTATION: "documentation",
    BUG_REPORT: "bug-report"
  });
  const clone = value => value == null ? value : JSON.parse(JSON.stringify(value));
  function normalizeRecordingPurpose(value) {
    return value === RECORDING_PURPOSES.BUG_REPORT
      ? RECORDING_PURPOSES.BUG_REPORT
      : RECORDING_PURPOSES.DOCUMENTATION;
  }
  function eventType(type) {
    return ({ "page-state": "pageOpened", "field-change": "fieldChanged", dialog: "dialogOpened" })[type] || type || "other";
  }
  function canonicalEvent(sessionId, source = {}, index = 0, identification = null) {
    const eventNo = source.eventNo || index + 1;
    const sourceEventId = source.sourceEventId || source.captureId || null;
    const event = {
      id: source.id || (sourceEventId
        ? `${sessionId}:event:${sourceEventId}`
        : `${sessionId}:event:${eventNo}`),
      recordingId: sessionId,
      schemaVersion: SCHEMA_VERSION,
      sequence: index + 1,
      timestamp: source.timestamp || new Date(0).toISOString(),
      capturedAt: source.timestamp || new Date(0).toISOString(),
      type: eventType(source.type),
      source: {
        type: source.source || "legacy-recorder",
        eventId: sourceEventId || undefined,
        sequence: source.sourceSequence ?? undefined,
        frameId: source.sourceFrameId || undefined,
        frameSequence: source.frameSequence ?? source.sourceSequence ?? undefined
      },
      raw: clone(source)
    };
    if (source.interactionId) event.interaction = {
      id: String(source.interactionId), source: "recorder"
    };
    const resolvedIdentification = identification || source.identification || null;
    if (resolvedIdentification) event.identification = clone(resolvedIdentification);
    const identifiedPage = resolvedIdentification?.pageIdentity || {};
    const pageObjectId = pageIdentity.observedPageObjectId(source);
    const pageCaption = source.pageCaption || source.pageName || undefined;
    if (source.pageId || pageObjectId || pageCaption || source.frameUrl) event.page = {
      id: source.pageId || undefined,
      pageObjectId: pageObjectId || undefined,
      name: pageCaption,
      caption: pageCaption,
      entity: identifiedPage.entity || undefined,
      pageType: identifiedPage.pageType || undefined,
      tableId: identifiedPage.tableId || undefined,
      recordType: identifiedPage.recordType || undefined,
      url: source.frameUrl || undefined
    };
    if (source.pageId || pageObjectId || pageCaption) event.businessCentral = {
      pageId: source.pageId || undefined,
      pageObjectId: pageObjectId || undefined,
      pageName: pageCaption,
      pageCaption
    };
    if (source.fieldName || source.label || source.role) event.control = { name: source.fieldName || source.label || undefined, role: source.role || undefined };
    if (source.category || source.inputSource || source.key) event.action = { category: source.category || undefined, inputSource: source.inputSource || undefined, key: source.key || undefined };
    if (Object.prototype.hasOwnProperty.call(source, "value")) event.value = clone(source.value);
    if (Object.prototype.hasOwnProperty.call(source, "previousValue")) event.previousValue = clone(source.previousValue);
    if (source.target) event.target = clone(source.target);
    else if (source.automationId || source.controlType) event.target = {
      automationId: source.automationId || undefined,
      controlType: source.controlType || undefined
    };
    if (source.label || source.role) event.accessibleTarget = {
      name: source.label || source.fieldName || undefined,
      role: source.role || undefined
    };
    if (source.clientX != null || source.clientY != null) event.coordinates = {
      x: source.clientX ?? undefined,
      y: source.clientY ?? undefined
    };
    if (source.frameUrl || source.topUrl || source.frameDepth != null) event.frame = {
      id: source.sourceFrameId || undefined,
      url: source.frameUrl || undefined,
      topUrl: source.topUrl || undefined,
      depth: source.frameDepth ?? undefined
    };
    if (source.selector) event.selector = source.selector;
    if (source.screenshotAssetId) event.screenshotAssetId = source.screenshotAssetId;
    return event;
  }
  function metadataFromSession(session = {}) {
    const configured = session.settings || {};
    const businessCentral = clone(session.businessCentral || {});
    businessCentral.environment = businessCentral.environment ||
      configured.businessCentralEnvironment || configured.environmentName || undefined;
    businessCentral.company = businessCentral.company ||
      configured.businessCentralCompany || configured.companyName || undefined;
    return { title: session.name || undefined, startedAt: session.startedAt || new Date(0).toISOString(), finishedAt: session.completedAt || session.finishedAt || undefined, sourceApplication: session.sourceApplication || "Microsoft Dynamics 365 Business Central", sourceUrl: session.sourceUrl || undefined, businessCentral, recordingPurpose: normalizeRecordingPurpose(session.recordingPurpose), taxonomyReferences: taxonomySchema.normalizeRecordingReferences(session.taxonomyReferences) };
  }
  function assetFor(sessionId, eventNo, value) {
    return { id: `${sessionId}:screenshot:${eventNo}`, type: "screenshot", path: `screenshots/${String(eventNo).padStart(6, "0")}.png`, mimeType: /^data:([^;,]+)/.exec(String(value || ""))?.[1] || "image/png", metadata: { legacyEventNo: Number(eventNo) } };
  }
  function create(options = {}) {
    const now = options.startedAt || new Date().toISOString();
    const session = options.legacySession || { id: options.id, name: options.title, recordingPurpose: normalizeRecordingPurpose(options.recordingPurpose), startedAt: now, completedAt: options.finishedAt, updatedAt: options.updatedAt || now, settings: clone(options.settings || {}) };
    return { id: options.id, schemaVersion: SCHEMA_VERSION, metadata: metadataFromSession(session), events: [], assets: [], semanticInterpretation: semanticModel.normalize(options.semanticInterpretation || session.semanticInterpretation), createdAt: now, updatedAt: options.updatedAt || now, compatibility: { session: clone(session) } };
  }
  function fromLegacy(session, events = [], screenshots = {}) {
    const result = create({ id: session.id, startedAt: session.startedAt, updatedAt: session.updatedAt, legacySession: session });
    result.events = events.map((event, index) => canonicalEvent(session.id, event, index));
    result.assets = Object.entries(screenshots).map(([eventNo, value]) => assetFor(session.id, eventNo, value));
    const assets = new Map(result.assets.map(asset => [asset.metadata.legacyEventNo, asset.id]));
    result.events.forEach(event => { const id = assets.get(Number(event.raw?.eventNo)); if (id) event.screenshotAssetId = id; });
    return result;
  }
  function integrityDiagnostics(input, options = {}) {
    const diagnostics = [];
    if (!input || Number(input.schemaVersion) !== SCHEMA_VERSION) {
      diagnostics.push({ code: "unsupported-canonical-schema", severity: "error",
        schemaVersion: input?.schemaVersion ?? null, supportedSchemaVersion: SCHEMA_VERSION });
      return diagnostics;
    }
    const events = Array.isArray(input.events) ? input.events : [];
    const assets = Array.isArray(input.assets) ? input.assets : [];
    const eventIds = new Set();
    const assetIds = new Set(assets.map(asset => String(asset.id)));
    events.forEach((event, index) => {
      if (!event.id || eventIds.has(String(event.id))) diagnostics.push({
        code: "duplicate-canonical-event-id", severity: "error",
        eventId: event.id || null });
      eventIds.add(String(event.id));
      if (event.sequence !== index + 1) diagnostics.push({
        code: "canonical-event-order-mismatch", severity: "error",
        eventId: event.id || null, expectedSequence: index + 1,
        actualSequence: event.sequence });
      if (event.screenshotAssetId && !assetIds.has(String(event.screenshotAssetId))) {
        diagnostics.push({ code: "missing-canonical-screenshot-asset",
          severity: "error", eventId: event.id,
          screenshotAssetId: event.screenshotAssetId });
      }
    });
    const semantic = semanticModel.normalize(input.semanticInterpretation);
    [...semantic.classifications, ...semantic.documentStateTransitions].forEach(item => {
      item.sourceEventIds.forEach(eventId => {
        if (!eventIds.has(String(eventId))) diagnostics.push({
          code: "missing-semantic-source-event", severity: "error",
          semanticId: item.classificationId || item.transitionId, eventId });
      });
    });
    if (Number.isFinite(options.legacyEventCount) &&
        options.legacyEventCount !== events.length) diagnostics.push({
      code: "legacy-canonical-event-count-mismatch", severity: "error",
      canonicalEventCount: events.length, legacyEventCount: options.legacyEventCount });
    return diagnostics;
  }
  function normalize(input, legacy = {}) {
    if (!input || input.schemaVersion == null) return (!legacy.session && !input) ? null : fromLegacy(legacy.session || input, legacy.events, legacy.screenshots);
    if (Number(input.schemaVersion) !== SCHEMA_VERSION) throw new Error(`Unsupported recording schema: ${input.schemaVersion}`);
    const result = clone(input); result.events = Array.isArray(result.events) ? result.events : [];
    result.events = result.events.map(event => event?.identification || !event?.raw?.identification
      ? event : { ...event, identification: clone(event.raw.identification) });
    result.assets = Array.isArray(result.assets) ? result.assets : []; result.metadata ||= {}; result.metadata.recordingPurpose = normalizeRecordingPurpose(result.metadata.recordingPurpose); result.metadata.taxonomyReferences = taxonomySchema.normalizeRecordingReferences(result.metadata.taxonomyReferences); result.semanticInterpretation = semanticModel.normalize(result.semanticInterpretation); return result;
  }
  function addEvent(recording, source, identification = null) {
    if (!source || typeof source !== "object" || Array.isArray(source) || !source.type) throw new TypeError("A raw event with a type is required.");
    const sourceId = source.sourceEventId || source.captureId;
    if (sourceId && recording.events?.some(event => event.source?.eventId === sourceId)) return recording;
    const result = normalize(recording);
    if (result.metadata.finishedAt) throw new Error("Completed recording evidence is immutable.");
    result.events.push(canonicalEvent(result.id, source, result.events.length, identification));
    result.updatedAt = source.timestamp || new Date().toISOString();
    return result;
  }
  function addScreenshot(recording, eventReference, dataUrl, createdAt = new Date().toISOString()) {
    const result = normalize(recording);
    if (result.metadata.finishedAt) throw new Error("Completed recording evidence is immutable.");
    const event = result.events.find(item =>
      item.id === eventReference || Number(item.raw?.eventNo) === Number(eventReference)
    );
    if (!event) throw new Error(`Canonical screenshot event not found: ${eventReference}`);
    const eventNo = event.raw?.eventNo || event.sequence;
    const asset = { ...assetFor(result.id, eventNo, dataUrl), createdAt };
    if (event.screenshotAssetId) {
      if (!result.assets.some(item => item.id === event.screenshotAssetId)) {
        throw new Error(`Missing canonical screenshot asset: ${event.screenshotAssetId}`);
      }
      return result;
    }
    const existing = result.assets.findIndex(item => item.id === asset.id);
    if (existing >= 0) result.assets[existing] = asset; else result.assets.push(asset);
    event.screenshotAssetId = asset.id;
    result.updatedAt = createdAt;
    return result;
  }
  function finish(recording, finishedAt) { if (recording.metadata?.finishedAt) { if (recording.metadata.finishedAt === finishedAt) return recording; throw new Error("Completed recording evidence is immutable."); } const result = normalize(recording); result.metadata.finishedAt = finishedAt; result.updatedAt = finishedAt; if (result.compatibility?.session) Object.assign(result.compatibility.session, { completedAt: finishedAt, updatedAt: finishedAt, status: "completed" }); return result; }
  function rename(recording, title) { const value = String(title || "").trim(); if (!value) return normalize(recording); if (recording.metadata?.finishedAt) throw new Error("Completed recording evidence is immutable."); const result = normalize(recording); result.metadata.title = value; if (result.compatibility?.session) result.compatibility.session.name = value; return result; }
  function setDocumentLanguage(recording, language) { if (recording.metadata?.finishedAt) throw new Error("Completed recording evidence is immutable."); const result = normalize(recording); const value = languages.normalize(language, "document"); result.metadata.documentLanguage = value; if (result.compatibility?.session) result.compatibility.session.settings = { ...(result.compatibility.session.settings || {}), documentLanguage: value }; return result; }
  function setTaxonomyReferences(recording, references) { if (recording.metadata?.finishedAt) throw new Error("Completed recording evidence is immutable."); const result = normalize(recording); const value = taxonomySchema.normalizeRecordingReferences(references); result.metadata.taxonomyReferences = value; if (result.compatibility?.session) result.compatibility.session.taxonomyReferences = clone(value); return result; }
  function requireSemanticEvents(recording, item) { const ids = new Set(recording.events.map(event => String(event.id))); const missing = (item.sourceEventIds || []).filter(id => !ids.has(String(id))); if (missing.length) throw new Error(`Semantic source event not found: ${missing.join(", ")}`); if (!item.sourceEventIds?.length) throw new Error("At least one semantic source event is required."); }
  function setSemanticClassification(recording, classification) { const result = normalize(recording); const value = semanticModel.normalizeClassification(classification); requireSemanticEvents(result, value); result.semanticInterpretation = semanticModel.upsertClassification(result.semanticInterpretation, value); return result; }
  function setDocumentStateTransition(recording, transition) { const result = normalize(recording); const value = semanticModel.normalizeTransition(transition); requireSemanticEvents(result, value); result.semanticInterpretation = semanticModel.upsertDocumentStateTransition(result.semanticInterpretation, value); return result; }
  function semanticForEvent(recording, eventId) { return semanticModel.forEvent(normalize(recording).semanticInterpretation, eventId); }
  function legacyView(recording) { const value = normalize(recording); const session = clone(value.compatibility?.session || {}); Object.assign(session, { id: value.id, name: session.name || value.metadata.title, purpose: session.purpose || "", recordingPurpose: value.metadata.recordingPurpose, taxonomyReferences: clone(value.metadata.taxonomyReferences), startedAt: session.startedAt || value.metadata.startedAt, completedAt: session.completedAt || value.metadata.finishedAt || null, updatedAt: value.updatedAt, eventCount: value.events.length }); return { session, events: value.events.map(event => ({ ...clone(event.raw || { id: event.id, timestamp: event.timestamp, type: event.type }), ...(event.identification ? { identification: clone(event.identification) } : {}) })) }; }
  return { RECORDING_PURPOSES, SCHEMA_VERSION, addEvent, addScreenshot, create,
    finish, fromLegacy, integrityDiagnostics, legacyView, normalize, rename,
    semanticForEvent, setDocumentLanguage, setDocumentStateTransition,
    setSemanticClassification, setTaxonomyReferences,
    normalizeRecordingPurpose };
});
