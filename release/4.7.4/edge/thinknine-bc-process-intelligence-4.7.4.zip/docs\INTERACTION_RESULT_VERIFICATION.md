# Interaction Result Verification

## Purpose

Result Verification records what Business Central observably did after an
interaction. It improves review confidence without guessing business intent or
changing the consultant's editable expected result.

```text
Raw Event -> Normalized Event -> Step Group capture packet
          -> Semantic Action -> Review Step
```

Step Grouping owns the mechanical relationship between an activation and its
immediate outcomes. Semantic rules receive that resolved relationship and do
not rediscover adjacent events.

## Contract

Each capture packet contains an additive immutable `resultVerification` object:

- `status`: `verified`, `error`, or `unverified`
- `primaryOutcome`: the deterministic outcome kind
- `primaryOutcomeEventId`: the single normalized event owning that outcome
- `outcomes`: ordered normalized and canonical source references
- `summary`: concise observed result for Review Studio
- `expectedResultSuggestion`: a non-destructive suggestion
- `sourceEventIds`: canonical traceability

Supported outcomes are navigation, dialog open/close, value change, selection,
toggle change, accessible status message, and Business Central error. An action
may collect more than one immediate outcome, for example a dialog opening
followed by an error.

The model stores only bounded outcome facts and captions already present in
normalized context. Status-message text, error details, call stacks, entered
business values, URLs, and raw payloads are not copied into the document model.
Full evidence remains in Canonical Recording. Because status messages are
transient, the screenshot policy captures their visible state when screenshots
are enabled. A status message without a stable initiating interaction remains
supporting evidence and cannot create a standalone documentation step.

Exact causal ownership is protected by the versioned
[Interaction to Result correctness corpus](INTERACTION_RESULT_CORRECTNESS.md).
In particular, a late outcome from an older interaction must never attach to a
newer active step; it remains supporting evidence when causality is uncertain.

## User experience and compatibility

Verified steps show a distinct **Observerat resultat** or **Observerat fel**
line in Review Studio. The same evidence-backed summary is projected as a
system-derived information callout under its owning Step in Semantic Document,
Document Workspace, and Word. Its label and generated sentence follow the UI or
document language while observed Business Central captions remain unchanged.

The document-level expected-result field remains fully manual, visually
separate, and is never overwritten by an observation or suggestion. Historical
recordings and Reviews without verification metadata continue unchanged.

This is an additive schema-v1 projection. Canonical Recording schema version is
unchanged, and raw events are neither modified nor rewritten.
