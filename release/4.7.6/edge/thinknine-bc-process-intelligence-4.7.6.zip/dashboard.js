const DEFAULTS = {
  uiLocale: "en-US",
  documentLanguage: "en-US",
  exportFileNamePattern: "{process} - {environment} - {date}",
  documentationProfile: "generic",
  defaultExpectedResult:
    "Processen är genomförd enligt arbetsgången och de registrerade " +
    "ändringarna har sparats i Business Central.",
  captureScreenshots: true,
  showClickHighlights: true,
  screenshotMode: "important",
  maskValues: true,
  maxEvents: 20000,
  environmentName: "ApteanAdvance",
  companyName: "",
  supportEmail: "",
  bugReportEmailMode: "eml",
  knowledgeMcpEnabled: false,
  advancedOverridesEnabled: false,
  maskSalesOrderNo: true,
  maskPurchaseOrderNo: true,
  maskInvoiceNo: true,
  maskReceiptNo: true,
  maskShipmentNo: true,
  maskProductionOrderNo: true,
  maskPostedDocumentNo: true,
  maskCompanyName: true,
  maskTenantAndUrl: true,
  maskCustomerNo: false,
  maskVendorNo: false,
  maskItemNo: false,
  maskLocationCode: false,
  maskLotBatchNo: false
};

let applicationSettings = { ...DEFAULTS };

const uiT = key => globalThis.T9UiI18n.translate(
  key, applicationSettings.uiLocale
);
const uiTf = (key, values) => globalThis.T9UiI18n.format(
  key, values, applicationSettings.uiLocale
);

const $ = id => document.getElementById(id);
const send = message => chrome.runtime.sendMessage(message);
const processIntelligenceEnabled = () =>
  globalThis.T9FeatureFlags?.isEnabled("processIntelligence") === true;
globalThis.T9FeatureFlags?.apply(document);


const CONTEXT_BUILDER_VERSION = "1.0.0";

function contextPageCaption(event) {
  return cleanUiCaption(
    event.identification?.page?.caption ||
    event.pageCaption ||
    event.documentTitle ||
    ""
  );
}

function eventControlCaption(event) {
  return cleanUiCaption(
    event.identification?.control?.caption ||
    event.fieldName ||
    event.label ||
    ""
  );
}

function isOpenRecordEvent(event) {
  return event.type === "click" &&
    identifiedActionType(event) === "OpenRecord";
}

function isConfirmEvent(event) {
  return event.type === "click" && ["ConfirmYes", "ConfirmNo"]
    .includes(identifiedActionType(event));
}

function isStatusActionEvent(event) {
  return event.type === "click" && ["ReopenDocument", "ReleaseDocument"]
    .includes(identifiedActionType(event));
}

function isPostActionEvent(event) {
  return event.type === "click" && identifiedActionType(event) === "PostDocument";
}

function identifiedActionType(event) {
  return event.identification?.actionIdentity?.actionType ||
    globalThis.T9BCUIIdentification.identifyAction(event).actionType || "";
}

function detectContextEntity(pageCaption, identification = null) {
  return identification?.pageIdentity?.entity ||
    globalThis.T9BCUIIdentification.identifyPage({ pageCaption }).entity || "";
}

function extractRecordValueFromOpenCaption(caption) {
  const text = cleanUiCaption(caption);

  const quoted = text.match(/["“](.+?)["”]/);
  if (quoted) return quoted[1];

  const trailing = text.match(/(?:open record|öppna post(?:en)?)\s+([A-Z0-9._/-]+)$/i);
  if (trailing) return trailing[1];

  return "";
}

function buildContextEvents(rawEvents) {
  const result = [];
  let currentPage = "";
  let previousPage = "";
  let currentEntity = "";
  let selectedRecordValue = "";
  let pendingAction = null;
  let activeDialog = null;

  for (let index = 0; index < rawEvents.length; index += 1) {
    const event = rawEvents[index];
    const next = rawEvents[index + 1];
    const next2 = rawEvents[index + 2];

    const eventPage = contextPageCaption(event);
    if (eventPage && eventPage !== currentPage) {
      previousPage = currentPage;
      currentPage = eventPage;
      currentEntity = detectContextEntity(currentPage, event.identification) || currentEntity;
    }

    if (isOpenRecordEvent(event)) {
      selectedRecordValue =
        extractRecordValueFromOpenCaption(eventControlCaption(event)) ||
        selectedRecordValue;
    }

    if (event.category === "dialog") {
      activeDialog = {
        eventNo: event.eventNo,
        caption: eventControlCaption(event),
        pageCaption: currentPage
      };
    }

    if (isStatusActionEvent(event) || isPostActionEvent(event)) {
      pendingAction = {
        eventNo: event.eventNo,
        caption: eventControlCaption(event),
        semanticHint: identifiedActionType(event)
      };
    }

    const navigationTarget =
      next?.category === "navigation"
        ? contextPageCaption(next)
        : next2?.category === "navigation"
          ? contextPageCaption(next2)
          : "";

    const enriched = {
      ...event,
      context: {
        builderVersion: CONTEXT_BUILDER_VERSION,
        currentPageCaption: currentPage,
        previousPageCaption: previousPage,
        currentEntity,
        selectedRecordValue,
        pendingActionCaption: pendingAction?.caption || "",
        pendingSemanticHint: pendingAction?.semanticHint || "",
        activeDialogCaption: activeDialog?.caption || "",
        hasFollowingNavigation: Boolean(navigationTarget),
        followingPageCaption: navigationTarget,
        followingEntity: detectContextEntity(navigationTarget,
          next?.category === "navigation" ? next.identification : next2?.identification),
        isOpenRecord: isOpenRecordEvent(event),
        isConfirmation: isConfirmEvent(event),
        isStatusAction: isStatusActionEvent(event),
        isPostAction: isPostActionEvent(event)
      }
    };

    result.push(enriched);

    if (isConfirmEvent(event)) {
      activeDialog = null;
      pendingAction = null;
    }

    if (event.category === "navigation" && eventPage) {
      currentPage = eventPage;
      currentEntity = detectContextEntity(eventPage, event.identification) || currentEntity;
    }
  }

  return result;
}

function createContextCandidates(contextEvents) {
  const candidates = [];

  for (let index = 0; index < contextEvents.length; index += 1) {
    const event = contextEvents[index];
    const context = event.context || {};

    if (context.isOpenRecord) {
      candidates.push({
        candidateType: "OpenRecord",
        sourceEventNos: [event.eventNo],
        currentPageCaption: context.currentPageCaption,
        targetPageCaption: context.followingPageCaption,
        entity:
          context.followingEntity ||
          context.currentEntity,
        recordValue: context.selectedRecordValue,
        confidence: context.followingPageCaption ? 0.96 : 0.82,
        reason: [
          `Current page: ${context.currentPageCaption || "unknown"}`,
          `Action: ${eventControlCaption(event)}`,
          context.followingPageCaption
            ? `Following page: ${context.followingPageCaption}`
            : "No following navigation"
        ]
      });
    }

    if (context.isStatusAction) {
      const nextConfirm = contextEvents
        .slice(index + 1, index + 5)
        .find(candidate => candidate.context?.isConfirmation);

      candidates.push({
        candidateType: context.pendingSemanticHint || "ChangeDocumentStatus",
        sourceEventNos: [
          event.eventNo,
          ...(nextConfirm ? [nextConfirm.eventNo] : [])
        ],
        currentPageCaption: context.currentPageCaption,
        entity: context.currentEntity,
        actionCaption: eventControlCaption(event),
        confirmationCaption: nextConfirm
          ? eventControlCaption(nextConfirm)
          : "",
        confidence: nextConfirm ? 0.99 : 0.94,
        reason: [
          `Page: ${context.currentPageCaption || "unknown"}`,
          `Action: ${eventControlCaption(event)}`,
          nextConfirm
            ? `Confirmation: ${eventControlCaption(nextConfirm)}`
            : "No explicit confirmation"
        ]
      });
    }

    if (context.isPostAction) {
      const nextConfirm = contextEvents
        .slice(index + 1, index + 6)
        .find(candidate => candidate.context?.isConfirmation);

      candidates.push({
        candidateType: "PostDocument",
        sourceEventNos: [
          event.eventNo,
          ...(nextConfirm ? [nextConfirm.eventNo] : [])
        ],
        currentPageCaption: context.currentPageCaption,
        entity: context.currentEntity,
        actionCaption: eventControlCaption(event),
        confirmationCaption: nextConfirm
          ? eventControlCaption(nextConfirm)
          : "",
        confidence: nextConfirm ? 0.99 : 0.95,
        reason: [
          `Page: ${context.currentPageCaption || "unknown"}`,
          `Action: ${eventControlCaption(event)}`,
          nextConfirm
            ? `Confirmation: ${eventControlCaption(nextConfirm)}`
            : "No explicit confirmation"
        ]
      });
    }

    if (
      event.type === "field-change" &&
      /datum|date/i.test(eventControlCaption(event))
    ) {
      candidates.push({
        candidateType: "ChangeDate",
        sourceEventNos: [event.eventNo],
        currentPageCaption: context.currentPageCaption,
        entity: context.currentEntity,
        fieldCaption: eventControlCaption(event),
        value: event.value ?? "",
        confidence: 0.96,
        reason: [
          `Page: ${context.currentPageCaption || "unknown"}`,
          `Field: ${eventControlCaption(event)}`
        ]
      });
    }
  }

  return candidates;
}


const KNOWLEDGE_PACK_FRAMEWORK_VERSION = "2.0.0";
let loadedKnowledgePacks = [];
let loadedKnowledgeRelease = null;
let loadedKnowledgeRepository = null;
let loadedKnowledgeRules = [];
let unmatchedKnowledgeItems = [];

async function loadKnowledgePacks() {
  const indexUrl = chrome.runtime.getURL("knowledge-packs/index.json");
  const loaded = await globalThis.BCKnowledgeRepository.load({
    indexUrl,
    resolveUrl: file => chrome.runtime.getURL(file)
  });
  if (!loaded.ok) throw new Error(loaded.diagnostics.map(item => item.code).join(", "));
  const repository = globalThis.BCKnowledgeRepository.createRepository(loaded.snapshot);
  const snapshot = repository.getRelease();
  const pageValidation = globalThis.T9PageIdentificationEngine.configureKnowledgePacks(
    snapshot.packs
  );
  loadedKnowledgePacks = [...snapshot.packs];
  loadedKnowledgeRelease = snapshot.release;
  loadedKnowledgeRepository = repository;
  loadedKnowledgeRules = globalThis.T9KnowledgeDomain.rules(loadedKnowledgePacks);
  return { packs: loadedKnowledgePacks, snapshot, repository,
    pageValidation };
}

function applyKnowledgePackFramework(tasks) {
  const result = globalThis.T9KnowledgeDomain.apply(tasks, loadedKnowledgePacks);
  unmatchedKnowledgeItems = result.unmatched;
  return result.tasks;
}


const PROFILE_PRESETS = {
  generic: {
    label: "Generisk manual",
    help: "Maskerar transaktionsnummer, företagsnamn, tenant och URL. Kund-, artikel-, lagerplats- och lot-/batchvärden behålls.",
    maskSalesOrderNo: true,
    maskPurchaseOrderNo: true,
    maskInvoiceNo: true,
    maskReceiptNo: true,
    maskShipmentNo: true,
    maskProductionOrderNo: true,
    maskPostedDocumentNo: true,
    maskCompanyName: true,
    maskTenantAndUrl: true,
    maskCustomerNo: false,
    maskVendorNo: false,
    maskItemNo: false,
    maskLocationCode: false,
    maskLotBatchNo: false
  },
  customer: {
    label: "Kundspecifik manual",
    help: "Behåller kundens masterdata och transaktionsvärden. Tenant och URL tas bort.",
    maskSalesOrderNo: false,
    maskPurchaseOrderNo: false,
    maskInvoiceNo: false,
    maskReceiptNo: false,
    maskShipmentNo: false,
    maskProductionOrderNo: false,
    maskPostedDocumentNo: false,
    maskCompanyName: false,
    maskTenantAndUrl: true,
    maskCustomerNo: false,
    maskVendorNo: false,
    maskItemNo: false,
    maskLocationCode: false,
    maskLotBatchNo: false
  },
  internal: {
    label: "Intern dokumentation",
    help: "Behåller all affärsdata. Endast teknisk tenant- och URL-information tas bort.",
    maskSalesOrderNo: false,
    maskPurchaseOrderNo: false,
    maskInvoiceNo: false,
    maskReceiptNo: false,
    maskShipmentNo: false,
    maskProductionOrderNo: false,
    maskPostedDocumentNo: false,
    maskCompanyName: false,
    maskTenantAndUrl: true,
    maskCustomerNo: false,
    maskVendorNo: false,
    maskItemNo: false,
    maskLocationCode: false,
    maskLotBatchNo: false
  },
  training: {
    label: "Utbildningsmaterial",
    help: "Maskerar transaktionsnummer men behåller tydliga exempel på masterdata och testdata.",
    maskSalesOrderNo: true,
    maskPurchaseOrderNo: true,
    maskInvoiceNo: true,
    maskReceiptNo: true,
    maskShipmentNo: true,
    maskProductionOrderNo: true,
    maskPostedDocumentNo: true,
    maskCompanyName: false,
    maskTenantAndUrl: true,
    maskCustomerNo: false,
    maskVendorNo: false,
    maskItemNo: false,
    maskLocationCode: false,
    maskLotBatchNo: false
  }
};

function applyProfile(profileName, updateControls = true) {
  const preset = PROFILE_PRESETS[profileName] || PROFILE_PRESETS.generic;
  $("profileHelp").textContent = preset.help;

  if (!updateControls) return;

  for (const [key, value] of Object.entries(preset)) {
    const element = $(key);
    if (element && typeof value === "boolean") {
      element.checked = value;
    }
  }
}


function show(text, error = false) {
  $("message").textContent = text || "";
  $("message").style.color = error ? "#b42318" : "#166534";
}

function escapeHtml(value) {
  return String(value || "").replace(/[&<>"']/g, char => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  })[char]);
}

function safeFileName(value) {
  return globalThis.T9Engine.exportSettings.safeFileName(value);
}

function bytes(text) {
  return new TextEncoder().encode(text);
}

function dataUrlBytes(dataUrl) {
  const base64 = dataUrl.slice(dataUrl.indexOf(",") + 1);
  const binary = atob(base64);
  const result = new Uint8Array(binary.length);

  for (let index = 0; index < binary.length; index += 1) {
    result[index] = binary.charCodeAt(index);
  }

  return result;
}

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);

  for (let n = 0; n < 256; n += 1) {
    let value = n;

    for (let k = 0; k < 8; k += 1) {
      value = (value & 1)
        ? 0xedb88320 ^ (value >>> 1)
        : value >>> 1;
    }

    table[n] = value >>> 0;
  }

  return table;
})();

function crc32(data) {
  let crc = 0xffffffff;

  for (const value of data) {
    crc = CRC_TABLE[(crc ^ value) & 0xff] ^ (crc >>> 8);
  }

  return (crc ^ 0xffffffff) >>> 0;
}

function dosTime(value) {
  const date = new Date(value || Date.now());
  const year = Math.max(1980, date.getFullYear());

  return {
    time:
      (date.getHours() << 11) |
      (date.getMinutes() << 5) |
      Math.floor(date.getSeconds() / 2),
    date:
      ((year - 1980) << 9) |
      ((date.getMonth() + 1) << 5) |
      date.getDate()
  };
}

function u16(view, offset, value) {
  view.setUint16(offset, value, true);
}

function u32(view, offset, value) {
  view.setUint32(offset, value >>> 0, true);
}

function zip(files) {
  const locals = [];
  const centrals = [];
  let offset = 0;

  for (const file of files) {
    const name = bytes(file.name);
    const data = file.data;
    const crc = crc32(data);
    const date = dosTime(file.modifiedAt);

    const local = new Uint8Array(30 + name.length + data.length);
    const localView = new DataView(local.buffer);

    u32(localView, 0, 0x04034b50);
    u16(localView, 4, 20);
    u16(localView, 6, 0x0800);
    u16(localView, 8, 0);
    u16(localView, 10, date.time);
    u16(localView, 12, date.date);
    u32(localView, 14, crc);
    u32(localView, 18, data.length);
    u32(localView, 22, data.length);
    u16(localView, 26, name.length);
    u16(localView, 28, 0);
    local.set(name, 30);
    local.set(data, 30 + name.length);
    locals.push(local);

    const central = new Uint8Array(46 + name.length);
    const centralView = new DataView(central.buffer);

    u32(centralView, 0, 0x02014b50);
    u16(centralView, 4, 20);
    u16(centralView, 6, 20);
    u16(centralView, 8, 0x0800);
    u16(centralView, 10, 0);
    u16(centralView, 12, date.time);
    u16(centralView, 14, date.date);
    u32(centralView, 16, crc);
    u32(centralView, 20, data.length);
    u32(centralView, 24, data.length);
    u16(centralView, 28, name.length);
    u16(centralView, 30, 0);
    u16(centralView, 32, 0);
    u16(centralView, 34, 0);
    u16(centralView, 36, 0);
    u32(centralView, 38, 0);
    u32(centralView, 42, offset);
    central.set(name, 46);
    centrals.push(central);

    offset += local.length;
  }

  const centralSize = centrals.reduce((sum, value) => sum + value.length, 0);
  const end = new Uint8Array(22);
  const endView = new DataView(end.buffer);

  u32(endView, 0, 0x06054b50);
  u16(endView, 4, 0);
  u16(endView, 6, 0);
  u16(endView, 8, files.length);
  u16(endView, 10, files.length);
  u32(endView, 12, centralSize);
  u32(endView, 16, offset);
  u16(endView, 20, 0);

  return new Blob([...locals, ...centrals, end], {
    type: "application/zip"
  });
}

function rawPageCaption(event) {
  return String(
    event.pageCaption ||
    event.documentTitle ||
    ""
  )
    .replace(/\s+/g, " ")
    .trim();
}

function stripWindowChrome(title) {
  return String(title || "")
    .replace(/\s+[∙·]\s+.*$/, "")
    .replace(/\s+-\s+Microsoft Dynamics 365 Business Central.*$/i, "")
    .trim();
}

function visiblePageCaption(event) {
  const caption = rawPageCaption(event);

  // Preserve the UI caption. Only remove surrounding browser/window chrome.
  return stripWindowChrome(caption) || "aktuell sida";
}

function cleanUiCaption(value) {
  return String(value || "")
    .replace(/\s+/g, " ")
    .replace(/[]+/g, "")
    .trim();
}


function normalizePageCaptionForDocumentation(caption, settings) {
  let result = String(caption || "").trim();

  if (settings?.maskCompanyName !== false) {
    result = result
      .replace(/\s*\([^)]*\)\s*$/, "")
      .replace(/\s+-\s+[A-ZÅÄÖ0-9][A-ZÅÄÖ0-9 _.-]{2,}$/, "");
  }

  // Remove transaction numbers from card page titles.
  result = result
    .replace(/\s+-\s+\d{4,}\s*$/, "")
    .replace(/\s+\d{4,}\s*$/, "");

  return result.trim() || "aktuell sida";
}

function classifyBusinessValue({
  value,
  fieldCaption = "",
  actionCaption = "",
  pageCaption = "",
  source = ""
}) {
  const rawValue = String(value ?? "").trim();
  const context = `${fieldCaption} ${actionCaption} ${pageCaption} ${source}`.toLowerCase();

  const matchers = [
    {
      role: "SalesOrderNo",
      patterns: [/förs\.?order/i, /försäljningsorder/i, /sales order/i],
      maskSetting: "maskSalesOrderNo",
      generic: "den försäljningsorder som ska hanteras"
    },
    {
      role: "PurchaseOrderNo",
      patterns: [/inköpsorder/i, /purchase order/i],
      maskSetting: "maskPurchaseOrderNo",
      generic: "den inköpsorder som ska hanteras"
    },
    {
      role: "InvoiceNo",
      patterns: [/fakturanr/i, /fakturanummer/i, /invoice no/i, /invoice number/i],
      maskSetting: "maskInvoiceNo",
      generic: "den faktura som ska hanteras"
    },
    {
      role: "ReceiptNo",
      patterns: [/inleveransnr/i, /receipt no/i, /warehouse receipt/i],
      maskSetting: "maskReceiptNo",
      generic: "den inleverans som ska hanteras"
    },
    {
      role: "ShipmentNo",
      patterns: [/utleveransnr/i, /shipment no/i, /warehouse shipment/i],
      maskSetting: "maskShipmentNo",
      generic: "den utleverans som ska hanteras"
    },
    {
      role: "ProductionOrderNo",
      patterns: [/produktionsordernr/i, /production order/i, /prod\. order/i],
      maskSetting: "maskProductionOrderNo",
      generic: "den produktionsorder som ska hanteras"
    },
    {
      role: "PostedDocumentNo",
      patterns: [/bokförd/i, /posted/i, /dokumentnr/i, /document no/i],
      maskSetting: "maskPostedDocumentNo",
      generic: "det bokförda dokument som ska hanteras"
    },
    {
      role: "CustomerNo",
      patterns: [/kundnr/i, /kundnummer/i, /customer no/i],
      maskSetting: "maskCustomerNo",
      generic: "aktuell kund"
    },
    {
      role: "VendorNo",
      patterns: [/leverantörsnr/i, /leverantörsnummer/i, /vendor no/i],
      maskSetting: "maskVendorNo",
      generic: "aktuell leverantör"
    },
    {
      role: "ItemNo",
      patterns: [/artikelnr/i, /artikelnummer/i, /item no/i],
      maskSetting: "maskItemNo",
      generic: "aktuell artikel"
    },
    {
      role: "LocationCode",
      patterns: [/lagerplatskod/i, /lagerplats/i, /location code/i],
      maskSetting: "maskLocationCode",
      generic: "aktuell lagerplats"
    },
    {
      role: "LotBatchNo",
      patterns: [
        /batchnr/i, /batchnummer/i, /batch no/i,
        /lotnr/i, /lotnummer/i, /lot no/i, /partinr/i
      ],
      maskSetting: "maskLotBatchNo",
      generic: "aktuellt lot-/batchnummer"
    }
  ];

  for (const matcher of matchers) {
    if (matcher.patterns.some(pattern => pattern.test(context))) {
      return {
        valueRole: matcher.role,
        maskSetting: matcher.maskSetting,
        maskByDefault: DEFAULTS[matcher.maskSetting] === true,
        genericValue: matcher.generic
      };
    }
  }

  // Heuristic for a number selected from an order list or opened from an order page.
  if (
    /^\d{4,}$/.test(rawValue) &&
    /(förs\.?order|försäljningsorder|sales order)/i.test(context)
  ) {
    return {
      valueRole: "SalesOrderNo",
      maskSetting: "maskSalesOrderNo",
      maskByDefault: true,
      genericValue: "den försäljningsorder som ska hanteras"
    };
  }

  return {
    valueRole: "Unknown",
    maskSetting: null,
    maskByDefault: false,
    genericValue: ""
  };
}

function instructionValueFor(classification, originalValue, settings) {
  if (!classification?.maskSetting) return originalValue;
  return settings?.[classification.maskSetting] === true
    ? classification.genericValue
    : originalValue;
}

function extractOpenRecordCaption(value) {
  const label = cleanUiCaption(value);
  const match = label.match(/^Open record\s+"([^"]+)"/i);
  return match ? match[1] : "";
}

function extractDatePickerField(value) {
  const label = cleanUiCaption(value);
  const match = label.match(/^Open the date picker for\s+(.+)$/i);
  return match ? cleanUiCaption(match[1]) : "";
}

function semanticActionForCaption(caption, event) {
  const identified = event?.identification?.actionIdentity?.actionType ||
    globalThis.T9BCUIIdentification.identifyAction({ ...event,
      accessibleName: cleanUiCaption(caption) }).actionType;
  if (identified) return identified === "SearchAndOpenPage"
    ? "OpenSearch" : identified;

  if (event?.category === "dialog") return "Dialog";
  if (event?.type === "field-change") return "ChangeField";
  if (event?.category === "navigation") return "Navigate";
  if (event?.category === "selection") return "Select";
  if (event?.category === "action") return "ClickAction";
  return event?.type || "Interaction";
}

function isTechnicalEvent(event) {
  return (
    event.type === "pointer" ||
    event.type === "focus" ||
    event.type === "page-state" ||
    event.category === "lifecycle" ||
    event.category === "technical"
  );
}

function samePage(a, b) {
  return (
    String(a?.pageId || "") === String(b?.pageId || "") &&
    visiblePageCaption(a) === visiblePageCaption(b)
  );
}

function uiStep({
  sourceEvents,
  action,
  pageCaption,
  pageId,
  actionCaption = "",
  fieldCaption = "",
  selectedCaption = "",
  value = "",
  semanticAction = "",
  description,
  screenshot = null,
  importance = "normal"
}) {
  return {
    step: 0,
    sourceEventNos: sourceEvents.map(event => event.eventNo),
    sourceEventIds: [...new Set(sourceEvents.map(event =>
      event.canonicalSourceEventId).filter(Boolean))],
    normalizedEventIds: [...new Set(sourceEvents.flatMap(event =>
      event.normalizedInteraction?.normalizedEventId || []).filter(Boolean))],
    stepGroupIds: [...new Set(sourceEvents.flatMap(event =>
      event.stepGroup?.stepGroupId || []).filter(Boolean))],
    identifications: sourceEvents.map(event => event.identification).filter(Boolean),
    normalizedInteractions: [...new Map(sourceEvents
      .map(event => event.normalizedInteraction).filter(Boolean)
      .map(item => [item.normalizedEventId, item])).values()],
    stepGroups: [...new Map(sourceEvents.map(event => event.stepGroup)
      .filter(Boolean).map(group => [group.stepGroupId, group])).values()],
    inputSources: [...new Set(sourceEvents.map(event => event.inputSource)
      .filter(Boolean))],
    timestamp: sourceEvents[0]?.timestamp || "",
    pageId: String(pageId || ""),
    pageCaption,
    action,
    actionCaption,
    fieldCaption,
    selectedCaption,
    value,
    semanticAction,
    description,
    screenshot,
    importance,
    valueRole: arguments[0].valueRole || "",
    maskByDefault: Boolean(arguments[0].maskByDefault),
    instructionValue: arguments[0].instructionValue ?? "",
    processPattern: arguments[0].processPattern || ""
  };
}

function screenshotFor(events, screenshots) {
  for (let index = events.length - 1; index >= 0; index -= 1) {
    const path = screenshots[events[index].eventNo];
    if (path) return path;
  }
  return null;
}

function buildBusinessSteps(rawEvents, screenshots, settings) {
  const events = rawEvents.filter(event => !isTechnicalEvent(event));
  const steps = [];
  let index = 0;

  while (index < events.length) {
    const event = events[index];
    const next = events[index + 1];
    const next2 = events[index + 2];

    // Search / Tell Me flow. Preserve each visible UI caption.
    if (
      event.type === "click" &&
      /^(Search|Sök)$/i.test(cleanUiCaption(event.label)) &&
      next?.category === "dialog"
    ) {
      const grouped = [event, next];
      let cursor = index + 2;
      let searchFieldCaption = "";
      let searchValue = "";
      let resultCaption = "";
      let navigationEvent = null;

      while (cursor < events.length && cursor <= index + 9) {
        const candidate = events[cursor];

        if (candidate.type === "field-change") {
          const caption = cleanUiCaption(
            candidate.fieldName || candidate.label
          );

          if (/Tell me|Berätta|Sök/i.test(caption)) {
            searchFieldCaption = caption;
            searchValue = String(candidate.value || "");
            grouped.push(candidate);
            cursor += 1;
            continue;
          }
        }

        if (
          candidate.type === "click" &&
          candidate.category === "selection"
        ) {
          resultCaption = globalThis.T9SearchInteractionPresentation
            .visibleResultCaption(candidate.label);
          grouped.push(candidate);
          cursor += 1;
          continue;
        }

        if (candidate.category === "navigation") {
          navigationEvent = candidate;
          grouped.push(candidate);
          cursor += 1;
          break;
        }

        grouped.push(candidate);
        cursor += 1;
      }

      if (navigationEvent) {
        const pageCaption = normalizePageCaptionForDocumentation(visiblePageCaption(navigationEvent), settings);
        const searchCaption = cleanUiCaption(event.label);

        steps.push(uiStep({
          sourceEvents: grouped,
          action: "SearchAndOpen",
          pageCaption,
          pageId: navigationEvent.pageId,
          actionCaption: searchCaption,
          fieldCaption: searchFieldCaption,
          selectedCaption: resultCaption,
          value: searchValue,
          semanticAction: "SearchAndOpenPage",
          processPattern: "SearchAndOpenPage",
          description:
            `Välj **${searchCaption}**, ange ${searchValue || "söktext"} i ` +
            `**${searchFieldCaption || "sökfältet"}** och välj ` +
            `**${resultCaption || pageCaption}**.`,
          screenshot: globalThis.T9SearchInteractionPresentation
            .screenshotForResult(grouped, screenshots),
          importance: "high"
        }));

        index = cursor;
        continue;
      }
    }

    // Repeated changes to the same visible field: keep final value.
    if (event.type === "field-change") {
      const grouped = [event];
      let finalEvent = event;
      let cursor = index + 1;
      const originalCaption = cleanUiCaption(
        event.fieldName || event.label || "fältet"
      );

      while (
        cursor < events.length &&
        cursor <= index + 4 &&
        events[cursor].type === "field-change" &&
        cleanUiCaption(
          events[cursor].fieldName || events[cursor].label
        ) === originalCaption
      ) {
        finalEvent = events[cursor];
        grouped.push(finalEvent);
        cursor += 1;
      }

      const fieldCaption = cleanUiCaption(
        finalEvent.fieldName || finalEvent.label || "fältet"
      );
      const pageCaption = normalizePageCaptionForDocumentation(visiblePageCaption(finalEvent), settings);

      const classification = classifyBusinessValue({
        value: finalEvent.value,
        fieldCaption,
        pageCaption
      });
      const instructionValue = instructionValueFor(
        classification,
        finalEvent.value ?? "",
        settings
      );

      steps.push(uiStep({
        sourceEvents: grouped,
        action: "ChangeField",
        pageCaption,
        pageId: finalEvent.pageId,
        fieldCaption,
        value: finalEvent.value ?? "",
        semanticAction: "ChangeField",
        processPattern: /datum/i.test(fieldCaption) ? "ChangeDate" : "ChangeField",
        description:
          instructionValue !== "" &&
          classification.valueRole !== "Unknown"
            ? `Ange **${instructionValue}** i **${fieldCaption}**.`
            : `Ändra fältet **${fieldCaption}**.`,
        screenshot: screenshotFor(grouped, screenshots),
        valueRole: classification.valueRole,
        maskByDefault: classification.maskByDefault,
        instructionValue
      }));

      index = cursor;
      continue;
    }

    // Open record and following navigation.
    if (
      event.type === "click" &&
      /^Open record/i.test(cleanUiCaption(event.label)) &&
      next?.category === "navigation"
    ) {
      const grouped = [event, next];
      const recordCaption = extractOpenRecordCaption(event.label);
      const pageCaption = normalizePageCaptionForDocumentation(
        visiblePageCaption(next),
        settings
      );

      if (
        next2?.category === "navigation" &&
        String(next2.pageId || "") === String(next.pageId || "")
      ) {
        grouped.push(next2);
      }

      const classification = classifyBusinessValue({
        value: recordCaption,
        pageCaption,
        source: event.label
      });
      const instructionValue = instructionValueFor(
        classification,
        recordCaption,
        settings
      );

      steps.push(uiStep({
        sourceEvents: grouped,
        action: "OpenRecord",
        pageCaption,
        pageId: next.pageId,
        selectedCaption: recordCaption,
        semanticAction: "OpenRecord",
        processPattern: "OpenDocument",
        description: classification.valueRole === "SalesOrderNo" &&
          settings?.maskSalesOrderNo === true
          ? `Öppna **${instructionValue}**.`
          : recordCaption
            ? `Öppna **${instructionValue}**.`
            : `Öppna den aktuella posten.`,
        screenshot: screenshotFor(grouped, screenshots),
        importance: "high",
        valueRole: classification.valueRole,
        maskByDefault: classification.maskByDefault,
        instructionValue
      }));

      index += grouped.length;
      continue;
    }

    // Date picker helper is not a separate instruction.
    if (
      event.type === "click" &&
      extractDatePickerField(event.label)
    ) {
      index += 1;
      continue;
    }

    // Calendar day click is represented by the field change.
    if (
      event.type === "click" &&
      /^\d{1,2},\s+[A-Za-zÅÄÖåäö]+,\s+\d{4}$/i.test(
        cleanUiCaption(event.label)
      )
    ) {
      index += 1;
      continue;
    }

    // Dialog followed by visible Yes/No caption.
    if (
      event.category === "dialog" &&
      next?.type === "click" &&
      /^(Yes|No|Ja|Nej)$/i.test(cleanUiCaption(next.label))
    ) {
      const actionCaption = cleanUiCaption(next.label);
      const pageCaption = normalizePageCaptionForDocumentation(visiblePageCaption(event), settings);
      const grouped = [event, next];

      steps.push(uiStep({
        sourceEvents: grouped,
        action: "ConfirmDialog",
        pageCaption,
        pageId: event.pageId,
        actionCaption,
        semanticAction: semanticActionForCaption(actionCaption, next),
        processPattern: "ConfirmDialog",
        description: `Välj **${actionCaption}** i dialogrutan.`,
        screenshot: screenshotFor(grouped, screenshots),
        importance: "high"
      }));

      index += 2;
      continue;
    }

    // Back is usually navigation noise, but preserve it if it is the only
    // meaningful action before a distinct page navigation.
    if (
      event.type === "click" &&
      /^(Back|Tillbaka)$/i.test(cleanUiCaption(event.label))
    ) {
      if (next?.category === "navigation") {
        const actionCaption = cleanUiCaption(event.label);
        const grouped = [event, next];

        steps.push(uiStep({
          sourceEvents: grouped,
          action: "NavigateBack",
          pageCaption: visiblePageCaption(next),
          pageId: next.pageId,
          actionCaption,
          semanticAction: "NavigateBack",
          description: `Välj **${actionCaption}**.`,
          screenshot: screenshotFor(grouped, screenshots)
        }));

        index += 2;
        continue;
      }

      index += 1;
      continue;
    }

    // Visible action caption wins. Never normalize it.
    if (event.type === "click" && event.category === "action") {
      const actionCaption = cleanUiCaption(event.label);
      const pageCaption = normalizePageCaptionForDocumentation(visiblePageCaption(event), settings);

      if (
        !actionCaption ||
        actionCaption.length > 120 ||
        /^Specifies |^Anger /i.test(actionCaption)
      ) {
        index += 1;
        continue;
      }

      steps.push(uiStep({
        sourceEvents: [event],
        action: "ClickAction",
        pageCaption,
        pageId: event.pageId,
        actionCaption,
        semanticAction: semanticActionForCaption(actionCaption, event),
        processPattern:
          ["ReopenDocument", "ReleaseDocument"].includes(
            semanticActionForCaption(actionCaption, event)
          )
            ? "ChangeDocumentStatus"
            : semanticActionForCaption(actionCaption, event) === "PostDocument"
              ? "PostDocument"
              : "RunAction",
        description: `Välj **${actionCaption}**.`,
        screenshot: screenshotFor([event], screenshots),
        importance:
          /Öppna igen|Reopen|Släpp|Frisläpp|Release|Bokför|Post/i.test(
            actionCaption
          )
            ? "high"
            : "normal"
      }));

      index += 1;
      continue;
    }

    // Visible selected caption wins.
    if (event.type === "click" && event.category === "selection") {
      const selectedCaption = cleanUiCaption(event.label);
      const pageCaption = normalizePageCaptionForDocumentation(visiblePageCaption(event), settings);

      if (selectedCaption) {
        steps.push(uiStep({
          sourceEvents: [event],
          action: "Select",
          pageCaption,
          pageId: event.pageId,
          selectedCaption,
          semanticAction: "Select",
          description: `Välj **${selectedCaption}**.`,
          screenshot: screenshotFor([event], screenshots)
        }));
      }

      index += 1;
      continue;
    }

    // Standalone navigation. Preserve visible page caption.
    if (event.category === "navigation") {
      const grouped = [event];
      let finalEvent = event;
      let cursor = index + 1;

      while (
        cursor < events.length &&
        cursor <= index + 3 &&
        events[cursor].category === "navigation" &&
        samePage(event, events[cursor])
      ) {
        finalEvent = events[cursor];
        grouped.push(finalEvent);
        cursor += 1;
      }

      const pageCaption = normalizePageCaptionForDocumentation(visiblePageCaption(finalEvent), settings);
      const previous = steps.at(-1);

      if (
        previous?.pageCaption !== pageCaption ||
        previous?.action !== "Navigate"
      ) {
        steps.push(uiStep({
          sourceEvents: grouped,
          action: "Navigate",
          pageCaption,
          pageId: finalEvent.pageId,
          semanticAction: "Navigate",
          description: `Öppna sidan **${pageCaption}**.`,
          screenshot: screenshotFor(grouped, screenshots)
        }));
      }

      index = cursor;
      continue;
    }

    // Standalone dialog.
    if (event.category === "dialog") {
      const pageCaption = normalizePageCaptionForDocumentation(visiblePageCaption(event), settings);

      steps.push(uiStep({
        sourceEvents: [event],
        action: "Dialog",
        pageCaption,
        pageId: event.pageId,
        semanticAction: "Dialog",
        description: `Kontrollera dialogrutan.`,
        screenshot: screenshotFor([event], screenshots)
      }));

      index += 1;
      continue;
    }

    index += 1;
  }

  // Deduplicate semantic output without changing visible captions.
  const deduplicated = [];

  for (const step of steps) {
    const signature = JSON.stringify([
      step.action,
      step.pageCaption,
      step.actionCaption,
      step.fieldCaption,
      step.selectedCaption,
      step.value,
      step.description
    ]);

    if (deduplicated.at(-1)?._signature === signature) continue;

    step._signature = signature;
    deduplicated.push(step);
  }

  return deduplicated.map((step, stepIndex) => {
    const clean = {
      ...step,
      step: stepIndex + 1
    };

    delete clean._signature;
    return clean;
  });
}


function normalizedCaption(value) {
  return String(value || "")
    .replace(/\*\*/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
}

function isConfirmationStep(step) {
  return (
    step.action === "ConfirmDialog" ||
    ["ConfirmYes", "ConfirmNo"].includes(step.semanticAction)
  );
}

function isNavigationStep(step) {
  return ["Navigate", "NavigateBack"].includes(step.action);
}

function isSearchStep(step) {
  return (
    step.action === "SearchAndOpen" ||
    step.semanticAction === "SearchAndOpenPage" ||
    step.processPattern === "SearchAndOpenPage"
  );
}

function isDocumentStatusStep(step) {
  return ["ReopenDocument", "ReleaseDocument"].includes(step.semanticAction);
}

function isPostStep(step) {
  return step.semanticAction === "PostDocument";
}

function isDateFieldStep(step) {
  return (
    step.action === "ChangeField" &&
    /datum|date/i.test(step.fieldCaption || "")
  );
}

function mergeSources(steps) {
  return [...new Set(
    steps.flatMap(step => step.sourceEventNos || [])
  )].sort((a, b) => a - b);
}

function preferredScreenshot(steps) {
  for (let index = steps.length - 1; index >= 0; index -= 1) {
    if (steps[index].screenshot) return steps[index].screenshot;
  }
  return null;
}

function cloneMergedStep(base, consumed, patch = {}) {
  return {
    ...base,
    ...patch,
    sourceEventNos: mergeSources(consumed),
    timestamp: consumed[0]?.timestamp || base.timestamp,
    screenshot: preferredScreenshot(consumed),
    mergedStepCount: consumed.length
  };
}

function sameVisiblePage(a, b) {
  if (!a || !b) return false;
  const aPage = normalizedCaption(a.pageCaption);
  const bPage = normalizedCaption(b.pageCaption);
  if (!aPage || !bPage) return false;
  return aPage === bPage || aPage.includes(bPage) || bPage.includes(aPage);
}

function suppressRedundantNavigation(steps) {
  const result = [];

  for (const step of steps) {
    const previous = result.at(-1);

    if (
      isNavigationStep(step) &&
      previous &&
      (
        sameVisiblePage(previous, step) ||
        (
          ["SearchAndOpen", "OpenRecord"].includes(previous.action) &&
          sameVisiblePage(previous, step)
        )
      )
    ) {
      continue;
    }

    result.push(step);
  }

  return result;
}

function mergeSearchPattern(steps) {
  const result = [];
  let index = 0;

  while (index < steps.length) {
    const current = steps[index];

    if (!isSearchStep(current)) {
      result.push(current);
      index += 1;
      continue;
    }

    const consumed = [current];
    let cursor = index + 1;

    while (
      cursor < steps.length &&
      cursor <= index + 3 &&
      isNavigationStep(steps[cursor]) &&
      sameVisiblePage(current, steps[cursor])
    ) {
      consumed.push(steps[cursor]);
      cursor += 1;
    }

    result.push(cloneMergedStep(current, consumed, {
      action: "SearchAndOpen",
      semanticAction: "SearchAndOpenPage",
      processPattern: "SearchAndOpenPage",
      importance: "high",
      screenshot: current.screenshot
    }));

    index = cursor;
  }

  return result;
}

function mergeOpenDocumentPattern(steps) {
  const result = [];
  let index = 0;

  while (index < steps.length) {
    const current = steps[index];

    if (current.action !== "OpenRecord") {
      result.push(current);
      index += 1;
      continue;
    }

    const consumed = [current];
    let cursor = index + 1;

    while (
      cursor < steps.length &&
      cursor <= index + 3 &&
      isNavigationStep(steps[cursor]) &&
      sameVisiblePage(current, steps[cursor])
    ) {
      consumed.push(steps[cursor]);
      cursor += 1;
    }

    result.push(cloneMergedStep(current, consumed, {
      processPattern: "OpenDocument",
      importance: "high"
    }));

    index = cursor;
  }

  return result;
}

function mergeStatusAndConfirmationPattern(steps) {
  const result = [];
  let index = 0;

  while (index < steps.length) {
    const current = steps[index];

    if (!isDocumentStatusStep(current)) {
      result.push(current);
      index += 1;
      continue;
    }

    const consumed = [current];
    let cursor = index + 1;

    if (
      cursor < steps.length &&
      isConfirmationStep(steps[cursor])
    ) {
      consumed.push(steps[cursor]);
      cursor += 1;
    }

    while (
      cursor < steps.length &&
      cursor <= index + 3 &&
      isNavigationStep(steps[cursor]) &&
      sameVisiblePage(current, steps[cursor])
    ) {
      consumed.push(steps[cursor]);
      cursor += 1;
    }

    result.push(cloneMergedStep(current, consumed, {
      processPattern: "ChangeDocumentStatus",
      description: `Välj **${current.actionCaption}**.`,
      importance: "high",
      confirmationIncluded: consumed.some(isConfirmationStep)
    }));

    index = cursor;
  }

  return result;
}

function mergePostAndConfirmationPattern(steps) {
  const result = [];
  let index = 0;

  while (index < steps.length) {
    const current = steps[index];

    if (!isPostStep(current)) {
      result.push(current);
      index += 1;
      continue;
    }

    const consumed = [current];
    let cursor = index + 1;

    if (
      cursor < steps.length &&
      (
        isConfirmationStep(steps[cursor]) ||
        steps[cursor].action === "Dialog"
      )
    ) {
      consumed.push(steps[cursor]);
      cursor += 1;

      if (
        cursor < steps.length &&
        isConfirmationStep(steps[cursor])
      ) {
        consumed.push(steps[cursor]);
        cursor += 1;
      }
    }

    result.push(cloneMergedStep(current, consumed, {
      processPattern: "PostDocument",
      description: `Välj **${current.actionCaption}**.`,
      importance: "high",
      confirmationIncluded: consumed.some(isConfirmationStep)
    }));

    index = cursor;
  }

  return result;
}

function mergeDatePattern(steps) {
  const result = [];
  let index = 0;

  while (index < steps.length) {
    const current = steps[index];

    if (!isDateFieldStep(current)) {
      result.push(current);
      index += 1;
      continue;
    }

    const consumed = [current];
    let cursor = index + 1;

    while (
      cursor < steps.length &&
      cursor <= index + 2 &&
      (
        steps[cursor].action === "Dialog" ||
        (
          steps[cursor].action === "ClickAction" &&
          /datumvälj|date picker|kalender/i.test(
            steps[cursor].actionCaption || ""
          )
        )
      )
    ) {
      consumed.push(steps[cursor]);
      cursor += 1;
    }

    result.push(cloneMergedStep(current, consumed, {
      processPattern: "ChangeDate",
      description: `Ange **${current.fieldCaption}**.`,
      importance: "normal"
    }));

    index = cursor;
  }

  return result;
}

function removeNonInstructionalFieldChanges(steps) {
  return steps.filter(step => {
    if (step.action !== "ChangeField") return true;

    const caption = normalizedCaption(step.fieldCaption);
    const hasMeaningfulValue =
      step.value !== undefined &&
      step.value !== null &&
      String(step.value).trim() !== "";

    // Typical focus/blur noise on display-name fields.
    if (
      !hasMeaningfulValue &&
      /namn|name|beskrivning|description/i.test(caption)
    ) {
      return false;
    }

    return true;
  });
}

function removeStandaloneConfirmations(steps) {
  return steps.filter((step, index) => {
    if (!isConfirmationStep(step)) return true;

    const previous = steps[index - 1];
    return !(
      previous &&
      (
        isDocumentStatusStep(previous) ||
        isPostStep(previous) ||
        previous.processPattern === "ChangeDocumentStatus" ||
        previous.processPattern === "PostDocument"
      )
    );
  });
}

function removeGenericDialogNoise(steps) {
  return steps.filter((step, index) => {
    if (step.action !== "Dialog") return true;

    const previous = steps[index - 1];
    const next = steps[index + 1];

    if (
      previous &&
      (
        isDocumentStatusStep(previous) ||
        isPostStep(previous) ||
        previous.processPattern === "ChangeDocumentStatus" ||
        previous.processPattern === "PostDocument"
      )
    ) {
      return false;
    }

    if (next && isConfirmationStep(next)) return false;

    return true;
  });
}

function finalDeduplicate(steps) {
  const result = [];

  for (const step of steps) {
    const previous = result.at(-1);
    const signature = JSON.stringify([
      step.action,
      step.semanticAction,
      step.processPattern,
      normalizedCaption(step.pageCaption),
      normalizedCaption(step.actionCaption),
      normalizedCaption(step.fieldCaption),
      normalizedCaption(step.selectedCaption),
      normalizedCaption(step.instructionValue),
      normalizedCaption(step.description)
    ]);

    if (previous?._finalSignature === signature) continue;

    result.push({
      ...step,
      _finalSignature: signature
    });
  }

  return result.map((step, index) => {
    const clean = {
      ...step,
      step: index + 1
    };
    delete clean._finalSignature;
    return clean;
  });
}

function runProcessPatternEngine(initialSteps) {
  let steps = [...initialSteps];

  steps = removeNonInstructionalFieldChanges(steps);
  steps = mergeSearchPattern(steps);
  steps = mergeOpenDocumentPattern(steps);
  steps = mergeStatusAndConfirmationPattern(steps);
  steps = mergePostAndConfirmationPattern(steps);
  steps = mergeDatePattern(steps);
  steps = suppressRedundantNavigation(steps);
  steps = removeStandaloneConfirmations(steps);
  steps = removeGenericDialogNoise(steps);
  steps = finalDeduplicate(steps);

  return steps;
}




const BC_KNOWLEDGE_PACK_VERSION = "1.0";

const BC_ENTITIES = [
  {
    entity: "SalesOrder",
    genericDocument: "den försäljningsorder som ska hanteras"
  },
  {
    entity: "PurchaseOrder",
    genericDocument: "den inköpsorder som ska hanteras"
  },
  {
    entity: "Customer",
    genericDocument: "den kund som ska hanteras"
  },
  {
    entity: "Vendor",
    genericDocument: "den leverantör som ska hanteras"
  },
  {
    entity: "Item",
    genericDocument: "den artikel som ska hanteras"
  },
  {
    entity: "PostedSalesInvoice",
    genericDocument: "den bokförda försäljningsfaktura som ska visas"
  }
];

const BC_ACTION_RULES = [
  {
    ruleId: "ReopenDocument",
    taskType: "ReopenDocument",
    semanticAction: "ReopenDocument",
    confidence: 0.99
  },
  {
    ruleId: "ReleaseDocument",
    taskType: "ReleaseDocument",
    semanticAction: "ReleaseDocument",
    confidence: 0.99
  },
  {
    ruleId: "PostDocument",
    taskType: "PostDocument",
    semanticAction: "PostDocument",
    confidence: 0.99
  },
  {
    ruleId: "OpenSearch",
    taskType: "SearchAndOpenPage",
    semanticAction: "SearchAndOpenPage",
    confidence: 0.98
  }
];

const BC_FIELD_RULES = [
  {
    ruleId: "ChangeShipmentDate",
    fieldSemanticHint: "ShipmentDate",
    taskType: "ChangeShipmentDate",
    semanticAction: "ChangeShipmentDate",
    confidence: 0.99
  },
  {
    ruleId: "SelectCustomer",
    fieldSemanticHint: "Customer",
    taskType: "SelectCustomer",
    semanticAction: "SelectCustomer",
    confidence: 0.90
  },
  {
    ruleId: "SelectItem",
    fieldSemanticHint: "Item",
    taskType: "SelectItem",
    semanticAction: "SelectItem",
    confidence: 0.95
  }
];

function detectEntity(pageCaption, selectedCaption = "") {
  const identity = globalThis.T9BCUIIdentification.identifyPage({
    pageCaption: `${pageCaption || ""} ${selectedCaption || ""}`
  });
  return BC_ENTITIES.find(item => item.entity === identity.entity) || null;
}

function findActionRule(caption) {
  const identity = globalThis.T9BCUIIdentification.identifyAction({
    type: "click", category: "action", accessibleName: cleanUiCaption(caption)
  });
  return BC_ACTION_RULES.find(rule =>
    rule.semanticAction === identity.actionType) || null;
}

function findFieldRule(caption) {
  const identity = globalThis.T9BCUIIdentification.identifyControl({
    type: "field-change", accessibleName: cleanUiCaption(caption)
  });
  return BC_FIELD_RULES.find(rule =>
    rule.fieldSemanticHint === identity.fieldSemanticHint) || null;
}

function documentationProfileName(settings) {
  return settings?.documentationProfile || "generic";
}

function taskInstructionFromKnowledge(task, settings) {
  const profile = documentationProfileName(settings);

  switch (task.taskType) {
    case "OpenSalesOrder":
    case "OpenPurchaseOrder":
    case "OpenCustomer":
    case "OpenVendor":
    case "OpenItem":
    case "OpenPostedSalesInvoice":
      if (
        profile !== "generic" &&
        task.originalRecordValue
      ) {
        return `Öppna **${task.originalRecordValue}**.`;
      }
      return `Öppna **${task.genericDocument}**.`;

    case "ReopenDocument":
    case "ReleaseDocument":
    case "PostDocument":
      return `Välj **${task.actionCaption}**.`;

    case "ChangeShipmentDate":
      return `Ange **${task.fieldCaption}**.`;

    case "SelectCustomer":
      if (task.instructionValue) {
        return `Välj kunden **${task.instructionValue}**.`;
      }
      return `Välj kunden.`;

    case "SelectItem":
      if (task.instructionValue) {
        return `Välj artikeln **${task.instructionValue}**.`;
      }
      return `Välj artikeln.`;

    case "SearchAndOpenPage":
      return task.searchCaption && task.resultCaption
        ? globalThis.T9SearchInteractionPresentation.instruction(task)
        : `Öppna sidan **${task.pageCaption}**.`;

    default:
      return task.instruction || task.description || "Utför uppgiften.";
  }
}

function enrichTaskWithKnowledge(task, settings) {
  const enriched = { ...task };
  const entity = detectEntity(
    task.pageCaption,
    task.selectedCaption || task.originalRecordValue
  );

  const actionRule = findActionRule(task.actionCaption);
  const fieldRule = findFieldRule(task.fieldCaption);

  enriched.knowledgePackVersion = BC_KNOWLEDGE_PACK_VERSION;
  enriched.entity = entity?.entity || "";
  enriched.knowledgeRule = "";
  enriched.confidence = 0.60;
  enriched.reviewSuggested = true;

  if (task.taskType === "OpenDocument" || task.semanticAction === "OpenRecord") {
    if (entity) {
      const openTaskByEntity = {
        SalesOrder: "OpenSalesOrder",
        PurchaseOrder: "OpenPurchaseOrder",
        Customer: "OpenCustomer",
        Vendor: "OpenVendor",
        Item: "OpenItem",
        PostedSalesInvoice: "OpenPostedSalesInvoice"
      };

      enriched.taskType = openTaskByEntity[entity.entity] || "OpenDocument";
      enriched.genericDocument = entity.genericDocument;
      enriched.originalRecordValue =
        task.selectedCaption ||
        task.value ||
        task.instructionValue ||
        "";
      enriched.knowledgeRule = enriched.taskType;
      enriched.confidence = 0.97;
      enriched.reviewSuggested = false;
    }
  } else if (actionRule) {
    enriched.taskType = actionRule.taskType;
    enriched.semanticAction = actionRule.semanticAction;
    enriched.knowledgeRule = actionRule.ruleId;
    enriched.confidence = actionRule.confidence;
    enriched.reviewSuggested = false;
  } else if (fieldRule) {
    enriched.taskType = fieldRule.taskType;
    enriched.semanticAction = fieldRule.semanticAction;
    enriched.knowledgeRule = fieldRule.ruleId;
    enriched.confidence = fieldRule.confidence;
    enriched.reviewSuggested = fieldRule.confidence < 0.90;
  } else if (task.taskType === "SearchAndOpenPage") {
    enriched.knowledgeRule = "SearchAndOpenPage";
    enriched.confidence = 0.98;
    enriched.reviewSuggested = false;
  } else if (task.taskType === "Navigate") {
    enriched.knowledgeRule = "Navigate";
    enriched.confidence = 0.85;
    enriched.reviewSuggested = true;
  }

  enriched.instruction = taskInstructionFromKnowledge(enriched, settings);
  return enriched;
}

function applyKnowledgePack(tasks, settings) {
  return tasks.map(task => enrichTaskWithKnowledge(task, settings));
}

function removeKnowledgePackNoise(tasks) {
  const result = [];

  for (const task of tasks) {
    const previous = result.at(-1);

    if (
      task.taskType === "Navigate" &&
      previous &&
      (
        [
          "SearchAndOpenPage",
          "OpenSalesOrder",
          "OpenPurchaseOrder",
          "OpenCustomer",
          "OpenVendor",
          "OpenItem",
          "OpenPostedSalesInvoice"
        ].includes(previous.taskType) &&
        sameVisiblePage(previous, task)
      )
    ) {
      continue;
    }

    // A field focus on Kundens namn without an actual value is not a manual step.
    if (
      ["SelectCustomer", "ChangeField"].includes(task.taskType) &&
      /kundens namn|customer name/i.test(task.fieldCaption || "") &&
      !String(task.value ?? "").trim()
    ) {
      continue;
    }

    // Confirmation dialogs are included in status/posting tasks.
    if (
      ["Dialog", "ConfirmDialog"].includes(task.taskType) &&
      previous &&
      [
        "ReopenDocument",
        "ReleaseDocument",
        "PostDocument"
      ].includes(previous.taskType)
    ) {
      previous.confirmationIncluded = true;
      previous.sourceEventNos = [
        ...new Set([
          ...(previous.sourceEventNos || []),
          ...(task.sourceEventNos || [])
        ])
      ];
      Object.assign(previous, canonicalTrace(previous, task));
      previous.screenshot = task.screenshot || previous.screenshot;
      continue;
    }

    // Keep only one shipment-date task.
    if (
      task.taskType === "ChangeShipmentDate" &&
      previous?.taskType === "ChangeShipmentDate"
    ) {
      result[result.length - 1] = {
        ...task,
        ...canonicalTrace(previous, task),
        sourceEventNos: [
          ...new Set([
            ...(previous.sourceEventNos || []),
            ...(task.sourceEventNos || [])
          ])
        ],
        screenshot: task.screenshot || previous.screenshot
      };
      continue;
    }

    result.push(task);
  }

  return result;
}

function finalizeKnowledgeTasks(tasks, settings) {
  const enriched = applyKnowledgePack(tasks, settings);
  const cleaned = removeKnowledgePackNoise(enriched);

  return cleaned.map((task, index) => ({
    ...task,
    taskNo: index + 1,
    taskId: stableTaskId(task, index),
    instruction: taskInstructionFromKnowledge(task, settings),
    reviewStatus: task.reviewSuggested ? "review-suggested" : "unreviewed"
  }));
}


function taskId(taskType, index) {
  return `${taskType}-${String(index + 1).padStart(3, "0")}`;
}

function canonicalTrace(...values) {
  const merged = globalThis.T9SourceReference.merge(...values);
  delete merged.legacyEventNos;
  return merged;
}

function stableTaskId(task, index) {
  const semanticActionIds = task.semanticActionModel?.actionId
    ? [task.semanticActionModel.actionId] : task.semanticActionIds;
  const identity = globalThis.T9SourceReference.stableIdentity({
    sourceEventIds: task.sourceEventIds,
    normalizedEventIds: task.normalizedEventIds,
    stepGroupIds: task.stepGroupIds || (task.stepGroups || [])
      .map(group => group.stepGroupId),
    semanticActionIds
  }, "");
  return identity ? `${task.taskType}:${identity}` : taskId(task.taskType, index);
}

function taskInstruction(task) {
  switch (task.taskType) {
    case "SearchAndOpenPage":
      return task.searchCaption && task.resultCaption
        ? globalThis.T9SearchInteractionPresentation.instruction(task)
        : `Öppna sidan **${task.pageCaption}**.`;

    case "OpenDocument":
      return task.instructionValue
        ? `Öppna **${task.instructionValue}**.`
        : `Öppna det dokument som ska hanteras.`;

    case "ChangeDocumentStatus":
      return `Välj **${task.actionCaption}**.`;

    case "ChangeDate":
      return `Ange **${task.fieldCaption}**.`;

    case "ChangeField":
      return task.instructionValue
        ? `Ange **${task.instructionValue}** i **${task.fieldCaption}**.`
        : `Ändra fältet **${task.fieldCaption}**.`;

    case "PostDocument":
      return `Välj **${task.actionCaption}**.`;

    case "RunAction":
      return `Välj **${task.actionCaption}**.`;

    case "Select":
      return `Välj **${task.selectedCaption}**.`;

    case "Navigate":
      return `Öppna sidan **${task.pageCaption}**.`;

    case "Dialog":
      return `Kontrollera dialogrutan.`;

    default:
      return task.description || "Utför uppgiften.";
  }
}

function createBusinessTasks(businessSteps) {
  const tasks = [];

  for (const step of businessSteps) {
    const taskType =
      step.processPattern ||
      (
        step.semanticAction === "SearchAndOpenPage"
          ? "SearchAndOpenPage"
          : step.semanticAction === "OpenRecord"
            ? "OpenDocument"
            : step.semanticAction === "ReopenDocument" ||
              step.semanticAction === "ReleaseDocument"
              ? "ChangeDocumentStatus"
              : step.semanticAction === "PostDocument"
                ? "PostDocument"
                : step.action === "ChangeField"
                  ? (/datum|date/i.test(step.fieldCaption || "") ? "ChangeDate" : "ChangeField")
                  : step.action === "Select"
                    ? "Select"
                    : step.action === "Navigate"
                      ? "Navigate"
                      : step.action === "Dialog"
                        ? "Dialog"
                        : step.action === "ClickAction"
                          ? "RunAction"
                          : "Unclassified"
      );

    const task = {
      taskId: "",
      taskNo: 0,
      taskType,
      semanticAction: step.semanticAction || "",
      processPattern: step.processPattern || "",
      pageId: step.pageId || "",
      pageCaption: step.pageCaption || "",
      actionCaption: step.actionCaption || "",
      fieldCaption: step.fieldCaption || "",
      selectedCaption: step.selectedCaption || "",
      value: step.value ?? "",
      valueRole: step.valueRole || "",
      instructionValue: step.instructionValue ?? "",
      maskByDefault: Boolean(step.maskByDefault),
      searchCaption:
        step.action === "SearchAndOpen"
          ? step.actionCaption || ""
          : "",
      searchFieldCaption:
        step.action === "SearchAndOpen"
          ? step.fieldCaption || ""
          : "",
      resultCaption:
        step.action === "SearchAndOpen"
          ? step.selectedCaption || ""
          : "",
      sourceStepNos: [step.step],
      sourceEventNos: step.sourceEventNos || [],
      sourceEventIds: step.sourceEventIds || [],
      normalizedEventIds: step.normalizedEventIds || [],
      stepGroupIds: step.stepGroupIds || (step.stepGroups || [])
        .map(group => group.stepGroupId),
      semanticActionIds: step.semanticActionModel?.actionId
        ? [step.semanticActionModel.actionId] : step.semanticActionIds || [],
      identifications: step.identifications || [],
      normalizedInteractions: step.normalizedInteractions || [],
      stepGroups: step.stepGroups || [],
      inputSources: step.inputSources || [],
      screenshot: step.screenshot || null,
      importance: step.importance || "normal",
      confirmationIncluded: Boolean(step.confirmationIncluded),
      reviewStatus: "unreviewed",
      userComment: "",
      description: step.description || ""
    };

    task.instruction = taskInstruction(task);
    tasks.push(task);
  }

  return tasks.map((task, index) => ({
    ...task,
    instruction: globalThis.T9TextFormat.quoteEmphasis(task.instruction),
    taskId: stableTaskId(task, index),
    taskNo: index + 1
  }));
}

function mergeAdjacentBusinessTasks(tasks) {
  const result = [];
  let index = 0;

  while (index < tasks.length) {
    const current = tasks[index];
    const next = tasks[index + 1];

    // Search/open page followed immediately by redundant Navigate to same page.
    if (
      current.taskType === "SearchAndOpenPage" &&
      next?.taskType === "Navigate" &&
      sameVisiblePage(current, next)
    ) {
      result.push({
        ...current,
        ...canonicalTrace(current, next),
        sourceStepNos: [
          ...new Set([
            ...(current.sourceStepNos || []),
            ...(next.sourceStepNos || [])
          ])
        ],
        sourceEventNos: [
          ...new Set([
            ...(current.sourceEventNos || []),
            ...(next.sourceEventNos || [])
          ])
        ],
        screenshot: current.screenshot || next.screenshot
      });
      index += 2;
      continue;
    }

    // Open document followed immediately by redundant Navigate.
    if (
      current.taskType === "OpenDocument" &&
      next?.taskType === "Navigate" &&
      sameVisiblePage(current, next)
    ) {
      result.push({
        ...current,
        ...canonicalTrace(current, next),
        sourceStepNos: [
          ...new Set([
            ...(current.sourceStepNos || []),
            ...(next.sourceStepNos || [])
          ])
        ],
        sourceEventNos: [
          ...new Set([
            ...(current.sourceEventNos || []),
            ...(next.sourceEventNos || [])
          ])
        ],
        screenshot: next.screenshot || current.screenshot
      });
      index += 2;
      continue;
    }

    // Consecutive ChangeDate tasks for the same field collapse to one.
    if (
      current.taskType === "ChangeDate" &&
      next?.taskType === "ChangeDate" &&
      normalizedCaption(current.fieldCaption) ===
        normalizedCaption(next.fieldCaption)
    ) {
      result.push({
        ...next,
        ...canonicalTrace(current, next),
        sourceStepNos: [
          ...new Set([
            ...(current.sourceStepNos || []),
            ...(next.sourceStepNos || [])
          ])
        ],
        sourceEventNos: [
          ...new Set([
            ...(current.sourceEventNos || []),
            ...(next.sourceEventNos || [])
          ])
        ],
        screenshot: next.screenshot || current.screenshot
      });
      index += 2;
      continue;
    }

    // Status action followed by confirmation-only task.
    if (
      current.taskType === "ChangeDocumentStatus" &&
      next &&
      (
        next.taskType === "Dialog" ||
        next.semanticAction === "ConfirmYes" ||
        next.semanticAction === "ConfirmNo"
      )
    ) {
      result.push({
        ...current,
        confirmationIncluded: true,
        ...canonicalTrace(current, next),
        sourceStepNos: [
          ...new Set([
            ...(current.sourceStepNos || []),
            ...(next.sourceStepNos || [])
          ])
        ],
        sourceEventNos: [
          ...new Set([
            ...(current.sourceEventNos || []),
            ...(next.sourceEventNos || [])
          ])
        ],
        screenshot: next.screenshot || current.screenshot
      });
      index += 2;
      continue;
    }

    // Post followed by dialog/confirmation.
    if (
      current.taskType === "PostDocument" &&
      next &&
      (
        next.taskType === "Dialog" ||
        next.semanticAction === "ConfirmYes" ||
        next.semanticAction === "ConfirmNo"
      )
    ) {
      result.push({
        ...current,
        confirmationIncluded: true,
        ...canonicalTrace(current, next),
        sourceStepNos: [
          ...new Set([
            ...(current.sourceStepNos || []),
            ...(next.sourceStepNos || [])
          ])
        ],
        sourceEventNos: [
          ...new Set([
            ...(current.sourceEventNos || []),
            ...(next.sourceEventNos || [])
          ])
        ],
        screenshot: next.screenshot || current.screenshot
      });
      index += 2;
      continue;
    }

    result.push(current);
    index += 1;
  }

  return result.map((task, taskIndex) => ({
    ...task,
    taskNo: taskIndex + 1,
    taskId: stableTaskId(task, taskIndex),
    instruction: taskInstruction(task)
  }));
}

function removeNonManualTasks(tasks) {
  return tasks.filter(task => {
    if (task.taskType === "Unclassified") return false;
    if (task.taskType === "Navigate") return false;
    if (task.taskType === "NavigateBack") return false;
    if (task.semanticAction === "ConfirmYes") return false;
    if (task.semanticAction === "ConfirmNo") return false;

    if (
      task.taskType === "Dialog" &&
      !task.actionCaption &&
      !task.selectedCaption
    ) {
      return false;
    }

    if (
      task.taskType === "ChangeField" &&
      !task.fieldCaption
    ) {
      return false;
    }

    return true;
  });
}

function calculateTaskQuality(tasks) {
  if (!tasks.length) return 0;

  let score = 0;

  for (const task of tasks) {
    let taskScore = 40;

    if (task.taskType !== "Unclassified") taskScore += 25;
    if (task.instruction) taskScore += 15;
    if (
      task.pageCaption ||
      task.actionCaption ||
      task.fieldCaption ||
      task.selectedCaption
    ) {
      taskScore += 10;
    }
    if (task.screenshot) taskScore += 10;

    score += Math.min(taskScore, 100);
  }

  return Math.round(score / tasks.length);
}

function runBusinessTaskEngine(businessSteps) {
  let tasks = createBusinessTasks(businessSteps);
  tasks = mergeAdjacentBusinessTasks(tasks);
  tasks = removeNonManualTasks(tasks);

  return {
    tasks,
    quality: calculateTaskQuality(tasks)
  };
}

function createTaskDocumentationMarkdown(session, tasks, quality) {
  const profile =
    PROFILE_PRESETS[session.settings?.documentationProfile || "generic"]
      ?.label || "Generisk manual";
  const explanationLabels = {
    "sv-SE": "Vad åtgärden innebär",
    "en-US": "What this action does",
    "fr-FR": "Ce que fait cette action",
    "de-DE": "Was diese Aktion bewirkt",
    "es-ES": "Qué hace esta acción",
    "da-DK": "Hvad handlingen gør",
    "fi-FI": "Mitä toiminto tekee",
    "nb-NO": "Hva handlingen gjør"
  };
  const sourceLabels = {
    "sv-SE": "Källa", "en-US": "Source", "fr-FR": "Source",
    "de-DE": "Quelle", "es-ES": "Fuente", "da-DK": "Kilde",
    "fi-FI": "Lähde", "nb-NO": "Kilde"
  };
  const documentLanguage = globalThis.T9LanguageRegistry.normalize(
    session.settings?.documentLanguage, "document");
  const explanationLabel = explanationLabels[documentLanguage] ||
    explanationLabels["en-US"];

  function explanationMarkdown(task) {
    if (!(Number(task.contextualExplanationConfidence) >= 0.85) ||
        !task.contextualExplanationRuleId) return "";
    const explanation = task.contextualExplanations?.[documentLanguage] ||
      task.contextualExplanations?.["en-US"] || "";
    if (!explanation) return "";
    const sourceIds = new Set(task.contextualExplanationSourceIds || []);
    const sources = loadedKnowledgePacks.flatMap(pack => pack.sources || [])
      .filter(source => sourceIds.has(source.sourceId));
    if (!sources.some(source => /^https:\/\/learn\.microsoft\.com\//i
      .test(source.sourceUri || ""))) return "";
    const localePrefix = `/${documentLanguage.toLowerCase()}/`;
    const source = sources.find(item => item.sourceUri?.includes(localePrefix)) ||
      sources.find(item => item.sourceUri?.includes("/en-us/")) || sources[0];
    const citation = source?.sourceUri
      ? ` *(${sourceLabels[documentLanguage] || sourceLabels["en-US"]}: [Microsoft Learn](${source.sourceUri}))*` : "";
    return `\n\n   **${explanationLabel}:** ${explanation}${citation}`;
  }

  const rendered = tasks.map(task => {
    const image = task.screenshot
      ? `\n\n   ![${task.instruction.replace(/\*\*/g, "")}](${task.screenshot})`
      : "";

    return `${task.taskNo}. ${task.instruction}${explanationMarkdown(task)}${image}`;
  }).join("\n\n");

  return `# ${session.name}

## Dokumentationstyp

${profile}

## Syfte

${session.purpose || "Syfte har inte angetts."}

## Förutsättningar

- Användaren har behörighet till berörda sidor och åtgärder.
- Processen genomförs med korrekta grunddata.
- Benämningar på sidor, fält och åtgärder återges exakt som de visades i Business Central.
- Känsliga värden hanteras enligt vald dokumentationsprofil.

## Arbetsgång

${rendered || "Inga dokumenterbara affärsuppgifter kunde identifieras."}

## Förväntat resultat

Processen är genomförd enligt arbetsgången.

## Kvalitet

Dokumentationskvalitet: **${quality} %**

---
Genererad av BC Process Studio 4.7.6.
`;
}


function createDocumentationMarkdown(session, businessSteps) {
  const rendered = businessSteps.map(step => {
    const image = step.screenshot
      ? `\n\n   ![${step.description.replace(/\*\*/g, "")}](${step.screenshot})`
      : "";

    return `${step.step}. ${step.description}${image}`;
  }).join("\n\n");

  return `# ${session.name}

## Syfte

${session.purpose || "Syfte har inte angetts."}

## Dokumentationstyp

${PROFILE_PRESETS[session.settings?.documentationProfile || "generic"]?.label || "Generisk manual"}

## Förutsättningar

- Användaren har behörighet till berörda sidor och åtgärder.
- Processen genomförs med korrekta grunddata.
- Benämningar på sidor, fält och åtgärder återges exakt som de visades i Business Central vid inspelningen.
- Känsliga affärsvärden kan vara maskerade.

## Arbetsgång

${rendered || "Inga meningsfulla arbetssteg kunde identifieras."}

## Förväntat resultat

Processen är genomförd och de registrerade ändringarna har sparats i Business Central.

---
Automatiskt tolkat av BC Process Studio 4.7.6.
`;
}

function createDiagnostics(session, rawEvents, businessSteps, screenshotCount) {
  const rawTypeCounts = {};
  for (const event of rawEvents) {
    rawTypeCounts[event.type] = (rawTypeCounts[event.type] || 0) + 1;
  }

  const semanticActionCounts = {};
  for (const step of businessSteps) {
    semanticActionCounts[step.semanticAction] =
      (semanticActionCounts[step.semanticAction] || 0) + 1;
  }

  return {
    recorderVersion: "4.7.6",
    uiFidelityMode: true,
    sessionId: session.id,
    environment: session.settings?.environmentName || "",
    rawEventCount: rawEvents.length,
    firstPassStepCount: arguments[4] || businessSteps.length,
    businessStepCount: businessSteps.length,
    patternReductionPercent: (arguments[4] || businessSteps.length)
      ? Math.round(
          (1 - businessSteps.length / (arguments[4] || businessSteps.length)) * 100
        )
      : 0,
    noiseReductionPercent: rawEvents.length
      ? Math.round((1 - businessSteps.length / rawEvents.length) * 100)
      : 0,
    screenshotCount,
    rawTypeCounts,
    semanticActionCounts,
    valueRoleCounts: businessSteps.reduce((counts, step) => {
      const role = step.valueRole || "None";
      counts[role] = (counts[role] || 0) + 1;
      return counts;
    }, {}),
    maskingSettings: session.settings || {},
    documentationProfile:
      session.settings?.documentationProfile || "generic",
    processPatternCounts: businessSteps.reduce((counts, step) => {
      const pattern = step.processPattern || "Unclassified";
      counts[pattern] = (counts[pattern] || 0) + 1;
      return counts;
    }, {}),
    recognizedPatternCount: businessSteps.filter(
      step => Boolean(step.processPattern)
    ).length,
    documentationQuality: (() => {
      if (!businessSteps.length) return 0;
      const recognized = businessSteps.filter(
        step => Boolean(step.processPattern)
      ).length;
      const captionComplete = businessSteps.filter(
        step =>
          step.pageCaption &&
          (
            step.actionCaption ||
            step.fieldCaption ||
            step.selectedCaption ||
            ["Navigate", "OpenRecord"].includes(step.action)
          )
      ).length;
      const score =
        (recognized / businessSteps.length) * 60 +
        (captionComplete / businessSteps.length) * 40;
      return Math.round(score);
    })(),
    pages: [...new Map(
      businessSteps.map(step => [
        `${step.pageId}|${step.pageCaption}`,
        {
          pageId: step.pageId,
          pageCaption: step.pageCaption
        }
      ])
    ).values()],
    exportedAt: new Date().toISOString()
  };
}

async function loadSettings() {
  try {
    await loadKnowledgePacks();
  } catch (error) {
    console.warn("Knowledge Packs could not be loaded.", error);
  }

  const response = await send({ type: "T9_GET_SETTINGS" });
  const settings = {
    ...DEFAULTS,
    ...(response?.settings || {})
  };
  applicationSettings = { ...settings };
  globalThis.T9UiI18n.apply(settings.uiLocale);
  globalThis.T9UiI18n.observe(() => applicationSettings.uiLocale);

  for (const [key, value] of Object.entries(settings)) {
    const element = $(key);
    if (!element) continue;

    if (typeof value === "boolean") {
      element.checked = value;
    } else if (
      value !== undefined &&
      value !== null
    ) {
      element.value = value;
    }
  }
  if (settings.supportEmail && $("supportEmailStatus")) {
    $("supportEmailStatus").textContent = globalThis.T9UiI18n.translateStaticText(
      "Sparad", settings.uiLocale);
    $("supportEmailStatus").classList.add("saved");
  }

  const documentationProfile = $("documentationProfile");
  if (documentationProfile) {
    documentationProfile.value = settings.documentationProfile ||
      DEFAULTS.documentationProfile || "generic";
  }

  applyProfile(
    documentationProfile?.value || DEFAULTS.documentationProfile || "generic",
    false
  );
  updateFilenamePreview();
}

async function saveSettings() {
  const settings = {
    ...DEFAULTS,
    documentationProfile: $("documentationProfile").value
  };

  for (const key of Object.keys(DEFAULTS)) {
    const element = $(key);
    if (!element) continue;

    settings[key] =
      element.type === "checkbox"
        ? element.checked
        : element.type === "number"
          ? Number(element.value)
          : element.value;
  }

  const response = await send({
    type: "T9_SAVE_SETTINGS",
    settings
  });

  applicationSettings = { ...settings, ...(response?.settings || {}) };

  show(globalThis.T9UiI18n.translate("settings.saved", settings.uiLocale));
}

async function testKnowledgeMcpConnection() {
  const button = $("testKnowledgeMcp");
  const status = $("knowledgeMcpStatus");
  button.disabled = true;
  status.textContent = uiT("settings.knowledgeMcpChecking");
  try {
    if ($("knowledgeMcpEnabled").checked !== applicationSettings.knowledgeMcpEnabled) {
      await saveSettings();
    }
    if (!applicationSettings.knowledgeMcpEnabled) {
      status.textContent = uiT("settings.knowledgeMcpConsentRequired");
      return;
    }
    const response = await send({ type: "T9_TEST_KNOWLEDGE_MCP_CONNECTION" });
    if (response?.ok) {
      status.textContent = uiTf("settings.knowledgeMcpConnected", { count: response.toolCount });
    } else {
      const detail = String(response?.detail || "").replace(/[\u0000-\u001f]+/gu, " ").trim().slice(0, 240);
      status.textContent = `${uiT("settings.knowledgeMcpUnavailable")}${detail
        ? ` ${uiTf("settings.knowledgeMcpFailureDetail", { detail })}` : ""}`;
    }
  } catch (error) {
    const detail = String(error?.message || error || "").replace(/[\u0000-\u001f]+/gu, " ").trim().slice(0, 240);
    status.textContent = `${uiT("settings.knowledgeMcpUnavailable")}${detail
      ? ` ${uiTf("settings.knowledgeMcpFailureDetail", { detail })}` : ""}`;
  } finally {
    button.disabled = false;
  }
}

async function testKnowledgeMcpSampleLookup() {
  const button = $("testKnowledgeMcpSampleLookup");
  const status = $("knowledgeMcpSampleLookupStatus");
  button.disabled = true;
  status.textContent = uiT("settings.knowledgeMcpSampleChecking");
  try {
    if ($("knowledgeMcpEnabled").checked !== applicationSettings.knowledgeMcpEnabled) {
      await saveSettings();
    }
    if (!applicationSettings.knowledgeMcpEnabled) {
      status.textContent = uiT("settings.knowledgeMcpSampleConsentRequired");
      return;
    }
    const response = await send({ type: "T9_TEST_KNOWLEDGE_MCP_SAMPLE_LOOKUP" });
    if (!response?.ok) {
      const detail = String(response?.detail || "").replace(/[\u0000-\u001f]+/gu, " ").trim().slice(0, 240);
      status.textContent = uiT("settings.knowledgeMcpUnavailable") + (detail
        ? " " + uiTf("settings.knowledgeMcpFailureDetail", { detail }) : "");
      return;
    }
    const result = response.result;
    const candidate = result?.candidates?.[0];
    if (result?.status === "suggested" && candidate?.objectRef) {
      const source = (candidate.provenance?.sourceId || "unknown") + "@" + (candidate.provenance?.sourceVersion || "unknown");
      status.textContent = uiTf("settings.knowledgeMcpSampleFound", {
        count: result.candidates.length,
        objectId: candidate.objectRef.objectId,
        source,
        confidence: Math.round(Number(candidate.confidence || 0) * 100)
      });
    } else {
      status.textContent = uiTf("settings.knowledgeMcpSampleUnresolved", { objectId: "22" });
    }
  } catch (error) {
    const detail = String(error?.message || error || "").replace(/[\u0000-\u001f]+/gu, " ").trim().slice(0, 240);
    status.textContent = uiT("settings.knowledgeMcpUnavailable") + (detail
      ? " " + uiTf("settings.knowledgeMcpFailureDetail", { detail }) : "");
  } finally {
    button.disabled = false;
  }
}
async function saveSupportEmail() {
  const input = $("supportEmail");
  const status = $("supportEmailStatus");
  input.value = input.value.trim();
  status.classList.remove("saved");
  if (!input.reportValidity()) return;
  try {
    await saveSettings();
    status.textContent = globalThis.T9UiI18n.translateStaticText(
      "Supportadressen har sparats.", applicationSettings.uiLocale);
    status.classList.add("saved");
  } catch (error) {
    status.textContent = error.message || String(error);
  }
}

async function changeUiLocale(event) {
  const previousLocale = applicationSettings.uiLocale;
  const uiLocale = globalThis.T9UiI18n.normalizeLocale(event.target.value);
  globalThis.T9UiI18n.apply(uiLocale);
  applicationSettings = { ...applicationSettings, uiLocale };
  try {
    const response = await send({ type: "T9_SAVE_UI_LOCALE", uiLocale });
    if (!response?.ok) throw new Error(response?.error || "Language could not be saved.");
    applicationSettings = { ...applicationSettings, uiLocale: response.uiLocale };
  } catch (error) {
    applicationSettings = { ...applicationSettings, uiLocale: previousLocale };
    event.target.value = previousLocale;
    globalThis.T9UiI18n.apply(previousLocale);
    show(error.message, true);
  }
}


function interpretLegacyCompatibility(input) {
  const filteredEvents = globalThis.T9Engine?.noiseFilter
    ? globalThis.T9Engine.noiseFilter.filter(input.events || [])
    : input.events || [];
  const contextEvents = buildContextEvents(filteredEvents);
  const contextCandidates = createContextCandidates(contextEvents);
  const interpretedSteps = buildBusinessSteps(contextEvents, input.imagePaths || {},
    input.session?.settings || DEFAULTS);
  const businessSteps = runProcessPatternEngine(interpretedSteps);
  const taskResult = runBusinessTaskEngine(businessSteps);
  const contextByEventNo = new Map(contextEvents.map(event =>
    [event.eventNo, event.context || {}]));
  const legacyTasks = finalizeKnowledgeTasks(taskResult.tasks,
    input.session?.settings || DEFAULTS).map(task => {
    const contexts = (task.sourceEventNos || []).map(eventNo =>
      contextByEventNo.get(eventNo)).filter(Boolean);
    return { ...task, context: contexts.find(value => value.currentEntity) ||
      contexts[0] || {}, automationId: task.automationId || "" };
  });
  const businessTasks = applyKnowledgePackFramework(legacyTasks,
    input.session?.settings || DEFAULTS).map((task, index) => ({ ...task,
    taskNo: index + 1, taskId: stableTaskId(task, index) }));
  const entityNodes = globalThis.T9Engine?.entityMemory
    ? globalThis.T9Engine.entityMemory.build(contextEvents) : [];
  const sessionGraph = globalThis.T9Engine?.sessionGraph
    ? globalThis.T9Engine.sessionGraph.build(input.session, businessTasks,
      entityNodes) : { nodes: [], edges: [] };
  const confidenceResult = globalThis.T9Engine?.confidence
    ? globalThis.T9Engine.confidence.evaluate(businessTasks, sessionGraph)
    : { tasks: businessTasks, sessionConfidence: calculateTaskQuality(businessTasks),
      knowledgeMatchPercent: 0, graphCoveragePercent: 0,
      reviewSuggestedCount: 0 };
  return { contextEvents, contextCandidates, interpretedSteps, businessSteps,
    businessTasks: confidenceResult.tasks, sessionGraph, confidenceResult,
    unmatchedKnowledgeItems: [] };
}

async function fetchExternalKnowledgeSuggestions(tasks) {
  if (!applicationSettings.knowledgeMcpEnabled ||
      !globalThis.T9KnowledgeMcpWorkflow) return { enabled: false,
        status: "disabled", requestCount: 0, suggestions: [] };
  const requests = globalThis.T9KnowledgeMcpWorkflow.buildRequests(
    tasks, applicationSettings.uiLocale, 40);
  if (!requests.length) return { enabled: true, status: "no-unresolved",
    requestCount: 0, suggestions: [] };
  try {
    const response = await send({ type: "T9_LOOKUP_KNOWLEDGE_MCP_BATCH",
      lookups: requests.map(({ key, kind, request }) => ({ key, kind, request })) });
    if (!response?.ok) return { enabled: true, status: "unavailable",
      requestCount: requests.length, suggestions: [] };
    const suggestions = globalThis.T9KnowledgeMcpWorkflow.collectSuggestions(
      requests, response.results);
    return { enabled: true,
      status: suggestions.length ? "suggestions" : "no-suggestions",
      requestCount: requests.length, suggestions };
  } catch {
    return { enabled: true, status: "unavailable",
      requestCount: requests.length, suggestions: [] };
  }
}

async function prepareSessionModel(session, options = {}) {
  const response = await send({
    type: "T9_GET_SESSION_DATA",
    sessionId: session.id,
    includeScreenshots: true
  });

  if (!response.ok) {
    throw new Error(response.error || "Sessionen kunde inte läsas.");
  }

  const imagePaths = {};
  const screenshotData = {};

  for (const [eventNo, dataUrl] of Object.entries(response.screenshots || {})) {
    imagePaths[eventNo] =
      `screenshots/${String(eventNo).padStart(6, "0")}.png`;
    screenshotData[imagePaths[eventNo]] = dataUrl;
  }

  const model = globalThis.T9SessionInterpretationPipeline.interpret({
    session: response.session, events: response.events,
    normalizedEvents: response.normalizedEvents, stepGroups: response.stepGroups,
    supportingEvents: response.supportingEvents,
    groupingDiagnostics: response.groupingDiagnostics,
    imagePaths, knowledgePacks: loadedKnowledgePacks,
    knowledgeRepository: loadedKnowledgeRepository,
    knowledgeReleaseId: loadedKnowledgeRelease?.releaseId || null
  }, { entityMemory: globalThis.T9Engine?.entityMemory,
    sessionGraph: globalThis.T9Engine?.sessionGraph,
    confidence: globalThis.T9Engine?.confidence,
    compatibilityInterpret: interpretLegacyCompatibility });
  const canonicalProcess = response.recording
    ? globalThis.BCProcessAdapter.normalizeProcess({
      recording: response.recording,
      interpretation: model,
      normalizedEvents: response.normalizedEvents,
      stepGroups: response.stepGroups,
      normalizerVersion: response.normalizedEvents?.[0]?.normalizationVersion ||
        globalThis.T9EventNormalization.NORMALIZATION_VERSION,
      knowledgeReleaseId: loadedKnowledgeRelease?.releaseId || null
    }) : null;
  const canonicalKnowledgeResolutions = canonicalProcess?.ok && loadedKnowledgeRepository
    ? canonicalProcess.process.steps.map(step => ({ stepId: step.stepId,
      object: loadedKnowledgeRepository.lookupObject(step.target.objectRef || {},
        loadedKnowledgeRelease?.releaseId),
      control: loadedKnowledgeRepository.resolveControl({
        objectRef: step.target.objectRef || {}, controlRef: step.target.controlRef || {},
        releaseId: loadedKnowledgeRelease?.releaseId }),
      action: loadedKnowledgeRepository.resolveAction({
        objectRef: step.target.objectRef || {}, controlRef: step.target.controlRef || {},
        context: { pageCaption: step.target.capturedCaption || "",
          actionCaption: step.observation.operation || "" }
      }, loadedKnowledgeRelease?.releaseId) })) : [];
  unmatchedKnowledgeItems = model.unmatchedKnowledgeItems;
  const externalKnowledgeTasks = model.businessTasks.map((task, index) => {
    const step = canonicalProcess?.process.steps[index];
    const localResolution = canonicalKnowledgeResolutions[index];
    return { ...task,
      knowledgeObjectRef: task.knowledgeObjectRef?.objectId
        ? task.knowledgeObjectRef : step?.target.objectRef || {},
      knowledgeControlRef: task.knowledgeControlRef?.controlId ||
        task.knowledgeControlRef?.automationId ? task.knowledgeControlRef
        : step?.target.controlRef || {},
      knowledgeResolution: task.knowledgeResolution || {
        object: localResolution?.object || { status: "unresolved" },
        action: localResolution?.action || { status: "unresolved" }
      },
      pageCaption: task.pageCaption || step?.target.capturedCaption || "",
      actionCaption: task.actionCaption || step?.observation.operation || ""
    };
  });
  const externalKnowledgeLookup = options.includeExternalKnowledge
    ? await fetchExternalKnowledgeSuggestions(externalKnowledgeTasks)
    : { enabled: false, status: "disabled", requestCount: 0, suggestions: [] };

  return {
    response,
    imagePaths,
    screenshotData,
    canonicalProcess,
    canonicalKnowledgeResolutions,
    externalKnowledgeLookup,
    ...model
  };
}

async function exportSession(session) {
  show(`Förbereder export av "${session.name}"...`);

  const response = await send({
    type: "T9_GET_SESSION_DATA",
    sessionId: session.id,
    includeScreenshots: true
  });

  if (!response.ok) {
    throw new Error(response.error || "Sessionen kunde inte läsas.");
  }

  const imagePaths = {};
  const imageFiles = [];

  for (const [eventNo, dataUrl] of Object.entries(response.screenshots || {})) {
    const path = `screenshots/${String(eventNo).padStart(6, "0")}.png`;
    imagePaths[eventNo] = path;
    imageFiles.push({
      name: path,
      data: dataUrlBytes(dataUrl)
    });
  }

  const model = globalThis.T9SessionInterpretationPipeline.interpret({
    session: response.session, events: response.events,
    normalizedEvents: response.normalizedEvents, stepGroups: response.stepGroups,
    supportingEvents: response.supportingEvents,
    groupingDiagnostics: response.groupingDiagnostics,
    imagePaths, knowledgePacks: loadedKnowledgePacks
  }, { entityMemory: globalThis.T9Engine?.entityMemory,
    sessionGraph: globalThis.T9Engine?.sessionGraph,
    confidence: globalThis.T9Engine?.confidence,
    compatibilityInterpret: interpretLegacyCompatibility });
  unmatchedKnowledgeItems = model.unmatchedKnowledgeItems;
  const { contextEvents, contextCandidates, interpretedSteps, businessSteps,
    sessionGraph, confidenceResult } = model;
  const finalBusinessTasks = model.businessTasks;
  const knowledgeQuality = confidenceResult.sessionConfidence;
  const diagnostics = createDiagnostics(
    response.session,
    response.events,
    businessSteps,
    imageFiles.length,
    interpretedSteps.length
  );

  diagnostics.businessTaskCount = finalBusinessTasks.length;
  diagnostics.businessTaskQuality = knowledgeQuality;
  diagnostics.knowledgePackVersion = "2.0.0";
  diagnostics.knowledgeFrameworkVersion = KNOWLEDGE_PACK_FRAMEWORK_VERSION;
  diagnostics.loadedKnowledgePacks = loadedKnowledgePacks.map(pack => ({
    packId: pack.packId,
    name: pack.name,
    version: pack.version,
    ruleCount: (pack.rules || []).length
  }));
  diagnostics.loadedKnowledgeRuleCount = loadedKnowledgeRules.length;
  diagnostics.unmatchedKnowledgeCount = unmatchedKnowledgeItems.length;
  diagnostics.contextBuilderVersion = CONTEXT_BUILDER_VERSION;
  diagnostics.contextEventCount = contextEvents.length;
  diagnostics.contextCandidateCount = contextCandidates.length;
  diagnostics.contextEntityCounts = contextEvents.reduce(
    (counts, event) => {
      const entity = event.context?.currentEntity || "Unknown";
      counts[entity] = (counts[entity] || 0) + 1;
      return counts;
    },
    {}
  );
  diagnostics.knowledgeRuleCounts = finalBusinessTasks.reduce(
    (counts, task) => {
      const rule = task.knowledgeRule || "Unmatched";
      counts[rule] = (counts[rule] || 0) + 1;
      return counts;
    },
    {}
  );
  diagnostics.reviewSuggestedCount = finalBusinessTasks.filter(
    task => task.reviewSuggested
  ).length;
  diagnostics.businessTaskTypeCounts = finalBusinessTasks.reduce(
    (counts, task) => {
      counts[task.taskType] = (counts[task.taskType] || 0) + 1;
      return counts;
    },
    {}
  );

  const folder = safeFileName(session.name);
  const prefix = `${folder}/`;

  const files = [
    {
      name: `${prefix}session.json`,
      data: bytes(JSON.stringify(response.session, null, 2))
    },
    {
      name: `${prefix}events.json`,
      data: bytes(JSON.stringify(
        response.events.map(event => {
          const copy = { ...event };
          delete copy.signature;
          return copy;
        }),
        null,
        2
      ))
    },
    {
      name: `${prefix}business-steps.json`,
      data: bytes(JSON.stringify(businessSteps, null, 2))
    },
    {
      name: `${prefix}session-graph.json`,
      data: bytes(JSON.stringify(sessionGraph, null, 2))
    },
    {
      name: `${prefix}confidence-report.json`,
      data: bytes(JSON.stringify({
        sessionConfidence: confidenceResult.sessionConfidence,
        knowledgeMatchPercent: confidenceResult.knowledgeMatchPercent,
        graphCoveragePercent: confidenceResult.graphCoveragePercent,
        reviewSuggestedCount: confidenceResult.reviewSuggestedCount
      }, null, 2))
    },
    {
      name: `${prefix}business-tasks.json`,
      data: bytes(JSON.stringify(finalBusinessTasks, null, 2))
    },
    {
      name: `${prefix}diagnostics.json`,
      data: bytes(JSON.stringify(diagnostics, null, 2))
    },
    {
      name: `${prefix}documentation.md`,
      data: bytes(
        createTaskDocumentationMarkdown(
          response.session,
          finalBusinessTasks,
          knowledgeQuality
        )
      )
    },
    {
      name: `${prefix}context-events.json`,
      data: bytes(JSON.stringify(contextEvents, null, 2))
    },
    {
      name: `${prefix}context-candidates.json`,
      data: bytes(JSON.stringify(contextCandidates, null, 2))
    },
    {
      name: `${prefix}knowledge-pack-summary.json`,
      data: bytes(JSON.stringify({
        frameworkVersion: KNOWLEDGE_PACK_FRAMEWORK_VERSION,
        packs: loadedKnowledgePacks.map(pack => ({
          packId: pack.packId,
          name: pack.name,
          version: pack.version,
          ruleCount: (pack.rules || []).length
        })),
        totalRuleCount: loadedKnowledgeRules.length
      }, null, 2))
    },
    {
      name: `${prefix}unmatched-knowledge.json`,
      data: bytes(JSON.stringify({
        count: unmatchedKnowledgeItems.length,
        contextCandidates,
        items: unmatchedKnowledgeItems
      }, null, 2))
    },
    {
      name: `${prefix}knowledge-pack.json`,
      data: bytes(JSON.stringify({
        version: BC_KNOWLEDGE_PACK_VERSION,
        entities: BC_ENTITIES.map(entity => ({
          entity: entity.entity,
          genericDocument: entity.genericDocument
        })),
        actionRules: BC_ACTION_RULES.map(rule => ({
          ruleId: rule.ruleId,
          taskType: rule.taskType,
          semanticAction: rule.semanticAction,
          confidence: rule.confidence
        })),
        fieldRules: BC_FIELD_RULES.map(rule => ({
          ruleId: rule.ruleId,
          taskType: rule.taskType,
          semanticAction: rule.semanticAction,
          confidence: rule.confidence
        }))
      }, null, 2))
    },
    {
      name: `${prefix}quality-report.json`,
      data: bytes(JSON.stringify({
        documentationQuality: knowledgeQuality,
        knowledgePackVersion: BC_KNOWLEDGE_PACK_VERSION,
        reviewSuggestedCount: diagnostics.reviewSuggestedCount,
        knowledgeMatchedCount: finalBusinessTasks.filter(
          task => task.knowledgeMatched
        ).length,
        knowledgeMatchPercent: finalBusinessTasks.length
          ? Math.round(
              finalBusinessTasks.filter(task => task.knowledgeMatched).length /
              finalBusinessTasks.length * 100
            )
          : 0,
        unmatchedKnowledgeCount: unmatchedKnowledgeItems.length,
        contextCandidateCount: contextCandidates.length,
        contextEntityCounts: diagnostics.contextEntityCounts,
        knowledgeRuleCounts: diagnostics.knowledgeRuleCounts,
        businessTaskCount: finalBusinessTasks.length,
        businessTaskTypeCounts: diagnostics.businessTaskTypeCounts,
        rawEventCount: diagnostics.rawEventCount,
        firstPassStepCount: diagnostics.firstPassStepCount,
        businessStepCount: diagnostics.businessStepCount,
        noiseReductionPercent: diagnostics.noiseReductionPercent,
        patternReductionPercent: diagnostics.patternReductionPercent,
        recognizedPatternCount: diagnostics.recognizedPatternCount,
        processPatternCounts: diagnostics.processPatternCounts,
        recommendation:
          diagnostics.documentationQuality >= 85
            ? "Redo för granskning"
            : diagnostics.documentationQuality >= 65
              ? "Granska oklassificerade steg"
              : "Spela in processen igen eller komplettera regler"
      }, null, 2))
    },
    {
      name: `${prefix}ui-fidelity.json`,
      data: bytes(JSON.stringify({
        version: "4.7.6",
        principle: "Visible Business Central captions are preserved exactly.",
        rules: [
          "actionCaption is the text shown on the action or button.",
          "fieldCaption is the text shown beside the field.",
          "pageCaption is the visible page title captured during recording.",
          "semanticAction is separate metadata and must not replace the UI caption.",
          "AI output must preserve actionCaption, fieldCaption and pageCaption verbatim."
        ],
        dataPolicy: {
          transactionNumbers: "Masked by default",
          masterData: "Preserved by default",
          environmentData: "Removed from documentation by default"
        }
      }, null, 2))
    },
    ...loadedKnowledgePacks.map(pack => ({
      name: `${prefix}knowledge-packs/${pack.packId}.json`,
      data: bytes(JSON.stringify(pack, null, 2))
    })),
    ...imageFiles.map(file => ({
      name: `${prefix}${file.name}`,
      data: file.data
    }))
  ];

  const blob = zip(files);
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");

  link.href = url;
  link.download = `${safeFileName(session.id)}.zip`;
  link.click();

  setTimeout(() => URL.revokeObjectURL(url), 60000);
  show(`ZIP-export skapad i UI Fidelity-läge: ${response.events.length} råhändelser blev ${businessSteps.length} arbetssteg och ${imageFiles.length} bilder.`);
}




function currentFilenamePreviewSession() {
  return activeReviewModel?.response?.session ||
    activeReviewSession ||
    { name: "Business Central-process", settings: {} };
}

function currentFilenamePreviewSettings() {
  return {
    ...DEFAULTS,
    exportFileNamePattern:
      $("exportFileNamePattern")?.value ||
      DEFAULTS.exportFileNamePattern,
    environmentName:
      $("environmentName")?.value ||
      DEFAULTS.environmentName,
    companyName:
      $("companyName")?.value ||
      DEFAULTS.companyName
  };
}

function updateFilenamePreview(
  session = currentFilenamePreviewSession(),
  settings = currentFilenamePreviewSettings()
) {
  const input = $("exportFileNamePattern");
  const preview = $("filenamePreview");
  const validation = $("filenameValidation");
  if (!input || !preview || !validation) return "";

  return globalThis.T9Engine.exportSettings.updatePreview(
    { input, preview, validation },
    session,
    settings
  );
}

function insertFilenameVariable(variable) {
  const input = $("exportFileNamePattern");
  if (!input) return;
  globalThis.T9Engine.exportSettings.insertVariable(input, variable);
  input.dispatchEvent(new Event("input", { bubbles: true }));
}

function initializeFilenameVariables() {
  globalThis.T9Engine.exportSettings.renderVariableControls(
    $("filenameVariables"),
    $("filenameVariableHelp"),
    insertFilenameVariable
  );
}

async function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);

  try {
    const response = await send({
      type: "T9_DOWNLOAD_FILE",
      url,
      filename
    });

    if (!response.ok) {
      throw new Error(response.error || "Filen kunde inte sparas.");
    }

    return response.downloadId;
  } finally {
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  }
}

function dataUrlToImageData(dataUrl) {
  if (!dataUrl) return null;

  const headerEnd = dataUrl.indexOf(",");
  if (headerEnd < 0) return null;

  const header = dataUrl.slice(0, headerEnd);
  const mimeMatch = header.match(/^data:([^;]+)/i);
  const mimeType = mimeMatch?.[1]?.toLowerCase() || "";
  const base64 = dataUrl.slice(headerEnd + 1);
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);

  for (let index = 0; index < binary.length; index += 1) {
    bytes[index] = binary.charCodeAt(index);
  }

  return {
    bytes,
    mimeType
  };
}

function imageDataToDataUrl(imageData) {
  if (!imageData?.bytes) return "";
  let binary = "";
  const chunkSize = 8192;
  for (let offset = 0; offset < imageData.bytes.length; offset += chunkSize) {
    binary += String.fromCharCode(...imageData.bytes.subarray(
      offset,
      offset + chunkSize
    ));
  }
  return `data:${imageData.mimeType || "image/png"};base64,${btoa(binary)}`;
}

function createActiveDocumentPipeline() {
  if (!activeReviewModel || !activeReview) {
    throw new Error("Dokumentet är inte tillgängligt ännu.");
  }
  const expectedResult = configuredExpectedResult();
  const documentLanguage = activeDocumentLanguage();
  const preparedPresentation = createActiveDocumentPresentation();
  const reviewWithKnowledgeExplanations = reviewForKnowledgeExport(activeReview);
  return activeDocumentPipelineCache.get([
    activeReviewModel,
    activeReview,
    workspaceState.revision,
    activeDocumentProfileId,
    activeDocumentThemeId(),
    expectedResult,
    documentLanguage
  ], () => globalThis.T9WordExportPipeline.create({
      session: activeReviewModel.response.session,
      review: reviewWithKnowledgeExplanations,
      expectedResult,
      documentLanguage,
      preparedPresentation,
      screenshotCandidates: screenshotCandidatesFor(activeReviewModel, activeReview),
      profileId: activeDocumentProfileId,
      themeId: activeDocumentThemeId()
    }));
}

function createActiveDocumentPresentation() {
  if (!activeReviewModel || !activeReview) {
    throw new Error("Dokumentet är inte tillgängligt ännu.");
  }
  const expectedResult = configuredExpectedResult();
  const documentLanguage = activeDocumentLanguage();
  const reviewWithKnowledgeExplanations = reviewForKnowledgeExport(activeReview);
  return activeDocumentPresentationCache.get([
    activeReviewModel,
    activeReview,
    workspaceState.revision,
    activeDocumentProfileId,
    expectedResult,
    documentLanguage
  ], () => globalThis.T9WordExportPipeline.createPresentation({
      session: activeReviewModel.response.session,
      review: reviewWithKnowledgeExplanations,
      expectedResult,
      documentLanguage,
      profileId: activeDocumentProfileId
    }));
}

function reviewForKnowledgeExport(review) {
  if (!review || !activeReviewModel?.businessTasks?.length) return review;
  const enriched = globalThis.T9ProcessTaskContext.enrichForDisplay(
    review.tasks || [], activeReviewModel.businessTasks
  );
  const optionsByTaskId = new Map((review.tasks || []).map(task =>
    [task.taskId, task.includeKnowledgeExplanationInWord === true]));
  return { ...review, tasks: enriched.map(task => ({ ...task,
    includeKnowledgeExplanationInWord: optionsByTaskId.get(task.taskId) === true
  })) };
}

function configuredExpectedResult(settings = applicationSettings) {
  return String(settings?.defaultExpectedResult || "").trim() ||
    globalThis.T9ReviewDocumentProjector.DEFAULT_EXPECTED_RESULT;
}

function activeDocumentLanguage() {
  return globalThis.T9LanguageRegistry.normalize(
    activeReview?.documentFields?.documentLanguage, "document"
  );
}

function displayedExpectedResult() {
  const stored = String(activeReview?.documentFields?.expectedResult || "").trim();
  if (stored) return stored;
  return globalThis.T9DocumentLanguage.systemText(
    configuredExpectedResult(),
    activeDocumentLanguage()
  );
}

function screenshotCandidatesFor(model, review) {
  return globalThis.T9ScreenshotIntelligence.fromEvents({
    events: model?.contextEvents || [],
    imagePaths: model?.imagePaths || {},
    tasks: review?.tasks || []
  });
}

async function composeDocumentMedia(pipeline, review, screenshotSources) {
  return composeDocumentMediaForTarget(
    pipeline, review, screenshotSources, dataUrlToImageData
  );
}

async function composeDocumentWorkspaceMedia(
  pipeline,
  review,
  screenshotSources
) {
  return composeDocumentMediaForTarget(
    pipeline, review, screenshotSources, source => source
  );
}

async function composeDocumentMediaForTarget(
  pipeline,
  review,
  screenshotSources,
  convertOriginal
) {
  const requiredAssetIds = new Set(
    globalThis.T9WordExportPipeline.requiredMediaAssetIds(pipeline.plan)
  );
  const screenshotAssets = pipeline.semanticDocument.assets.filter(asset =>
    asset.kind === "image" && requiredAssetIds.has(asset.assetId) &&
    asset.sourceRef?.screenshotRef
  );
  const screenshotPaths = [...new Set(screenshotAssets.map(
    asset => asset.sourceRef.screenshotRef
  ))];
  const composedScreenshots = await globalThis.T9ReviewAnnotationCompositor
    .composeReview({
      review,
      paths: screenshotPaths,
      screenshotSources: screenshotSources || {},
      convertOriginal
    });
  return Object.fromEntries(screenshotAssets.map(asset => [
    asset.assetId,
    composedScreenshots[asset.sourceRef.screenshotRef]
  ]));
}

async function prepareDocumentMedia(pipeline) {
  return composeDocumentMedia(
    pipeline, activeReview, activeReviewModel?.screenshotData
  );
}

async function exportLibraryDocument(record, exportSettings) {
  const session = documentLibrarySessions.get(record.projectId);
  if (!session || session.status === "recording") {
    throw new Error(`Dokumentet "${record.title}" kan inte exporteras.`);
  }
  if (session.recordingPurpose === "bug-report" ||
      record.metadata?.recordingPurpose === "bug-report") {
    throw new Error(
      `Felrapporten "${record.title}" exporteras från Technical Report Workspace.`
    );
  }
  const model = await prepareSessionModel(session);
  const existing = await send({ type: "T9_GET_REVIEW", sessionId: session.id });
  const review = existing.review
    ? globalThis.T9Review.normalizeReview({
      ...existing.review,
      tasks: globalThis.T9Review.normalizeTasks(existing.review.tasks)
    })
    : globalThis.T9Review.createReview(session, model.businessTasks);
  const themeId = globalThis.T9DocumentThemeRegistry.get(
    globalThis.T9DocumentThemeRegistry.BUILT_IN_REGISTRY,
    record.theme.themeId
  ) ? record.theme.themeId : "thinknine";
  const pipeline = globalThis.T9WordExportPipeline.create({
    session: model.response.session,
    review,
    expectedResult: configuredExpectedResult(exportSettings),
    screenshotCandidates: screenshotCandidatesFor(model, review),
    profileId: record.profile.profileId,
    themeId
  });
  const mediaAssets = await composeDocumentMedia(
    pipeline, review, model.screenshotData
  );
  globalThis.T9WordExportPipeline.validateMedia(pipeline.plan, mediaAssets);
  const result = await globalThis.T9Export.word.renderPlan({
    plan: pipeline.plan,
    mediaAssets
  });
  const filename = globalThis.T9Engine.exportSettings.buildFileName(
    "docx", model.response.session, exportSettings
  );
  await downloadBlob(result.blob, filename);
  return result;
}

async function exportActiveReviewToWord() {
  if (!activeReviewSession || !activeReview) {
    throw new Error("Ingen granskning är öppen.");
  }

  if (!globalThis.T9Export?.word?.renderPlan ||
      !globalThis.T9WordExportPipeline) {
    throw new Error(
      "Word-exportbiblioteket kunde inte laddas. Kör npm install och npm run build."
    );
  }

  if (!activeReviewModel) {
    activeReviewModel = await prepareSessionModel(
      activeReviewSession
    );
  }

  const pipeline = createActiveDocumentPipeline();
  const mediaAssets = await prepareDocumentMedia(pipeline);
  globalThis.T9WordExportPipeline.validateMedia(
    pipeline.plan,
    mediaAssets
  );
  const result = await globalThis.T9Export.word.renderPlan({
    plan: pipeline.plan,
    mediaAssets
  });

  const settingsResponse = await send({
    type: "T9_GET_SETTINGS"
  });
  const exportSettings = {
    ...DEFAULTS,
    ...(settingsResponse?.settings || {})
  };
  const filename = updateFilenamePreview(
    activeReviewModel.response.session,
    exportSettings
  );

  await downloadBlob(result.blob, filename);

  show(
    `Word-dokument skapat med docx-biblioteket: ` +
    `${result.taskCount} steg och ${result.imageCount} skärmbilder.`
  );
}

let activeReviewSession = null;
let activeReview = null;
let activeReviewModel = null;
let activeProcessModel = null;
let activeProcessBaseModel = null;
let selectedProcessMapNodeId = null;
let processMapDraftOverrides = [];
let activeProcessAnalysis = null;
let processAnalysisRequest = null;
let activeProcessMapLevel = "businessCentral";
let processMapIncludeReferences = false;
let processMapResizeFrame = null;
const PROCESS_MAP_ZOOM_STORAGE_KEY = "t9.processMap.zoom";
const PROCESS_MAP_DIRECTION_STORAGE_KEY = "t9.processMap.direction";
const PROCESS_MAP_THEME_STORAGE_KEY = "t9.processMap.theme";
const PROCESS_MAP_DENSITY_STORAGE_KEY = "t9.processMap.density";
function normalizedProcessMapDensity(value) {
  return value === "compact" ? "compact" : "standard";
}
function normalizedProcessMapDirection(value) {
  return value === "vertical" ? "vertical" : "adaptive";
}
function loadProcessMapZoom() {
  try {
    return globalThis.T9ProcessMapViewport.normalize(
      globalThis.localStorage?.getItem(PROCESS_MAP_ZOOM_STORAGE_KEY)
    );
  } catch {
    return 100;
  }
}
let processMapZoom = loadProcessMapZoom();
function loadProcessMapDirection() {
  try {
    return normalizedProcessMapDirection(
      globalThis.localStorage?.getItem(PROCESS_MAP_DIRECTION_STORAGE_KEY)
    );
  } catch {
    return "adaptive";
  }
}
let processMapDirection = loadProcessMapDirection();
function loadProcessMapTheme() {
  try {
    return globalThis.T9ProcessMapTheme.normalize(
      globalThis.localStorage?.getItem(PROCESS_MAP_THEME_STORAGE_KEY)
    );
  } catch {
    return globalThis.T9ProcessMapTheme.DEFAULT_THEME_ID;
  }
}
let processMapTheme = loadProcessMapTheme();
function loadProcessMapDensity() {
  try {
    return normalizedProcessMapDensity(
      globalThis.localStorage?.getItem(PROCESS_MAP_DENSITY_STORAGE_KEY)
    );
  } catch {
    return "standard";
  }
}
let processMapDensity = loadProcessMapDensity();
let processMapFocusReturn = null;
let processMapSearchCursor = -1;
function setProcessMapFocus(active) {
  const disclosure = $("processOverviewDisclosure");
  const button = $("processMapFocus");
  const enabled = Boolean(active);
  if (enabled) {
    processMapFocusReturn = document.activeElement;
    disclosure.open = true;
  }
  disclosure.classList.toggle("process-map-focus", enabled);
  document.body.classList.toggle("process-map-focus-active", enabled);
  button.setAttribute("aria-pressed", String(enabled));
  renderProcessOverview();
  if (enabled) $("processOverview").querySelector("[data-process-node-action]")?.focus();
  else processMapFocusReturn?.focus?.();
}
let activeReviewSelection = globalThis.T9ReviewSelection.create();
let activeReviewEdit = null;
let reviewReturnFocus = null;
let reviewLayoutState = globalThis.T9ReviewLayout.create();
const REVIEW_ZOOM_STORAGE_KEY = "t9.reviewWorkspace.zoom";
const REVIEW_ZOOM_MIN = 50;
const REVIEW_ZOOM_MAX = 200;
const REVIEW_ZOOM_STEP = 10;
function normalizedReviewZoom(value) {
  if (value === null || value === undefined || value === "") return 100;
  const numeric = Number(value);
  const rounded = Number.isFinite(numeric)
    ? Math.round(numeric / REVIEW_ZOOM_STEP) * REVIEW_ZOOM_STEP
    : 100;
  return Math.max(REVIEW_ZOOM_MIN, Math.min(REVIEW_ZOOM_MAX, rounded));
}
function loadReviewZoom() {
  try {
    return normalizedReviewZoom(
      globalThis.localStorage?.getItem(REVIEW_ZOOM_STORAGE_KEY)
    );
  } catch {
    return 100;
  }
}
let reviewZoom = loadReviewZoom();
let annotationEditorState = null;
let annotationChangesPending = false;
let annotationEditorBaseline = null;
let workspaceState = globalThis.T9WorkspaceController.create();
let documentWorkspaceSync = null;
const activeDocumentPipelineCache = globalThis.T9WorkspaceController
  .createRevisionCache();

function processAnalysisLabels() {
  const english = String(applicationSettings.uiLocale || "").startsWith("en");
  return english ? {
    locale: "en-US",
    detected: "Detected reference process", unknownDomain: "Domain not identified",
    match: "match", confirmedConfidence: "manually confirmed",
    matchDegree: "Classification confidence", confirmed:
      "Classification confirmed manually", matched: "Matched", missing: "Possible missing",
    conditional: "Conditional", additional: "Customer-specific", advisory: "Differences are guidance, not errors. " +
      "The recorded process may be a valid customer variant.", matchedSteps: "Matched steps",
    missingSteps: "Possible missing steps", conditionalSteps: "Configuration-dependent reference steps",
    referenceComparison: "Compare with other Business Central configurations",
    referenceComparisonHelp: "These reference steps were not observed in the recording and are not included in the process map.",
    additionalSteps: "Customer-specific steps", noConditional: "No configuration-dependent steps",
    none: "None", noMissing: "No expected steps are missing", noAdditional: "No additional steps",
    alternatives: "Alternative reference processes", noAlternatives: "No relevant alternatives",
    noMatchTitle: "No reliable process match", noMatchText:
      "The recording remains valid and can be classified manually later.",
    "auto-classifiable": "Strong process evidence", "review-required": "Needs confirmation",
    "insufficient-evidence": "Insufficient process evidence", "manual-confirmed": "Manually selected process",
    confirmationRecommended:
      "Confirm the classification before using it.", strongEvidence:
      "The classification is supported by several independent signals.",
    configurationVariant: "Business Central configuration", variantUncertain:
      "Several configurations fit the recording. Other configuration steps are available in the reference comparison.",
    variantSupported: "The observed sequence supports this configuration variant.",
    variantConfirmed: "This configuration was selected manually and now controls the process map.",
    variantAlternatives: "Other possible configurations", mostLikely: "Most likely",
    evidenceTitle: "Why this assessment?", evidenceDocuments: "Business Central documents",
    evidenceActions: "Business actions", evidenceQuality: "Evidence quality",
    actionQualifiers: { shipment: "shipment", receipt: "receipt", invoice: "invoice",
      pick: "pick", "put-away": "put-away", assembly: "assembly",
      consumption: "consumption", output: "output", transfer: "transfer" },
    observedPrecision: "Observed steps fit", referenceCoverage: "Reference process covered",
    candidateMargin: "Lead over next candidate", percentagePoints: "percentage points",
    evidenceNone: "None detected", "quality-strong": "Strong", "quality-moderate": "Moderate",
    "quality-weak": "Weak"
  } : {
    locale: "sv-SE",
    detected: "Identifierad referensprocess", unknownDomain: "Domän inte identifierad",
    match: "matchning", confirmedConfidence: "manuellt bekräftad",
    matchDegree: "Klassificeringssäkerhet", confirmed:
      "Klassificeringen är manuellt bekräftad", matched: "Matchade", missing: "Möjligen saknade",
    conditional: "Villkorliga", additional: "Kundunika", advisory: "Skillnader är vägledning, inte fel. " +
      "Den inspelade processen kan vara en giltig kundvariant.", matchedSteps: "Matchade steg",
    missingSteps: "Möjligen saknade steg", conditionalSteps: "Konfigurationsberoende referenssteg",
    referenceComparison: "Jämför med andra Business Central-konfigurationer",
    referenceComparisonHelp: "Dessa referenssteg observerades inte i inspelningen och tas inte med i processkartan.",
    additionalSteps: "Kundunika steg", noConditional: "Inga konfigurationsberoende steg",
    none: "Inga", noMissing: "Inga förväntade steg saknas", noAdditional: "Inga extra steg",
    alternatives: "Alternativa referensprocesser", noAlternatives: "Inga relevanta alternativ",
    noMatchTitle: "Ingen säker processmatchning", noMatchText:
      "Inspelningen är fortfarande giltig och kan klassificeras manuellt senare.",
    "auto-classifiable": "Starkt processunderlag", "review-required": "Behöver bekräftas",
    "insufficient-evidence": "Otillräckligt processunderlag", "manual-confirmed": "Manuellt vald process",
    confirmationRecommended:
      "Bekräfta klassificeringen innan den används.", strongEvidence:
      "Klassificeringen stöds av flera oberoende signaler.",
    configurationVariant: "Business Central-konfiguration", variantUncertain:
      "Flera konfigurationer passar inspelningen. Andra konfigurationssteg finns i referensjämförelsen.",
    variantSupported: "Den observerade sekvensen stöder denna konfigurationsvariant.",
    variantConfirmed: "Konfigurationen valdes manuellt och styr nu processkartan.",
    variantAlternatives: "Andra möjliga konfigurationer", mostLikely: "Mest sannolik",
    evidenceTitle: "Varför denna bedömning?", evidenceDocuments: "Business Central-dokument",
    evidenceActions: "Affärsåtgärder", evidenceQuality: "Underlagskvalitet",
    actionQualifiers: { shipment: "leverans", receipt: "inleverans", invoice: "faktura",
      pick: "plockning", "put-away": "inlagring", assembly: "montering",
      consumption: "förbrukning", output: "utflöde", transfer: "överföring" },
    observedPrecision: "Träff på observerade steg", referenceCoverage: "Täckning av referensprocess",
    candidateMargin: "Försprång till nästa kandidat", percentagePoints: "procentenheter",
    evidenceNone: "Inget identifierat", "quality-strong": "Starkt",
    "quality-moderate": "Måttligt", "quality-weak": "Svagt",
    variantNames: {
      "variant:no-warehouse": "Utan lagerhantering",
      "variant:basic-warehouse": "Grundläggande lagerhantering",
      "variant:advanced-warehouse": "Avancerad lagerhantering",
      "variant:direct-shipment": "Direktleverans",
      "variant:drop-shipment": "Direktleverans från leverantör",
      "variant:standard-return": "Standardretur",
      "variant:make-to-stock": "Tillverkning mot lager",
      "variant:make-to-order": "Tillverkning mot order"
    }, processNames: {
        "Source to Pay": "Inköp till betalning", "domain:source-to-pay": "Inköp till betalning",
        "Purchase to Pay": "Inköp till betalning",
        "Simple Purchase Order": "Enkel inköpsorder", "Warehouse Inbound": "Lagerinleverans",
        "Purchase Receipt and Invoice": "Inköpsinleverans och faktura",
        "Advanced Warehouse Inbound": "Avancerad lagerinleverans",
        "Get Source Documents": "Hämta källdokument",
        "Post Warehouse Receipt": "Bokför lagerinleverans",
        "Transfer Order": "Överföringsorder", "Inventory Transfer": "Lageröverföring",
        "Item Transfer": "Artikelöverföring", "Create Transfer Order": "Skapa överföringsorder",
        "Post Transfer Shipment": "Bokför överföringsutleverans",
        "Post Transfer Receipt": "Bokför överföringsinleverans",
        "Assembly Order": "Monteringsorder", "Production Order": "Produktionsorder",
        "Production Consumption": "Produktionsförbrukning",
        "Production Output": "Produktionsutflöde",
        "Production with Warehouse Picking": "Produktion med lagerplockning",
        "Production with Warehouse Put-away": "Produktion med lagerinlagring",
        "Make to Stock": "Tillverkning mot lager", "Make to Order": "Tillverkning mot order",
        "Planning Worksheet": "Planeringsförslag", "Warehouse Movement": "Lagerförflyttning",
        "Planning Supply Options": "Planeringens försörjningsalternativ",
        "Create Purchase Orders": "Skapa inköpsorder",
        "Create Production Orders": "Skapa produktionsorder",
        "Create Transfer Orders": "Skapa överföringsorder",
        "Review Action Messages": "Granska åtgärdsmeddelanden",
        "Accept Action Message": "Acceptera åtgärdsmeddelande",
        "Sales Order": "Försäljningsorder", "Simple Sales Order": "Enkel försäljningsorder",
        "Purchase Order": "Inköpsorder", "Warehouse Receipt": "Lagerinleverans",
        "Warehouse Put-away": "Lagerinlagring",
        "document:purchase-order": "Inköpsorder",
        "document:purchase-invoice": "Inköpsfaktura",
        "document:posted-purchase-invoice": "Bokförd inköpsfaktura",
        "Create": "Skapa", "Release": "Frisläpp", "Receive": "Ta emot",
        "Invoice": "Fakturera", "Post": "Bokför", "Unknown step": "Okänt steg",
        "Inventory Movement": "Lagerflyttning", "Assembly to Stock": "Montering mot lager",
        "Sales Returns": "Försäljningsreturer", "Purchase Returns": "Inköpsreturer",
        "Warehouse Movement": "Lagerförflyttning", "Item Tracking": "Artikelspårning",
        "Lot Tracking": "Partispårning", "Serial Tracking": "Serienummerspårning",
        "Expiration Date Handling": "Hantering av utgångsdatum",
        "Assign Lot Number": "Tilldela partinummer",
        "Assign Serial Number": "Tilldela serienummer",
        "Enter Expiration Date": "Ange utgångsdatum",
        "Post Tracked Transaction": "Bokför spårad transaktion",
        "General Journal Posting": "Bokföring av redovisningsjournal",
        "Item Adjustment": "Lagerjustering", "Item Reclassification": "Artikelomklassificering",
        "Physical Inventory": "Inventering",
        "document:sales-return-order": "Försäljningsreturorder",
        "document:purchase-return-order": "Inköpsreturorder",
        "document:inventory-movement": "Lagerflyttning",
        "document:warehouse-movement": "Lagerförflyttning",
        "document:item-tracking-lines": "Artikelspårningsrader",
        "document:general-journal": "Redovisningsjournal",
        "document:item-journal": "Artikeljournal",
        "document:item-reclassification-journal": "Artikelomklassificeringsjournal",
        "document:physical-inventory-journal": "Inventeringsjournal",
        "Purchase Order → Warehouse Receipt → Put-away → Posted Receipt → Purchase Invoice":
          "Inköpsorder → Lagerinleverans → Inlagring → Bokförd inleverans → Inköpsfaktura",
        "Transfer Order → Transfer Shipment → In-transit → Transfer Receipt":
          "Överföringsorder → Överföringsutleverans → På väg → Överföringsinleverans"
      }
  };
}

function updateProcessAnalysisBadge() {
  const badge = $("processAnalysisBadge");
  const model = activeProcessAnalysis ? globalThis.T9ProcessAnalysisView.normalize(
    activeProcessAnalysis, activeReview?.processAnalysis
  ) : null;
  badge.hidden = !model?.available;
  badge.textContent = model?.available ? `${Math.round(model.confidence * 100)}%` : "";
}

async function loadProcessAnalysis(force = false) {
  if (!activeReviewSession) return null;
  if (activeProcessAnalysis && !force) return activeProcessAnalysis;
  if (processAnalysisRequest && !force) return processAnalysisRequest;
  const sessionId = activeReviewSession.id;
  processAnalysisRequest = send({ type: "T9_MATCH_REFERENCE_PROCESS", sessionId })
    .then(response => {
      if (!response?.ok) throw new Error(response?.error ||
        "Processanalysen kunde inte genomföras.");
      if (activeReviewSession?.id !== sessionId) return null;
      activeProcessAnalysis = response.result;
      updateProcessAnalysisBadge();
      renderProcessOverview();
      return activeProcessAnalysis;
    }).finally(() => { processAnalysisRequest = null; });
  return processAnalysisRequest;
}

function renderProcessAnalysisDialog() {
  const model = globalThis.T9ProcessAnalysisView.render(
    $("processAnalysisContent"), { result: activeProcessAnalysis || {},
      decision: activeReview?.processAnalysis }, processAnalysisLabels()
  );
  $("confirmProcessAnalysis").disabled = !model.available;
  $("useSelectedReference").disabled = true;
  $("processAnalysisStatus").textContent = "";
  updateProcessAnalysisBadge();
  return model;
}

function persistProcessAnalysisDecision(reference, status, variant = null) {
  if (!activeReview || !reference?.id) return;
  activeReview.processAnalysis = {
    confirmedReferenceId: reference.id,
    confirmedName: reference.name,
    confirmedVariantId: variant?.id || null,
    confirmedVariantName: variant?.name || null,
    confirmedAt: new Date().toISOString(),
    classificationSource: "manual",
    status
  };
  activeReview.updatedAt = activeReview.processAnalysis.confirmedAt;
  reviewAutoSave.schedule();
  renderProcessAnalysisDialog();
  renderProcessOverview();
  $("processAnalysisStatus").textContent = status === "confirmed"
    ? uiT("Klassificeringen bekräftades.")
    : uiT("Processvalet sparades.");
}

async function openProcessAnalysisDialog() {
  if (!processIntelligenceEnabled()) return;
  const dialog = $("processAnalysisDialog");
  $("processAnalysisContent").innerHTML = `<p class="process-analysis-loading">${escapeHtml(
    uiT("Analyserar processen…"))}</p>`;
  $("confirmProcessAnalysis").disabled = true;
  $("useSelectedReference").disabled = true;
  dialog.showModal();
  try {
    await loadProcessAnalysis();
    renderProcessAnalysisDialog();
  } catch (error) {
    $("processAnalysisContent").innerHTML = `<div class="process-analysis-empty" role="alert"><h4>${escapeHtml(
      uiT("Processanalysen kunde inte visas"))}</h4><p>${escapeHtml(error.message)}</p></div>`;
  }
}
const activeDocumentPresentationCache = globalThis.T9WorkspaceController
  .createRevisionCache();
const activeScreenshotQualityCache = globalThis.T9WorkspaceController
  .createRevisionCache();
let documentViewState = globalThis.T9DocumentWorkspaceExperience.load(
  globalThis.localStorage
);
let documentViewFrame = 0;
let documentScrollFrame = 0;
let workspaceContext = globalThis.T9WorkspaceContext.create();
let workspaceContextBinding = null;
let workspaceHighlightTimer = 0;
let documentationIntelligenceModel = null;
let activeDocumentProfileId = "business-process";
let documentProfileVariants = new Map();
let documentWorkspaceMediaSources = {};
let documentProfileSource = null;
let documentLibraryRecords = [];
let documentLibraryIndex = [];
let documentLibrarySessions = new Map();
let documentLibrarySelection = globalThis.T9DocumentBatchOperations.selection();
const DOCUMENT_LIBRARY_RENDER_LIMIT = 200;
let visibleDocumentLibraryRecords = [];

function librarySessionRecord(session) {
  const bugReport = session.recordingPurpose === "bug-report";
  const companyName = session.settings?.businessCentralCompany ||
    session.settings?.companyName || "";
  return {
    projectId: session.id,
    sessionId: session.id,
    title: session.name,
    createdAt: session.startedAt,
    modifiedAt: session.updatedAt || session.completedAt || session.startedAt,
    workflowName: session.name,
    documentLanguage: globalThis.T9LanguageRegistry.normalize(
      session.settings?.documentLanguage, "document"
    ),
    profile: bugReport ? {
      profileId: "bug-report", displayName: "Bug Report"
    } : undefined,
    theme: bugReport ? {
      themeId: "technical-report", displayName: "Technical Report"
    } : undefined,
    metadata: {
      environment: session.settings?.environmentName || "",
      company: companyName,
      eventCount: session.eventCount || 0,
      status: session.status || "",
      recordingPurpose: session.recordingPurpose || "documentation"
    }
  };
}

async function persistDocumentLibrary() {
  const response = await send({
    type: "T9_SAVE_DOCUMENT_LIBRARY",
    records: documentLibraryRecords
  });
  if (!response?.ok) throw new Error(
    response?.error || "Dokumentbiblioteket kunde inte sparas."
  );
}

function libraryOptions() {
  const value = (id, fallback = "") => $(id)?.value ?? fallback;
  const checked = id => $(id)?.checked === true;
  return {
    search: value("librarySearch"),
    sort: value("librarySort", "modified"),
    filters: {
      profile: value("libraryProfileFilter"),
      theme: value("libraryThemeFilter"),
      documentLanguage: value("libraryLanguageFilter"),
      favourite: checked("libraryFavouriteFilter"),
      recent: checked("libraryRecentFilter"),
      created: { from: value("libraryCreatedFrom"),
        to: value("libraryCreatedTo") },
      modified: { from: value("libraryModifiedFrom"),
        to: value("libraryModifiedTo") }
    }
  };
}

function fillLibraryFilter(id, values, selected) {
  const select = $(id);
  if (!select) return;
  const first = select.options[0];
  select.innerHTML = "";
  select.appendChild(first);
  values.forEach(([value, label]) => {
    const option = document.createElement("option");
    option.value = value;
    option.textContent = label;
    select.appendChild(option);
  });
  select.value = values.some(([value]) => value === selected) ? selected : "";
}

function renderDocumentLibrary() {
  const options = libraryOptions();
  const matches = globalThis.T9DocumentLibrary.query(
    documentLibraryIndex, options
  );
  const records = matches.slice(0, DOCUMENT_LIBRARY_RENDER_LIMIT);
  visibleDocumentLibraryRecords = records;
  const view = globalThis.T9DocumentLibraryView;
  const activeId = $("libraryGroupProfiles").checked
    ? view.renderGrouped($("libraryResults"),
      globalThis.T9DocumentLibrary.groupByProfile(records),
      documentLibrarySelection)
    : view.renderList($("libraryResults"), records, documentLibrarySelection);
  documentLibrarySelection = globalThis.T9DocumentBatchOperations.selection({
    ...documentLibrarySelection,
    activeId
  });
  $("libraryStatus").textContent = matches.length > records.length
    ? uiTf("library.limitedShown", {
      matches: matches.length,
      count: records.length
    })
    : records.length === 1
    ? uiT("library.oneShown")
    : uiTf("library.manyShown", { count: records.length });
  const filterCount = view.activeFilterCount(options);
  $("libraryFilterCount").hidden = filterCount === 0;
  $("libraryFilterCount").textContent = String(filterCount);
  $("libraryResetFilters").disabled = filterCount === 0;
  $("libraryFilterDisclosure").querySelector("summary").setAttribute(
    "aria-label", filterCount
      ? uiTf("library.activeFilters", { count: filterCount })
      : uiT("library.filters")
  );
  renderLibraryBatchToolbar();
}

function resetDocumentLibraryFilters() {
  for (const id of ["libraryProfileFilter", "libraryThemeFilter",
    "libraryLanguageFilter", "libraryCreatedFrom", "libraryCreatedTo",
    "libraryModifiedFrom", "libraryModifiedTo"]) {
    $(id).value = "";
  }
  $("libraryFavouriteFilter").checked = false;
  $("libraryRecentFilter").checked = false;
  renderDocumentLibrary();
  $("libraryFilterDisclosure").querySelector("summary").focus();
}

function rebuildDocumentLibraryIndex() {
  documentLibraryIndex = globalThis.T9DocumentLibrary.create(
    documentLibraryRecords
  );
}

function renderDocumentLibrarySelection() {
  globalThis.T9DocumentLibraryView.applySelection(
    $("libraryResults"), documentLibrarySelection
  );
  renderLibraryBatchToolbar();
}

function renderLibraryBatchToolbar(message = "") {
  const count = documentLibrarySelection.selectedIds.length;
  $("libraryBatchToolbar").hidden = count === 0;
  $("libraryBatchCount").textContent = count === 1
    ? uiT("library.oneSelected")
    : uiTf("library.manySelected", { count });
  if (message) $("libraryBatchStatus").textContent = message;
}

function refreshLibraryFilters() {
  const profiles = new Map();
  const themes = new Map();
  documentLibraryRecords.forEach(record => {
    profiles.set(record.profile.profileId, record.profile.displayName);
    themes.set(record.theme.themeId, record.theme.displayName);
  });
  fillLibraryFilter("libraryProfileFilter", [...profiles],
    $("libraryProfileFilter")?.value || "");
  fillLibraryFilter("libraryThemeFilter", [...themes],
    $("libraryThemeFilter")?.value || "");
}

async function loadDocumentLibrary(sessions, bootstrap = {}) {
  documentLibrarySessions = new Map(sessions.map(session => [session.id, session]));
  const stored = new Map((bootstrap.records || []).map(record =>
    [record.projectId || record.sessionId, record]
  ));
  const bugReports = new Map((bootstrap.reports || []).map(report =>
    [report.recordingId, report]));
  documentLibraryRecords = sessions.map(session => {
    const storedRecord = stored.get(session.id) || {};
    const sessionRecord = librarySessionRecord(session);
    const reportTitle = bugReports.get(session.id)?.summary?.title;
    return globalThis.T9DocumentLibrary.merge(storedRecord, {
      ...sessionRecord,
      title: reportTitle || sessionRecord.title,
      documentLanguage: storedRecord.documentLanguage ||
        sessionRecord.documentLanguage
    });
  });
  documentLibrarySelection = globalThis.T9DocumentBatchOperations.reconcile(
    documentLibrarySelection,
    documentLibraryRecords.map(record => record.projectId)
  );
  rebuildDocumentLibraryIndex();
  const activeIds = new Set(sessions.map(session => session.id));
  if ([...stored.keys()].some(projectId => !activeIds.has(projectId))) {
    await persistDocumentLibrary();
  }
  refreshLibraryFilters();
  renderDocumentLibrary();
}

async function updateDocumentLibraryRecord(projectId, patch, options = {}) {
  const previous = documentLibraryRecords;
  documentLibraryRecords = globalThis.T9DocumentLibrary.update(
    documentLibraryRecords, projectId, patch
  );
  rebuildDocumentLibraryIndex();
  try {
    await persistDocumentLibrary();
  } catch (error) {
    documentLibraryRecords = previous;
    rebuildDocumentLibraryIndex();
    throw error;
  }
  if (options.render !== false) {
    refreshLibraryFilters();
    renderDocumentLibrary();
  }
}

function selectedLibraryRecords() {
  return globalThis.T9DocumentBatchOperations.selected(
    documentLibraryRecords, documentLibrarySelection
  );
}

async function commitLibraryBatch(result, confirmation) {
  if (!result.affected) {
    renderLibraryBatchToolbar("Inga metadataändringar behövdes.");
    return 0;
  }
  const previous = documentLibraryRecords;
  documentLibraryRecords = result.records;
  rebuildDocumentLibraryIndex();
  try {
    await persistDocumentLibrary();
  } catch (error) {
    documentLibraryRecords = previous;
    rebuildDocumentLibraryIndex();
    renderDocumentLibrary();
    throw error;
  }
  documentLibrarySelection = globalThis.T9DocumentBatchOperations.reconcile(
    documentLibrarySelection,
    documentLibraryRecords.map(record => record.projectId)
  );
  refreshLibraryFilters();
  renderDocumentLibrary();
  renderLibraryBatchToolbar(confirmation.replace("{count}", result.affected));
  return result.affected;
}

function populateBatchMetadataOptions() {
  $("libraryBatchProfileValue").innerHTML = documentProfiles().map(profile =>
    `<option value="${escapeHtml(profile.profileId)}">` +
      `${escapeHtml(profile.displayName)}</option>`
  ).join("");
  const themes = globalThis.T9DocumentThemeRegistry.list(
    globalThis.T9DocumentThemeRegistry.BUILT_IN_REGISTRY
  ).filter(theme => theme.themeId !== "base");
  $("libraryBatchThemeValue").innerHTML = themes.map(theme =>
    `<option value="${escapeHtml(theme.themeId)}">` +
      `${escapeHtml(theme.displayName)}</option>`
  ).join("");
}

function openBatchMetadataDialog(mode = "metadata") {
  const count = documentLibrarySelection.selectedIds.length;
  if (!count) return;
  for (const id of ["Tags", "Profile", "Theme", "Author", "Status", "Archived"]) {
    $("libraryBatchUse" + id).checked = false;
  }
  const modeField = { tags: "Tags", profile: "Profile", theme: "Theme" }[mode];
  if (modeField) $("libraryBatchUse" + modeField).checked = true;
  $("libraryBatchMetadataDescription").textContent =
    `Endast markerade fält ändras för ${count} dokument.`;
  $("libraryBatchMetadataDialog").returnValue = "";
  $("libraryBatchMetadataDialog").showModal();
  $(modeField ? "libraryBatch" + modeField + "Value" :
    "libraryBatchUseTags").focus();
}

function batchMetadataOperation() {
  const profileSelect = $("libraryBatchProfileValue");
  const themeSelect = $("libraryBatchThemeValue");
  return {
    type: "metadata",
    fields: {
      tags: { selected: $("libraryBatchUseTags").checked,
        value: $("libraryBatchTagsValue").value.split(",")
          .map(value => value.trim()).filter(Boolean) },
      profile: { selected: $("libraryBatchUseProfile").checked,
        value: { profileId: profileSelect.value,
          displayName: profileSelect.selectedOptions[0]?.textContent || "" } },
      theme: { selected: $("libraryBatchUseTheme").checked,
        value: { themeId: themeSelect.value,
          displayName: themeSelect.selectedOptions[0]?.textContent || "" } },
      author: { selected: $("libraryBatchUseAuthor").checked,
        value: $("libraryBatchAuthorValue").value.trim() },
      status: { selected: $("libraryBatchUseStatus").checked,
        value: $("libraryBatchStatusValue").value.trim() },
      archived: { selected: $("libraryBatchUseArchived").checked,
        value: $("libraryBatchArchivedValue").value === "true" }
    }
  };
}

function activeDocumentThemeId() {
  const assigned = documentLibraryRecords.find(record =>
    record.projectId === activeReviewSession?.id)?.theme?.themeId;
  const themes = globalThis.T9DocumentThemeRegistry.list(
    globalThis.T9DocumentThemeRegistry.BUILT_IN_REGISTRY);
  return themes.some(theme => theme.themeId === assigned) ? assigned
    : documentProfiles().find(profile => profile.profileId === activeDocumentProfileId)
      ?.theme.themeId || "thinknine";
}

function renderDocumentProfileChoice() {
  const select = $("reviewDocumentProfile");
  select.innerHTML = documentProfiles().map(profile =>
    '<option value="' + escapeHtml(profile.profileId) + '">' +
    escapeHtml(uiT("review.profile." + profile.profileId)) + '</option>').join("");
  select.value = activeDocumentProfileId;
  $("reviewDocumentProfileHelp").textContent = uiT("review.profileHelp." + activeDocumentProfileId);
}

function documentProfiles() {
  return globalThis.T9DocumentProfile.list(
    globalThis.T9DocumentProfile.BUILT_IN_REGISTRY
  );
}

function buildDocumentProfileVariants(pipeline) {
  const availableThemeIds = new Set(globalThis.T9DocumentThemeRegistry.list(
    globalThis.T9DocumentThemeRegistry.BUILT_IN_REGISTRY
  ).map(theme => theme.themeId));
  return new Map(documentProfiles().filter(profile =>
    profile.profileId === activeDocumentProfileId).map(profile => {
    const assignedThemeId = profile.profileId === activeDocumentProfileId
      ? documentLibraryRecords.find(record =>
        record.projectId === activeReviewSession?.id
      )?.theme.themeId
      : null;
    const themeId = availableThemeIds.has(assignedThemeId)
      ? assignedThemeId : profile.theme.themeId;
    const theme = themeId === pipeline.theme.themeId
      ? pipeline.theme
      : globalThis.T9DocumentThemeRegistry.resolve(
        globalThis.T9DocumentThemeRegistry.BUILT_IN_REGISTRY,
        themeId,
        profile.theme.overrides || {}
      );
    const matchesPipeline =
      profile.profileId === pipeline.languageProfile.profileId &&
      theme === pipeline.theme;
    let semanticDocument = pipeline.semanticDocument;
    let screenshotSelections = pipeline.screenshotSelections;
    let plan = pipeline.plan;
    if (!matchesPipeline) {
      const languageDocument = globalThis.T9LanguageExcellence.process(
        pipeline.semanticActionsDocument,
        profile
      );
      const presentationDocument = globalThis.T9PresentationGrammar.process(
        languageDocument
      );
      const screenshotResult = globalThis.T9ScreenshotIntelligence.select(
        presentationDocument,
        { candidates: pipeline.screenshotCandidates, profile }
      );
      semanticDocument = screenshotResult.document;
      screenshotSelections = screenshotResult.selections;
      plan = globalThis.T9DocumentPlanner.plan(semanticDocument, theme);
    }
    return [profile.profileId, {
      profile,
      theme,
      semanticDocument,
      screenshotSelections,
      plan,
      model: globalThis.T9DocumentWorkspace.render(plan)
    }];
  }));
}

function applyDocumentProfileVariant(options = {}) {
  renderDocumentExportCheck();
  const variant = documentProfileVariants.get(activeDocumentProfileId);
  if (!variant) return null;
  const viewport = $("documentWorkspaceViewport");
  const focalRatio = (viewport.scrollTop + viewport.clientHeight / 2) /
    Math.max(1, viewport.scrollHeight);
  documentationIntelligenceModel = globalThis.T9DocumentationIntelligence
    .create({
      document: variant.semanticDocument,
      plan: variant.plan,
      qualityDiagnostics: options.qualityDiagnostics ||
        documentProfileSource?.qualityDiagnostics,
      workspaceContext,
      profile: variant.profile
    });
  indexActiveDocumentVariant(variant, variant.semanticDocument);
  workspaceContextBinding = globalThis.T9WorkspaceContext.bind(variant.model, {
    taskIds: globalThis.T9Review.activeTasks(activeReview).map(task => task.taskId),
    screenshotsByTask: reviewScreenshotsByTask()
  });
  const result = globalThis.T9DocumentWorkspaceView.render(
    $("documentWorkspace"),
    variant.model,
    documentWorkspaceMediaSources
  );
  applyDocumentView({ persist: false });
  if (options.preservePosition) {
    viewport.scrollTop = Math.max(
      0,
      focalRatio * viewport.scrollHeight - viewport.clientHeight / 2
    );
  } else {
    revealDocumentContext();
  }
  return result;
}

function indexActiveDocumentVariant(variant, semanticDocument) {
  if (!activeReviewSession || !semanticDocument || !documentationIntelligenceModel) {
    return;
  }
  const sectionNames = (semanticDocument.sections || []).map(section =>
    section.title || section.kind
  ).filter(Boolean);
  const paragraphTexts = [];
  function visit(blocks) {
    (blocks || []).forEach(block => {
      if (block.kind === "paragraph" && block.text) paragraphTexts.push(block.text);
      visit(block.blocks);
    });
  }
  semanticDocument.sections?.forEach(section => visit(section.blocks));
  const wordCount = paragraphTexts.join(" ").trim().split(/\s+/).filter(Boolean).length;
  const patch = {
    title: semanticDocument.title || activeReviewSession.name,
    modifiedAt: activeReview?.updatedAt || activeReviewSession.updatedAt ||
      activeReviewSession.startedAt,
    profile: {
      profileId: variant.profile.profileId,
      displayName: variant.profile.displayName
    },
    theme: {
      themeId: variant.theme.themeId,
      displayName: variant.theme.name || variant.theme.displayName ||
        variant.theme.themeId
    },
    summary: semanticDocument.purpose || semanticDocument.metadata?.purpose ||
      paragraphTexts[0] || "",
    workflowName: activeReviewSession.name,
    sectionNames,
    readingMinutes: Math.max(1, Math.ceil(wordCount / 200)),
    health: {
      overall: healthStatusLabel(documentationIntelligenceModel.health.overall),
      suggestionLabel: documentationIntelligenceModel.health.suggestionLabel,
      confirmations: documentationIntelligenceModel.positiveConfirmations.map(
        value => value.title
      )
    },
    recentActivity: ["Dokumentinformationen indexerades"]
  };
  const previous = documentLibraryRecords.find(record =>
    record.projectId === activeReviewSession.id
  );
  const next = globalThis.T9DocumentLibrary.merge(previous ||
    librarySessionRecord(activeReviewSession), patch);
  if (JSON.stringify(previous) === JSON.stringify(next)) return;
  documentLibraryRecords = globalThis.T9DocumentLibrary.update(
    documentLibraryRecords, activeReviewSession.id, patch
  );
  rebuildDocumentLibraryIndex();
  persistDocumentLibrary().catch(error => show(error.message, true));
}

function healthStatusLabel(status) {
  return {
    "Ready for Review": "Redo för granskning",
    "Needs Attention": "Behöver uppmärksamhet",
    Complete: "Komplett",
    Good: "Bra",
    "Good with Suggestions": "Bra med förslag",
    "Not assessed": "Inte bedömd"
  }[status] || status;
}

function reviewScreenshotsByTask() {
  return Object.fromEntries((activeReview?.tasks || []).map(task => [
    task.taskId,
    reviewImages(task).map(image => image.path)
  ]));
}

function publishWorkspaceContext(patch, reason, origin) {
  workspaceContext = globalThis.T9WorkspaceContext.update(workspaceContext, {
    ...patch,
    navigationReason: reason,
    focusOrigin: origin
  });
}

function documentContextElement(itemId) {
  return [...$("documentWorkspace").querySelectorAll(
    "[data-document-workspace-item-id]"
  )].find(element => element.dataset.documentWorkspaceItemId === itemId) || null;
}

function revealDocumentContext(options = {}) {
  if (!workspaceContextBinding) return;
  const target = globalThis.T9WorkspaceContext.target(
    workspaceContextBinding,
    workspaceContext
  );
  const element = documentContextElement(target.itemId);
  if (!element) return;
  const section = element.closest("[data-document-workspace-section-id]");
  const sectionIndex = documentSections().indexOf(section);
  if (sectionIndex >= 0) {
    documentViewState = globalThis.T9DocumentWorkspaceExperience.navigate(
      documentViewState,
      sectionIndex + 1,
      documentPageCount()
    );
    applyDocumentView({ persist: false });
  }
  clearTimeout(workspaceHighlightTimer);
  $("documentWorkspace").querySelectorAll(".workspace-context-highlight")
    .forEach(item => item.classList.remove("workspace-context-highlight"));
  element.classList.add("workspace-context-highlight");
  const reducedMotion = globalThis.matchMedia?.(
    "(prefers-reduced-motion: reduce)"
  ).matches;
  element.scrollIntoView({
    block: "center",
    behavior: reducedMotion ? "auto" : "smooth"
  });
  if (options.focus) element.focus({ preventScroll: true });
  workspaceHighlightTimer = setTimeout(() => {
    element.classList.remove("workspace-context-highlight");
  }, reducedMotion ? 0 : 1400);
  $("documentWorkspaceStatus").textContent =
    "Motsvarande dokumentposition visas.";
}

function revealReviewContext(options = {}) {
  const taskId = workspaceContext.selectedStepId;
  if (!taskId || !reviewTaskIds().includes(taskId)) return;
  activeReviewSelection = {
    selectedIds: [taskId],
    activeId: taskId,
    anchorId: taskId
  };
  applyReviewSelection(Boolean(options.focus), false);
  const card = [...$("reviewList").querySelectorAll("[data-review-task-id]")]
    .find(element => element.dataset.reviewTaskId === taskId);
  if (options.scroll !== false) card?.scrollIntoView({ block: "center" });
  if (options.focus && workspaceContext.selectedScreenshotId) {
    const task = (activeReview?.tasks || []).find(item => item.taskId === taskId);
    const imageIndex = reviewImages(task || {}).findIndex(
      image => image.path === workspaceContext.selectedScreenshotId
    );
    if (imageIndex >= 0) {
      card?.querySelectorAll('[data-action="annotate"]')[imageIndex]?.focus({
        preventScroll: true
      });
    }
  }
  $("reviewFooterText").textContent = "Motsvarande granskningssteg visas.";
}

function documentSections() {
  return [...$("documentWorkspace").children].filter(element =>
    element.dataset.documentWorkspaceSectionId
  );
}

function documentPageCount() {
  return Math.max(1, documentSections().length);
}

function saveDocumentViewPreferences() {
  globalThis.T9DocumentWorkspaceExperience.save(
    globalThis.localStorage,
    documentViewState
  );
}

function applyReviewZoom(options = {}) {
  const panel = $("reviewWorkspacePanel");
  const focalRatio = (panel.scrollTop + panel.clientHeight / 2) /
    Math.max(1, panel.scrollHeight);
  reviewZoom = normalizedReviewZoom(reviewZoom);
  panel.style.setProperty("--review-zoom", String(reviewZoom / 100));
  $("reviewZoomValue").textContent = `${reviewZoom}%`;
  $("reviewZoomOut").disabled = reviewZoom <= REVIEW_ZOOM_MIN;
  $("reviewZoomIn").disabled = reviewZoom >= REVIEW_ZOOM_MAX;
  if (options.preservePosition !== false) {
    panel.scrollTop = Math.max(
      0,
      focalRatio * panel.scrollHeight - panel.clientHeight / 2
    );
  }
  if (options.persist !== false) {
    try {
      globalThis.localStorage?.setItem(REVIEW_ZOOM_STORAGE_KEY, String(reviewZoom));
    } catch {
      // Zoom remains available for the current dashboard session.
    }
  }
}

function changeReviewZoom(value) {
  reviewZoom = normalizedReviewZoom(value);
  applyReviewZoom();
}

function applyDocumentView(options = {}) {
  const panel = $("documentWorkspacePanel");
  const viewport = $("documentWorkspaceViewport");
  const page = $("documentWorkspace");
  const experience = globalThis.T9DocumentWorkspaceExperience;
  const pageCount = documentPageCount();
  documentViewState = experience.navigate(
    documentViewState,
    documentViewState.currentPage,
    pageCount
  );
  const zoom = experience.effectiveZoom(documentViewState, {
    availableWidth: Math.max(1, viewport.clientWidth - 44),
    availableHeight: Math.max(1, viewport.clientHeight - 44),
    pageWidth: 780,
    pageHeight: 900
  });
  panel.style.setProperty("--document-zoom", String(zoom / 100));
  panel.dataset.viewMode = documentViewState.viewMode;
  panel.classList.toggle("adaptive-reading", experience.adaptiveEnabled(
    documentViewState,
    { workspaceWidth: panel.clientWidth, documentWidth: 780, zoom }
  ));
  $("documentToolbar").classList.toggle("compact", experience.compactToolbar(
    documentViewState,
    panel.clientWidth
  ));
  $("documentZoomValue").textContent = `${zoom}%`;
  $("documentFitWidth").setAttribute(
    "aria-pressed",
    String(documentViewState.zoomMode === "fitWidth")
  );
  $("documentFitPage").setAttribute(
    "aria-pressed",
    String(documentViewState.zoomMode === "fitPage")
  );
  $("documentContinuousMode").setAttribute(
    "aria-pressed",
    String(documentViewState.viewMode === "continuous")
  );
  $("documentPageMode").setAttribute(
    "aria-pressed",
    String(documentViewState.viewMode === "page")
  );
  const sections = documentSections();
  sections.forEach((section, index) => {
    section.hidden = documentViewState.viewMode === "page" &&
      index + 1 !== documentViewState.currentPage;
  });
  $("documentPageIndicator").textContent = uiTf("document.page", {
    page: documentViewState.currentPage,
    count: pageCount
  });
  $("documentPreviousPage").disabled = documentViewState.currentPage <= 1;
  $("documentNextPage").disabled = documentViewState.currentPage >= pageCount;
  page.setAttribute("aria-label", page.getAttribute("aria-label") || "Dokument");
  if (options.announce) {
    $("documentWorkspaceStatus").textContent = uiTf(
      "document.pageZoomAnnouncement",
      { page: documentViewState.currentPage, count: pageCount, zoom }
    );
  }
  if (options.persist !== false) saveDocumentViewPreferences();
}

function scheduleDocumentView(options = {}) {
  cancelAnimationFrame(documentViewFrame);
  documentViewFrame = requestAnimationFrame(() => {
    documentViewFrame = 0;
    applyDocumentView(options);
  });
}

function changeDocumentView(nextState, options = {}) {
  const viewport = $("documentWorkspaceViewport");
  const focalRatio = (viewport.scrollTop + viewport.clientHeight / 2) /
    Math.max(1, viewport.scrollHeight);
  documentViewState = nextState;
  applyDocumentView({ announce: true, ...options });
  if (options.preserveFocalPosition !== false) {
    viewport.scrollTop = Math.max(
      0,
      focalRatio * viewport.scrollHeight - viewport.clientHeight / 2
    );
  }
}

function navigateDocument(destination) {
  documentViewState = globalThis.T9DocumentWorkspaceExperience.navigate(
    documentViewState,
    destination,
    documentPageCount()
  );
  applyDocumentView({ announce: true, persist: false });
  const section = documentSections()[documentViewState.currentPage - 1];
  if (documentViewState.viewMode === "continuous") {
    section?.scrollIntoView({ block: "start" });
  } else {
    $("documentWorkspaceViewport").scrollTop = 0;
  }
}

function updateContinuousDocumentPage() {
  if (documentViewState.viewMode !== "continuous") return;
  const viewport = $("documentWorkspaceViewport");
  const sections = documentSections();
  if (!sections.length) return;
  const marker = viewport.getBoundingClientRect().top + 80;
  let page = 1;
  for (let index = 0; index < sections.length; index += 1) {
    if (sections[index].getBoundingClientRect().top <= marker) page = index + 1;
  }
  if (page !== documentViewState.currentPage) {
    documentViewState = globalThis.T9DocumentWorkspaceExperience.navigate(
      documentViewState,
      page,
      sections.length
    );
    $("documentPageIndicator").textContent = uiTf("document.page", {
      page,
      count: sections.length
    });
    $("documentPreviousPage").disabled = page <= 1;
    $("documentNextPage").disabled = page >= sections.length;
  }
}

function invalidateDocumentWorkspace() {
  workspaceState = globalThis.T9WorkspaceController.invalidate(workspaceState);
}

function applyWorkspaceState() {
  const documentActive = workspaceState.active === "document";
  $("reviewDialog").classList.toggle("document-workspace-mode", documentActive);
  $("reviewWorkspacePanel").hidden = documentActive;
  $("documentWorkspacePanel").hidden = !documentActive;
  for (const [workspace, tabId] of [
    ["review", "reviewWorkspaceTab"],
    ["document", "documentWorkspaceTab"]
  ]) {
    const selected = workspaceState.active === workspace;
    $(tabId).setAttribute("aria-selected", String(selected));
    $(tabId).tabIndex = selected ? 0 : -1;
  }
}

async function synchronizeDocumentWorkspace() {
  if (!activeReview || !activeReviewModel) return;
  if (!globalThis.T9WorkspaceController.needsRender(workspaceState)) return;
  if (documentWorkspaceSync) return documentWorkspaceSync;
  documentWorkspaceSync = (async () => {
    while (activeReview && workspaceState.active === "document" &&
        globalThis.T9WorkspaceController.needsRender(workspaceState)) {
      const requestedRevision = workspaceState.revision;
      $("documentWorkspaceStatus").textContent = "Uppdaterar dokumentet...";
      try {
        const pipeline = createActiveDocumentPipeline();
        const mediaAssets = await composeDocumentWorkspaceMedia(
          pipeline, activeReview, activeReviewModel?.screenshotData
        );
        if (requestedRevision !== workspaceState.revision) continue;
        documentProfileSource = {
          semanticDocument: pipeline.semanticDocument,
          qualityDiagnostics: pipeline.qualityDiagnostics
        };
        documentProfileVariants = buildDocumentProfileVariants(pipeline);
        documentWorkspaceMediaSources = Object.fromEntries(
          Object.entries(mediaAssets).map(
          ([assetId, value]) => [assetId, {
            source: typeof value === "string"
              ? value
              : imageDataToDataUrl(value),
            revision: requestedRevision
          }]
        ));
        const result = applyDocumentProfileVariant({
          semanticDocument: pipeline.semanticDocument,
          qualityDiagnostics: pipeline.qualityDiagnostics
        });
        workspaceState = globalThis.T9WorkspaceController.complete(
          workspaceState,
          requestedRevision
        );
        $("documentWorkspaceStatus").textContent = uiTf(
          "document.synchronized",
          { count: result.sectionCount }
        );
      } catch (error) {
        $("documentWorkspaceStatus").textContent =
          `Dokumentet kunde inte visas: ${error.message}`;
        break;
      }
    }
  })().finally(() => {
    documentWorkspaceSync = null;
  });
  return documentWorkspaceSync;
}

async function switchWorkspace(workspace, focusTab = false) {
  if (workspace === "document" && annotationEditorState) {
    $("annotationStatus").textContent =
      "Slutför eller avbryt annoteringen innan du byter arbetsyta.";
    return false;
  }
  if (workspace === "document" && activeReviewEdit) {
    const current = $("reviewList").querySelector('[data-editing="true"]');
    finishReviewEdit(current, true);
  }
  workspaceState = globalThis.T9WorkspaceController.switchTo(
    workspaceState,
    workspace
  );
  applyWorkspaceState();
  if (workspace === "document") {
    await synchronizeDocumentWorkspace();
    revealDocumentContext({ focus: focusTab });
  } else {
    revealReviewContext({ focus: focusTab });
  }
  if (focusTab) {
    $(workspace === "document"
      ? "documentWorkspaceTab"
      : "reviewWorkspaceTab").focus();
  }
  return true;
}

const reviewSaveQueue = globalThis.T9ReviewEdit.createSaveQueue(
  payload => send({
    type: "T9_SAVE_REVIEW",
    sessionId: payload.sessionId,
    review: payload.review
  })
);

const reviewAutoSave = globalThis.T9ReviewEdit.createAutoSave(
  () => {
    if (globalThis.T9ReviewAnnotationEditor.hasActiveGesture(
      annotationEditorState
    )) {
      reviewAutoSave.schedule();
      return undefined;
    }
    return saveActiveReview({ render: false, announce: false });
  },
  {
    onError(error) {
      show(error.message, true);
      $("reviewFooterText").textContent = "Automatisk sparning misslyckades.";
      if (annotationEditorState) {
        $("annotationStatus").textContent =
          "Automatisk sparning misslyckades. Försök spara igen.";
      }
    }
  }
);

const reviewPersistence = globalThis.T9ReviewEdit.createPersistenceCoordinator({
  autoSave: reviewAutoSave,
  saveQueue: reviewSaveQueue,
  save: saveActiveReview
});

function reviewTaskIds() {
  return globalThis.T9Review.activeTasks(activeReview || { tasks: [] })
    .map(task => task.taskId);
}

function reviewNavigationState() {
  return globalThis.T9ReviewNavigation.derive(
    globalThis.T9Review.activeTasks(activeReview || { tasks: [] }),
    activeReviewSelection.activeId
  );
}

function applyReviewToolbarState() {
  const state = globalThis.T9ReviewToolbar.derive({
    taskIds: reviewTaskIds(),
    selection: activeReviewSelection,
    canUndo: activeReview && globalThis.T9Review.canUndo(activeReview),
    canRedo: activeReview && globalThis.T9Review.canRedo(activeReview),
    hasStructureOverrides: Boolean(activeReview?.structureOverrides?.length),
    canExport: activeReview && activeReviewSession && activeReviewModel
  });
  globalThis.T9ReviewToolbar.apply($("reviewToolbar"), state);
  const selectionBar = $("reviewSelectionActions");
  const selectedCount = activeReviewSelection.selectedIds.filter(id => reviewTaskIds().includes(id)).length;
  if (!selectedCount && selectionBar.contains(document.activeElement)) {
    $("reviewMoreActions").querySelector("summary").focus();
  }
  selectionBar.hidden = selectedCount === 0;
  $("reviewSelectionCount").textContent = String(selectedCount);
  $("resetReviewStructure").disabled =
    !activeReview?.structureOverrides?.length;
  $("completeReview").disabled = !activeReview ||
    !globalThis.T9Review.canComplete(activeReview);
  $("regenerateSelectedReview").disabled =
    !activeReviewSelection.selectedIds.length;
  const navigation = reviewNavigationState();
  const nextButton = $("nextUnreviewedStep");
  nextButton.disabled = !activeReview || navigation.complete;
  nextButton.setAttribute("aria-label", navigation.complete
    ? uiT("review.allStepsReviewed")
    : uiTf("review.nextUnreviewedLabel", { count: navigation.count }));
}

function activeExportCheck() {
  const tasks = reviewTasksForDisplay(activeReview).tasks;
  const navigation = globalThis.T9ReviewNavigation.derive(
    tasks, activeReviewSelection.activeId
  );
  return { total: tasks.length, remaining: navigation.count,
    nextTaskId: navigation.nextTaskId };
}

function renderDocumentExportCheck() {
  const check = activeExportCheck();
  $("documentExportCheckStatus").textContent = check.total
    ? uiTf("review.readiness", check) : uiT("review.exportEmpty");
  $("documentCheckNext").disabled = !check.nextTaskId;
  if (!$("documentExportWord").hasAttribute("aria-busy")) {
    $("documentExportWord").disabled = !check.total;
  }
}

$("documentCheckNext").addEventListener("click", async () => {
  const review = activeReview;
  const check = activeExportCheck();
  if (!check.nextTaskId) return;
  await switchWorkspace("review");
  if (activeReview !== review) return;
  activateProcessOverviewTask(check.nextTaskId, true);
});

$("documentExportWord").addEventListener("click", event => {
  exportReviewFromToolbar(event.currentTarget);
});

function renderReviewAttention(tasks) {
  renderDocumentExportCheck();
  const remaining = tasks.filter(task => !task.approved).length;
  $("reviewSummary").textContent = uiTf("review.readiness", {
    total: tasks.length, remaining
  });
}
function applyReviewStatus() {
  const status = globalThis.T9ReviewStatus.derive(
    activeReview?.tasks || [],
    activeReviewSelection
  );
  status.corrections = activeReview
    ? globalThis.T9Review.correctionFeedbackSummary(activeReview).correctionCount
    : 0;
  globalThis.T9ReviewStatus.apply($("reviewStatus"), status);
}

function applyReviewSelection(focusActive = false, publish = true) {
  const taskIds = reviewTaskIds();
  activeReviewSelection = globalThis.T9ReviewSelection.reconcile(
    activeReviewSelection,
    taskIds
  );
  for (const card of $("reviewList").querySelectorAll("[data-review-task-id]")) {
    const selected = activeReviewSelection.selectedIds.includes(
      card.dataset.reviewTaskId
    );
    const active = activeReviewSelection.activeId === card.dataset.reviewTaskId;
    card.classList.toggle("selected", selected);
    card.setAttribute("aria-selected", String(selected));
    const initial = !activeReviewSelection.activeId &&
      card === $("reviewList").firstElementChild;
    card.tabIndex = active || initial ? 0 : -1;
    if (focusActive && active) card.focus();
  }
  applyReviewToolbarState();
  applyReviewStatus();
  globalThis.T9ProcessOverviewView.updateSelection(
    $("processOverview"), activeReviewSelection.selectedIds
  );
  if (publish && activeReviewSelection.activeId) {
    publishWorkspaceContext({
      selectedStepId: activeReviewSelection.activeId,
      selectedScreenshotId: null,
      selectedAnnotationId: null,
      scrollAnchor: activeReviewSelection.activeId
    }, "review-selection", "review");
  }
}

function activateProcessOverviewTask(taskId, focusCard = false) {
  if (!taskId || !reviewTaskIds().includes(taskId)) return false;
  activeReviewSelection = globalThis.T9ReviewSelection.reduce(
    activeReviewSelection,
    { type: "select", id: taskId },
    reviewTaskIds()
  );
  applyReviewSelection(focusCard);
  const card = [...$("reviewList").querySelectorAll("[data-review-task-id]")]
    .find(element => element.dataset.reviewTaskId === taskId);
  card?.scrollIntoView({ block: "center" });
  $("reviewFooterText").textContent = "Motsvarande granskningssteg visas.";
  return true;
}

function activateNextUnreviewedStep() {
  const navigation = reviewNavigationState();
  if (!navigation.nextTaskId) {
    show(uiT("review.allStepsReviewed"));
    return false;
  }
  const activated = activateProcessOverviewTask(
    navigation.nextTaskId, true
  );
  if (activated) {
    show(navigation.count === 1
      ? uiT("review.lastUnreviewedShown")
      : uiTf("review.nextUnreviewedShown", { count: navigation.count }));
  }
  return activated;
}

function dispatchReviewSelection(command, focusActive = false) {
  activeReviewSelection = globalThis.T9ReviewSelection.reduce(
    activeReviewSelection,
    command,
    reviewTaskIds()
  );
  applyReviewSelection(focusActive);
}

function selectedReviewTaskIds(fallbackId) {
  return activeReviewSelection.selectedIds.includes(fallbackId)
    ? activeReviewSelection.selectedIds
    : [fallbackId];
}

function renderMovedReview(previousPositions, focusId) {
  renderReview();
  loadProcessAnalysis().catch(error => {
    console.warn("BC Process Studio process analysis preload failed", error);
  });
  if (focusId) {
    activeReviewSelection = {
      ...activeReviewSelection,
      activeId: focusId
    };
    applyReviewSelection(true);
  }
  const reducedMotion = globalThis.matchMedia?.(
    "(prefers-reduced-motion: reduce)"
  ).matches;
  globalThis.T9ReviewMove.animatePositions(
    $("reviewList"),
    previousPositions,
    reducedMotion
  );
}

function moveReviewTasksByOffset(delta, fallbackId) {
  const previous = globalThis.T9ReviewMove.capturePositions($("reviewList"));
  const fallbackSelected = activeReviewSelection.selectedIds.includes(fallbackId);
  const movedIds = selectedReviewTaskIds(fallbackId);
  const tasks = globalThis.T9ReviewMove.moveByOffset(
    activeReview.tasks,
    movedIds,
    delta
  );
  globalThis.T9Review.reorder(activeReview, tasks, {
    beforeSelection: activeReviewSelection,
    afterSelection: activeReviewSelection
  });
  const focusId = fallbackSelected
    ? activeReviewSelection.activeId || fallbackId
    : fallbackId;
  renderMovedReview(previous, focusId);
}

function moveReviewTasksTo({ draggedId, targetId, position }) {
  const previous = globalThis.T9ReviewMove.capturePositions($("reviewList"));
  const draggedSelected = activeReviewSelection.selectedIds.includes(draggedId);
  const movedIds = selectedReviewTaskIds(draggedId);
  const tasks = globalThis.T9ReviewMove.moveTo(
    activeReview.tasks,
    movedIds,
    targetId,
    position
  );
  globalThis.T9Review.reorder(activeReview, tasks, {
    beforeSelection: activeReviewSelection,
    afterSelection: activeReviewSelection
  });
  const focusId = draggedSelected
    ? activeReviewSelection.activeId || draggedId
    : draggedId;
  renderMovedReview(previous, focusId);
}

function deleteReviewTasks(selectedIds) {
  const taskIds = reviewTaskIds();
  if (!selectedIds.length) return;
  const firstIndex = Math.min(...selectedIds.map(id => taskIds.indexOf(id)));
  selectedIds.forEach(taskId => {
    const index = activeReview.tasks.findIndex(task => task.taskId === taskId);
    globalThis.T9Review.setTaskHidden(activeReview, index, true, {
      beforeSelection: activeReviewSelection
    });
  });
  const remainingIds = reviewTaskIds();
  const nextId = remainingIds[Math.min(firstIndex, remainingIds.length - 1)] || null;
  activeReviewSelection = nextId
    ? { selectedIds: [nextId], activeId: nextId, anchorId: nextId }
    : globalThis.T9ReviewSelection.create();
  renderReview();
  applyReviewSelection(Boolean(nextId));
}

function addManualInformationStep(afterIndex) {
  globalThis.T9Review.add(activeReview, afterIndex, {
    beforeSelection: activeReviewSelection
  });
  const created = activeReview.manualSteps.at(-1);
  activeReviewSelection = {
    selectedIds: [created.manualStepId],
    activeId: created.manualStepId,
    anchorId: created.manualStepId
  };
  reviewAutoSave.schedule();
  renderReview();
  const card = $("reviewList").querySelector(
    `[data-review-task-id="${created.manualStepId}"]`
  );
  if (card) editReviewField(card, created.manualStepId, "instruction");
  show("Informationssteget lades till. Skriv texten och spara.");
}

function mergeSelectedReviewTasks() {
  const selectedIds = activeReviewSelection.selectedIds;
  if (selectedIds.length < 2) return;
  const previous = globalThis.T9ReviewMove.capturePositions($("reviewList"));
  const result = globalThis.T9Review.merge(activeReview, selectedIds, {
    beforeSelection: activeReviewSelection
  });
  if (!result.mergedTask) {
    show(result.reason === "non-adjacent-steps"
      ? "Välj intilliggande steg för att slå samman dem."
      : "Stegen kunde inte slås samman.", true);
    return;
  }
  const mergedId = result.mergedTask.taskId;
  activeReviewSelection = {
    selectedIds: [mergedId],
    activeId: mergedId,
    anchorId: mergedId
  };
  renderMovedReview(previous, mergedId);
}

function splitSelectedReviewTask() {
  const [taskId] = activeReviewSelection.selectedIds;
  if (!taskId || activeReviewSelection.selectedIds.length !== 1) return;
  const card = [...$("reviewList").querySelectorAll("[data-review-task-id]")]
    .find(element => element.dataset.reviewTaskId === taskId);
  const instruction = card?.querySelector('[data-field="instruction"]');
  const selection = globalThis.getSelection?.();
  let splitAt = instruction?.selectionStart;
  if (!Number.isInteger(splitAt) && instruction && selection?.rangeCount &&
      instruction.contains(selection.anchorNode)) {
    const range = selection.getRangeAt(0).cloneRange();
    range.selectNodeContents(instruction);
    range.setEnd(selection.anchorNode, selection.anchorOffset);
    splitAt = range.toString().length;
  }
  const previous = globalThis.T9ReviewMove.capturePositions($("reviewList"));
  const result = globalThis.T9Review.split(
    activeReview,
    taskId,
    { splitAt },
    { beforeSelection: activeReviewSelection }
  );
  if (!result.splitTasks.length) {
    $("reviewFooterText").textContent =
      "Placera markören mellan två textdelar i instruktionen.";
    instruction?.focus();
    return;
  }
  const splitIds = result.splitTasks.map(task => task.taskId);
  activeReviewSelection = {
    selectedIds: splitIds,
    activeId: splitIds[0],
    anchorId: splitIds[0]
  };
  renderMovedReview(previous, splitIds[0]);
  show(`Steget delades i ${splitIds.length} delar.`);
}

function restoreReviewHistory(direction) {
  if (!activeReview) return;
  if (annotationEditorState &&
      !globalThis.T9ReviewAnnotationEditor.canRestoreAnnotation(
        activeReview,
        direction
      )) {
    $("annotationStatus").textContent =
      "Det finns ingen annoteringsändring att återställa.";
    return;
  }
  const previous = globalThis.T9ReviewMove.capturePositions($("reviewList"));
  const result = direction === "undo"
    ? globalThis.T9Review.undo(activeReview)
    : globalThis.T9Review.redo(activeReview);
  if (!result) return;
  if (annotationEditorState) {
    annotationEditorState = globalThis.T9ReviewAnnotationEditor.select(
      annotationEditorState,
      result.annotationSelection
    );
    annotationEditorState = globalThis.T9ReviewAnnotationEditor
      .reconcileSelection(
        annotationEditorState,
        annotationItems(annotationEditorState.screenshotRef)
      );
    annotationChangesPending = true;
    invalidateDocumentWorkspace();
    reviewAutoSave.schedule();
    renderActiveAnnotation();
    applyReviewToolbarState();
    $("annotationStatus").textContent = direction === "undo"
      ? "Annoteringsändringen ångrades."
      : "Annoteringsändringen gjordes om.";
    return;
  }
  activeReviewSelection = result.selection ||
    globalThis.T9ReviewSelection.reconcile(
      activeReviewSelection,
      reviewTaskIds()
    );
  renderMovedReview(previous, activeReviewSelection.activeId);
  if (result.entry.type.startsWith("annotation-")) {
    annotationChangesPending = true;
    reviewAutoSave.schedule();
  }
  show(direction === "undo" ? "Senaste ändringen ångrades." : "Ändringen gjordes om.");
}

function finishReviewEdit(control, commit) {
  if (!activeReviewEdit || !control) return;
  const edit = globalThis.T9ReviewEdit.result(activeReviewEdit);
  const formattedTextChanged = ["instruction", "userComment"].includes(edit.field) &&
    JSON.stringify(activeReviewEdit.instructionRuns) !==
      activeReviewEdit.originalInstructionRuns;
  if (commit && (edit.changed || formattedTextChanged)) {
    const revisionChanged = globalThis.T9ReviewEdit.hasRevisionConflict(
      activeReviewEdit, activeReview.updatedAt
    );
    const index = activeReview.tasks.findIndex(task => task.taskId === edit.taskId);
    if (index >= 0) {
      globalThis.T9Review.editTask(
        activeReview,
        index,
        edit.field === "instruction"
          ? { instruction: edit.value,
            instructionRuns: globalThis.T9TextFormat.normalizeInstructionRuns(
              activeReviewEdit.instructionRuns, edit.value
            ) }
          : edit.field === "userComment"
          ? { userComment: edit.value,
            commentRuns: globalThis.T9TextFormat.normalizeInstructionRuns(
              activeReviewEdit.instructionRuns, edit.value
            ) }
          : { [edit.field]: edit.value },
        {
          beforeSelection: activeReviewSelection,
          afterSelection: activeReviewSelection
        }
      );
      invalidateDocumentWorkspace();
      reviewAutoSave.schedule();
      $("reviewFooterText").textContent = "Ändringen sparas automatiskt.";
      if (revisionChanged) {
        $("reviewFooterText").textContent =
          "Steget ändrades under redigering. Din text bevarades och sparas.";
      }
    }
  } else if (!commit) {
    control.value = activeReviewEdit.originalValue;
  }
  if (edit.field === "userComment" && !control.value) {
    const card = control.closest("[data-review-task-id]");
    card.querySelector(".review-comment-section").hidden = true;
    card.querySelector('[data-action="add-comment"]').hidden = false;
  }
  if (edit.field === "userComment") {
    const reset = control.closest("[data-review-task-id]")
      ?.querySelector('[data-action="reset-comment"]');
    if (reset) reset.hidden = true;
  }
  control.readOnly = true;
  if (["instruction", "userComment"].includes(edit.field)) {
    control.hidden = true;
    const editor = control.closest("[data-review-task-id]")
      ?.querySelector(edit.field === "instruction"
        ? "[data-instruction-preview]" : "[data-comment-preview]");
    if (editor) {
      editor.contentEditable = "false";
      delete editor.dataset.editing;
    }
  }
  delete control.dataset.editing;
  activeReviewEdit = null;
  if (["instruction", "userComment"].includes(edit.field)) {
    renderReview();
    return;
  }
  applyReviewSelection();
}

function beginReviewEdit({ control, taskId, field }) {
  if (activeReviewEdit) {
    const current = $("reviewList").querySelector('[data-editing="true"]');
    finishReviewEdit(current, true);
  }
  activeReviewEdit = globalThis.T9ReviewEdit.createSession(
    taskId,
    field,
    control.value,
    activeReview.updatedAt
  );
  if (["instruction", "userComment"].includes(field)) {
    const task = globalThis.T9Review.activeTasks(activeReview)
      .find(candidate => candidate.taskId === taskId);
    const presentation = field === "instruction"
      ? reviewInstructionPresentation(task, documentInstructionPresentationsByTask())
      : { text: String(task?.userComment || ""),
        runs: globalThis.T9TextFormat.normalizeInstructionRuns(
          task?.commentRuns, String(task?.userComment || "")
        ) };
    control.value = presentation.text;
    const runs = presentation.runs;
    activeReviewEdit.instructionRuns = runs;
    activeReviewEdit.originalInstructionRuns = JSON.stringify(runs);
    activeReviewEdit.selectionStart = 0;
    activeReviewEdit.selectionEnd = control.value.length;
    const card = control.closest("[data-review-task-id]");
    card?.querySelector(field === "instruction"
      ? "[data-instruction-format-toolbar]" : "[data-comment-format-toolbar]")
      ?.removeAttribute("hidden");
    const editor = card?.querySelector(field === "instruction"
      ? "[data-instruction-preview]" : "[data-comment-preview]");
    if (editor) {
      editor.contentEditable = "true";
      editor.dataset.editing = "true";
      editor.scrollIntoView({ block: "nearest", inline: "nearest" });
      editor.focus({ preventScroll: true });
      const range = document.createRange();
      range.selectNodeContents(editor);
      const selection = globalThis.getSelection?.();
      selection?.removeAllRanges();
      selection?.addRange(range);
      updateInstructionToolbar(card, editor);
    }
    control.dataset.editing = "true";
    return;
  }
  control.readOnly = false;
  control.dataset.editing = "true";
  if (field === "userComment") updateCommentResetState(control);
  control.scrollIntoView({ block: "nearest", inline: "nearest" });
  control.focus({ preventScroll: true });
  control.select();
}

function updateCommentResetState(control) {
  const reset = control?.closest("[data-review-task-id]")
    ?.querySelector('[data-action="reset-comment"]');
  if (!reset) return;
  reset.hidden = control.dataset.editing !== "true";
  reset.disabled = control.value === (control.dataset.originalValue || "");
}

function editReviewField(card, taskId, field) {
  const control = card.querySelector(`[data-edit-field="${field}"]`);
  if (!control) return;
  beginReviewEdit({ control, taskId, field });
}

globalThis.T9ReviewEdit.bind($("reviewList"), {
  start: beginReviewEdit,
  update({ value }) {
    if (activeReviewEdit) {
      activeReviewEdit = globalThis.T9ReviewEdit.update(activeReviewEdit, value);
      if (activeReviewEdit.field === "instruction") {
        activeReviewEdit.instructionRuns = [{ text: value }];
        updateInstructionPreview(activeReviewEdit.taskId,
          activeReviewEdit.instructionRuns);
      }
      if (activeReviewEdit.field === "userComment") {
        const control = $("reviewList").querySelector(
          `[data-review-task-id="${CSS.escape(activeReviewEdit.taskId)}"] ` +
          '[data-edit-field="userComment"]'
        );
        updateCommentResetState(control);
      }
    }
  },
  commit({ control }) {
    finishReviewEdit(control, true);
  },
  cancel({ control }) {
    finishReviewEdit(control, false);
  }
});

function reviewImages(task) {
  if (!activeReviewModel) return [];
  const screenshotData = activeReviewModel.screenshotData || {};
  const paths = globalThis.T9Review.displayScreenshotAssetIds(
    task, Object.keys(screenshotData)
  );
  return paths
    .map(path => ({ path, imageUrl: activeReviewModel.screenshotData[path] }))
    .filter(image => Boolean(image.imageUrl));
}

let stepRepairState = null;

function stepRepairContext() {
  const state = stepRepairState;
  const review = activeReview;
  const session = activeReviewSession;
  const model = activeReviewModel;
  return { state, review, session, model, current: () =>
    Boolean(state && state === stepRepairState && review === activeReview &&
      session === activeReviewSession && model === activeReviewModel &&
      $("stepRepairDialog").open &&
      (review?.tasks?.[state.taskIndex]?.taskId ||
        review?.tasks?.[state.taskIndex]?.stepId) === state.taskId) };
}

function renderStepRepairGallery() {
  const gallery = $("stepRepairGallery");
  const task = activeReview?.tasks?.[stepRepairState?.taskIndex];
  const resolved = task ? globalThis.T9Review.resolveTask(task) : {};
  const assets = globalThis.T9ScreenshotGallery.derive(
    activeReviewModel?.screenshotData, resolved, stepRepairState?.capturedAssetId);
  gallery.innerHTML = assets.length ? assets.map(asset =>
    '<div class="step-repair-choice"><label>' +
    '<input type="radio" name="stepRepairScreenshot" value="' + escapeHtml(asset.id) + '" ' +
    (stepRepairState?.selectedAssetId === asset.id ? 'checked' : '') + '>' +
    '<img loading="lazy" src="' + escapeHtml(asset.imageUrl) + '" alt="' +
    escapeHtml(uiTf("review.imageNumber", { number: asset.number })) + '">' +
    '<span>' + escapeHtml(uiTf("review.imageNumber", { number: asset.number })) +
    ' · ' + escapeHtml(uiT("review.imageRole." + asset.role)) + '</span></label>' +
    '<button type="button" class="secondary" data-preview-asset="' + escapeHtml(asset.id) +
    '" aria-label="' + escapeHtml(uiTf("review.previewImageNumber", { number: asset.number })) +
    '">' + escapeHtml(uiT("review.previewImage")) + '</button></div>'
  ).join("") : '<p class="muted">' + uiT("review.noImages") + '</p>';
  for (const radio of gallery.querySelectorAll("input[type=radio]")) {
    radio.addEventListener("change", () => {
      if (!stepRepairState) return;
      stepRepairState.selectedAssetId = radio.value;
      $("applyStepRepair").disabled = false;
    });
  }
  for (const button of gallery.querySelectorAll("[data-preview-asset]")) {
    button.addEventListener("click", () => {
      const asset = assets.find(value => value.id === button.dataset.previewAsset);
      if (!asset) return;
      $("stepImagePreviewTitle").textContent = uiTf("review.previewImageNumber", { number: asset.number });
      $("stepImagePreviewImage").src = asset.imageUrl;
      $("stepImagePreviewImage").alt = uiTf("review.imageNumber", { number: asset.number });
      $("stepImagePreviewViewport").classList.remove("actual-size");
      $("stepImageActualSize").setAttribute("aria-pressed", "false");
      $("stepImagePreviewDialog").showModal();
    });
  }
  $("applyStepRepair").disabled = !assets.some(asset => asset.id === stepRepairState?.selectedAssetId);
}

$("stepImageActualSize").addEventListener("click", () => {
  const actual = $("stepImagePreviewViewport").classList.toggle("actual-size");
  $("stepImageActualSize").setAttribute("aria-pressed", String(actual));
});
$("stepImagePreviewDialog").addEventListener("close", () => {
  $("stepImagePreviewImage").removeAttribute("src");
});

function openStepRepair(taskIndex) {
  const task = activeReview?.tasks?.[taskIndex];
  if (!task || !activeReviewModel) return;
  stepRepairState = { taskIndex, taskId: task.taskId || task.stepId,
    selectedAssetId: globalThis.T9Review.resolveTask(task).selectedScreenshotAssetId || null,
    capturedAssetId: null, capturedAssetKey: null, capturedImage: null,
    capturedAt: null };
  $("stepRepairTitle").textContent = uiTf("review.changeImageForStep", {
    step: globalThis.T9Review.visibleTaskNumber(
      activeReview, task.taskId || task.stepId
    ) || taskIndex + 1
  });
  $("stepRepairStatus").textContent = "";
  $("captureStepRepairScreenshot").disabled = false;
  renderStepRepairGallery();
  $("stepRepairDialog").showModal();
}

$("captureStepRepairScreenshot").addEventListener("click", async () => {
  if (!stepRepairState || !activeReviewSession) return;
  const operation = stepRepairContext();
  if (!operation.current()) return;
  const button = $("captureStepRepairScreenshot");
  if (button.disabled) return;
  button.disabled = true;
  $("stepRepairStatus").textContent =
    "Tar en bild från den senast använda Business Central-fliken...";
  try {
    const response = await send({ type: "T9_CAPTURE_STEP_REPAIR_SCREENSHOT",
      sessionId: activeReviewSession.id, stepId: stepRepairState.taskId });
    if (!operation.current()) return;
    if (!response.ok) throw new Error(response.error ||
      "Skärmbilden kunde inte tas.");
    activeReviewModel.screenshotData[response.assetId] = response.image;
    stepRepairState.selectedAssetId = response.assetId;
    stepRepairState.capturedAssetId = response.assetId;
    stepRepairState.capturedAssetKey = response.assetKey;
    stepRepairState.capturedImage = response.image;
    stepRepairState.capturedAt = response.capturedAt;
    renderStepRepairGallery();
    $("stepRepairStatus").textContent =
      "Den nya bilden är vald. Bekräfta för att uppdatera steget.";
  } catch (error) {
    if (!operation.current()) return;
    $("stepRepairStatus").textContent = error.message;
  } finally {
    if (operation.current()) button.disabled = false;
  }
});

$("applyStepRepair").addEventListener("click", async () => {
  if (!stepRepairState?.selectedAssetId) return;
  const operation = stepRepairContext();
  if (!operation.current()) return;
  const selectedAssetId = operation.state.selectedAssetId;
  const button = $("applyStepRepair");
  if (button.disabled) return;
  button.disabled = true;
  const currentTask = activeReview?.tasks?.[stepRepairState.taskIndex];
  const currentAssetId = currentTask
    ? globalThis.T9Review.resolveTask(currentTask).selectedScreenshotAssetId
    : null;
  if (currentAssetId !== stepRepairState.selectedAssetId &&
      annotationItems(currentAssetId).length) {
    $("stepRepairStatus").textContent =
      "Den nuvarande bilden har markeringar. Ta bort dem innan bilden byts.";
    button.disabled = false;
    return;
  }
  if (stepRepairState.selectedAssetId === stepRepairState.capturedAssetId) {
    try {
      const saved = await send({ type: "T9_SAVE_STEP_REPAIR_SCREENSHOT",
        sessionId: activeReviewSession.id,
        assetKey: stepRepairState.capturedAssetKey,
        image: stepRepairState.capturedImage });
      if (!operation.current()) return;
      if (stepRepairState.selectedAssetId !== selectedAssetId) {
        button.disabled = false;
        return;
      }
      if (!saved.ok) throw new Error(saved.error || "Bilden kunde inte sparas.");
    } catch (error) {
      if (!operation.current()) return;
      $("stepRepairStatus").textContent = error.message;
      button.disabled = false;
      return;
    }
  }
  const availableAssetIds = Object.keys(activeReviewModel?.screenshotData || {});
  const result = globalThis.T9Review.repairTaskScreenshot(activeReview,
    stepRepairState.taskIndex, stepRepairState.selectedAssetId,
    availableAssetIds, { capturedAt: stepRepairState.capturedAt,
      beforeSelection: activeReviewSelection,
      afterSelection: activeReviewSelection });
  if (!result.ok) {
    $("stepRepairStatus").textContent = result.reason === "annotation-protected"
      ? "Den nuvarande bilden har markeringar. Ta bort dem innan bilden byts."
      : "Den valda bilden kan inte kopplas till steget.";
    button.disabled = false;
    return;
  }
  $("stepRepairDialog").close("apply");
  stepRepairState = null;
  reviewAutoSave.schedule();
  renderReview();
  show("Stegets skärmbild har reparerats.");
});

$("stepRepairDialog").addEventListener("close", () => {
  stepRepairState = null;
});

function annotationItems(screenshotRef) {
  return globalThis.T9ReviewAnnotations.findScreenshotSet(
    activeReview?.annotations,
    screenshotRef
  )?.items || [];
}

function renderAnnotationSvg(svg, image, screenshotRef, options = {}) {
  if (!image.naturalWidth || !image.naturalHeight) return;
  let items = [...annotationItems(screenshotRef)];
  if (options.preview) {
    items = items.map(annotation =>
      annotation.annotationId === options.preview.annotationId
        ? { ...annotation, geometry: options.preview.geometry }
        : annotation
    );
  }
  if (options.draft) {
    items.push({
      annotationId: "annotation-draft",
      type: options.draftType,
      geometry: options.draft,
      style: globalThis.T9ReviewAnnotations.DEFAULT_STYLES[options.draftType]
    });
  }
  globalThis.T9ReviewAnnotationSvg.render(
    svg,
    items,
    image.naturalWidth,
    image.naturalHeight,
    document,
    { selectedId: options.selectedId }
  );
}

function initializeReviewScreenshots(card, task, images) {
  for (const [index, imageData] of images.entries()) {
    const stage = card.querySelector(`[data-review-image-index="${index}"]`);
    const image = stage.querySelector("img");
    const svg = stage.querySelector("svg");
    const render = () => renderAnnotationSvg(svg, image, imageData.path);
    if (image.complete) render();
    else image.addEventListener("load", render, { once: true });
    stage.parentElement.querySelector('[data-action="annotate"]')
      .addEventListener("click", () => {
        openAnnotationEditor(task, imageData);
      });
  }
}

function renderActiveAnnotation(updateControls = true) {
  if (!annotationEditorState) return;
  renderAnnotationSvg(
    $("annotationSurface"),
    $("annotationImage"),
    annotationEditorState.screenshotRef,
    {
      draft: globalThis.T9ReviewAnnotationEditor.geometry(
        annotationEditorState
      ),
      draftType: annotationEditorState.draft?.type,
      preview: annotationEditorState.translation && {
        annotationId: annotationEditorState.translation.annotationId,
        geometry: annotationEditorState.translation.geometry
      },
      selectedId: annotationEditorState.selectedId
    }
  );
  if (updateControls) renderAnnotationControls();
}

function releaseActiveAnnotationPointer() {
  const pointerId = annotationEditorState?.pointerId;
  globalThis.T9ReviewAnnotationEditor.releasePointer(
    $("annotationSurface"),
    pointerId
  );
  if (annotationEditorState) {
    annotationEditorState = { ...annotationEditorState, pointerId: null };
  }
}

function annotationById(annotationId) {
  return annotationItems(annotationEditorState?.screenshotRef)
    .find(annotation => annotation.annotationId === annotationId) || null;
}

function annotationGeometryFields(annotation) {
  if (annotation.type === "arrow") {
    return [
      ["startX", "Start X"],
      ["startY", "Start Y"],
      ["endX", "Slut X"],
      ["endY", "Slut Y"]
    ];
  }
  return [
    ["x", "X"],
    ["y", "Y"],
    ["width", "Bredd"],
    ["height", "Höjd"]
  ];
}

function renderAnnotationControls() {
  if (!annotationEditorState) return;
  const items = annotationItems(annotationEditorState.screenshotRef)
    .filter(annotation => {
      const result = globalThis.T9ReviewAnnotations.validation(annotation);
      return result.valid && result.supported;
    });
  const selected = items.find(
    annotation => annotation.annotationId === annotationEditorState.selectedId
  );
  annotationEditorState = globalThis.T9ReviewAnnotationEditor
    .reconcileSelection(annotationEditorState, items);
  publishWorkspaceContext({
    selectedStepId: annotationEditorState.taskId,
    selectedScreenshotId: annotationEditorState.screenshotRef,
    selectedAnnotationId: annotationEditorState.selectedId,
    scrollAnchor: annotationEditorState.screenshotRef
  }, "annotation-selection", "review");
  $("rectangleAnnotationTool").setAttribute(
    "aria-pressed",
    String(annotationEditorState.tool === "rectangle")
  );
  $("arrowAnnotationTool").setAttribute(
    "aria-pressed",
    String(annotationEditorState.tool === "arrow")
  );
  $("deleteAnnotation").disabled = !selected;
  $("annotationList").innerHTML = items.map((annotation, index) => {
    const type = annotation.type === "arrow" ? "Pil" : "Rektangel";
    return `<li><button class="secondary" data-annotation-id="${escapeHtml(annotation.annotationId)}"
      aria-current="${annotation.annotationId === annotationEditorState.selectedId}">${type} ${index + 1}</button></li>`;
  }).join("");
  if (!selected) {
    $("annotationProperties").innerHTML =
      '<p class="muted">Välj en markering för att ändra dess geometri.</p>';
    return;
  }
  $("annotationProperties").innerHTML = annotationGeometryFields(selected)
    .map(([key, label]) => `<label>${label}
      <input type="number" min="0" max="100" step="1"
        data-annotation-geometry="${key}"
        value="${Math.round(selected.geometry[key] * 100)}">
    </label>`)
    .join("") +
    '<div class="annotation-properties-actions"><button data-action="apply-annotation-geometry" class="primary">Tillämpa</button></div>';
}

function updateAnnotationStickyOffset() {
  if (!annotationEditorState) return;
  const reviewHeader = $("reviewDialog").querySelector(".review-header");
  $("reviewDialog").style.setProperty(
    "--review-header-height",
    `${reviewHeader.offsetHeight}px`
  );
}

function openAnnotationEditor(task, imageData) {
  annotationEditorBaseline = globalThis.T9ReviewAnnotationEditor.baseline(
    activeReview
  );
  annotationEditorState = globalThis.T9ReviewAnnotationEditor.create({
    taskId: task.taskId,
    screenshotRef: imageData.path,
    imageUrl: imageData.imageUrl
  });
  publishWorkspaceContext({
    selectedStepId: task.taskId,
    selectedScreenshotId: imageData.path,
    selectedAnnotationId: null,
    scrollAnchor: imageData.path
  }, "screenshot-selection", "review");
  $("documentWorkspaceTab").disabled = true;
  $("reviewDialog").classList.add("annotation-mode");
  updateAnnotationStickyOffset();
  $("reviewList").hidden = true;
  $("reviewFooter").hidden = true;
  $("annotationEditor").hidden = false;
  const visibleStepNumber = globalThis.T9Review.visibleTaskNumber(
    activeReview,
    task.taskId
  );
  $("annotationTitle").textContent = uiTf("review.editImageForStep", {
    step: visibleStepNumber ?? task.taskNo
  });
  $("annotationImage").src = imageData.imageUrl;
  renderAnnotationControls();
  if ($("annotationImage").complete) renderActiveAnnotation();
  $("annotationSurface").focus();
}

async function closeAnnotationEditor(options = {}) {
  if (!annotationEditorState) return;
  const taskId = annotationEditorState.taskId;
  releaseActiveAnnotationPointer();
  annotationEditorState = globalThis.T9ReviewAnnotationEditor.cancel(
    annotationEditorState
  );
  if (options.cancel) {
    reviewAutoSave.cancel();
    activeReview = globalThis.T9ReviewAnnotationEditor.restoreBaseline(
      activeReview,
      annotationEditorBaseline
    );
    annotationChangesPending = true;
    await saveActiveReview({ render: false, announce: false });
    await reviewSaveQueue.flush();
  } else {
    $("annotationStatus").textContent = "Sparar annoteringar.";
    await flushReviewPersistence();
  }
  annotationEditorState = null;
  annotationEditorBaseline = null;
  $("documentWorkspaceTab").disabled = false;
  $("annotationEditor").hidden = true;
  $("reviewList").hidden = false;
  $("reviewFooter").hidden = false;
  $("reviewDialog").classList.remove("annotation-mode");
  $("reviewDialog").style.removeProperty("--review-header-height");
  renderReview();
  const card = [...$("reviewList").querySelectorAll("[data-review-task-id]")]
    .find(element => element.dataset.reviewTaskId === taskId);
  card?.querySelector('[data-action="annotate"]')?.focus();
}

function markAnnotationsChanged(message) {
  annotationChangesPending = true;
  invalidateDocumentWorkspace();
  reviewAutoSave.schedule();
  renderActiveAnnotation();
  $("annotationStatus").textContent =
    `${message} Väntar på automatisk sparning.`;
  $("reviewFooterText").textContent =
    "Annoteringen väntar på automatisk sparning.";
}

function addAnnotation(type, geometry) {
  if (!annotationEditorState) return false;
  try {
    const annotation = globalThis.T9ReviewAnnotations.createAnnotation(
      type,
      geometry
    );
    globalThis.T9Review.addAnnotation(
      activeReview,
      annotationEditorState.screenshotRef,
      annotation,
      {
        beforeAnnotationSelection: annotationEditorState.selectedId,
        afterAnnotationSelection: annotation.annotationId
      }
    );
    annotationEditorState = globalThis.T9ReviewAnnotationEditor.select(
      annotationEditorState,
      annotation.annotationId
    );
    markAnnotationsChanged(type === "arrow" ? "Pil tillagd." : "Rektangel tillagd.");
    return true;
  } catch (error) {
    $("annotationStatus").textContent =
      `Markeringen kunde inte läggas till: ${error.message}`;
    return false;
  }
}

function updateAnnotation(annotationId, geometry, message, options = {}) {
  if (!annotationEditorState) return false;
  try {
    const before = annotationById(annotationId);
    const updated = globalThis.T9Review.updateAnnotation(
      activeReview,
      annotationEditorState.screenshotRef,
      annotationId,
      { geometry },
      {
        type: options.type,
        groupKey: options.groupKey,
        beforeAnnotationSelection: annotationEditorState.selectedId,
        afterAnnotationSelection: annotationId
      }
    );
    if (!updated) return false;
    if (JSON.stringify(before) === JSON.stringify(updated)) {
      renderActiveAnnotation();
      return true;
    }
    markAnnotationsChanged(message || "Markeringen uppdaterades.");
    return true;
  } catch (error) {
    $("annotationStatus").textContent =
      `Markeringen kunde inte uppdateras: ${error.message}`;
    return false;
  }
}

function deleteSelectedAnnotation() {
  const annotationId = annotationEditorState?.selectedId;
  if (!annotationId) return false;
  releaseActiveAnnotationPointer();
  const removed = globalThis.T9Review.removeAnnotation(
    activeReview,
    annotationEditorState.screenshotRef,
    annotationId,
    {
      beforeAnnotationSelection: annotationId,
      afterAnnotationSelection: null
    }
  );
  if (!removed) return false;
  annotationEditorState = globalThis.T9ReviewAnnotationEditor.select(
    annotationEditorState,
    null
  );
  markAnnotationsChanged("Markeringen togs bort.");
  $("annotationSurface").focus();
  return true;
}

function documentInstructionPresentationsByTask() {
  const result = new Map();
  try {
    const documentModel = createActiveDocumentPresentation()
      .presentationDocument;
    const visit = blocks => {
      for (const block of blocks || []) {
        if (block.kind === "step" && block.sourceRef?.taskId) {
          const paragraph = block.blocks?.find(child =>
            child.kind === "paragraph" && Array.isArray(child.presentationRuns)
          );
          if (paragraph) result.set(block.sourceRef.taskId, {
            text: paragraph.text,
            runs: paragraph.presentationRuns
          });
        }
        visit(block.blocks);
      }
    };
    for (const section of documentModel.sections || []) visit(section.blocks);
  } catch {
    // Review remains usable while an incomplete document is being assembled.
  }
  return result;
}

function screenshotQualityByTask() {
  return activeScreenshotQualityCache.get([
    activeReviewModel,
    activeReview,
    workspaceState.revision,
    activeDocumentProfileId
  ], () => {
    const result = new Map();
    try {
      const presentation = createActiveDocumentPresentation();
      const profile = documentProfiles().find(value =>
        value.profileId === activeDocumentProfileId) || documentProfiles()[0];
      const selection = globalThis.T9ScreenshotIntelligence.select(
        presentation.presentationDocument,
        { candidates: screenshotCandidatesFor(activeReviewModel, activeReview),
          profile }
      );
      selection.selections.forEach(value => {
        if (value.taskId) result.set(value.taskId, value);
      });
    } catch {
      // Screenshot quality is advisory and must never block Review rendering.
    }
    return result;
  });
}

function reviewInstructionPresentation(task, documentPresentations = null) {
  const sourceText = String(task?.instruction || "");
  try {
    const reviewText = globalThis.T9TextFormat.quoteEmphasis(sourceText);
    const documentPresentation = documentPresentations?.get(task?.taskId);
    const automatic = globalThis.T9PresentationGrammar.presentationFor(
      task?.semanticActionModel || task,
      sourceText, activeDocumentLanguage()
    ).runs.map(run => ({
      text: run.text,
      ...(run.bold ? { bold: true } : {}),
      ...(run.italic ? { italic: true } : {}),
      ...(run.monospace ? { monospace: true } : {})
    }));
    return globalThis.T9TextFormat.resolveInstructionPresentation({
      reviewText,
      reviewRuns: task?.instructionRuns,
      reviewRunsUserEdited:
        task?.fieldProvenance?.instructionRuns === "user-edited",
      documentPresentation,
      automaticRuns: automatic
    });
  } catch (error) {
    console.warn("Instruction presentation fallback", {
      taskId: task?.taskId,
      error: error?.message
    });
    return { text: sourceText, runs: [{ text: sourceText }] };
  }
}

function instructionRunsHtml(runs) {
  return runs.map(run => {
    const data = [
      run.bold ? ' data-format-bold="true"' : "",
      run.italic ? ' data-format-italic="true"' : "",
      run.monospace ? ' data-format-monospace="true"' : "",
      run.fontFamily
        ? ` data-font-family="${escapeHtml(run.fontFamily)}"` : "",
      run.fontSize ? ` data-font-size="${run.fontSize}"` : "",
      run.textColor ? ` data-text-color="${run.textColor}"` : "",
      run.backgroundColor
        ? ` data-background-color="${run.backgroundColor}"` : ""
    ].join("");
    return `<span${data}>${escapeHtml(run.text)}</span>`;
  }).join("");
}

function resolveReviewHierarchyForDisplay(tasks, hierarchy) {
  try {
    return globalThis.T9DocumentationHierarchy.resolve(tasks, hierarchy);
  } catch (error) {
    console.warn("Review hierarchy display fallback", {
      error: error?.message,
      taskCount: tasks.length
    });
    return { sections: [] };
  }
}

function reviewTasksForDisplay(review) {
  let visible = [];
  let activeTasksError = null;
  try {
    visible = globalThis.T9Review.activeTasks(review);
  } catch (error) {
    activeTasksError = error;
    console.error("Review active-task resolution failed", error);
  }
  if (visible.length || !review?.tasks?.length) {
    return { tasks: visible, recovered: false, error: activeTasksError };
  }
  const recoverable = review.tasks.filter(task =>
    !task?.deleted &&
    task?.stepOverride?.visibilityOverride !== "hidden"
  ).map(task => {
    try {
      return globalThis.T9StepEditor.resolve(task);
    } catch {
      return task;
    }
  });
  if (recoverable.length) {
    console.warn("Review visibility fallback", {
      storedTaskCount: review.tasks.length,
      recoveredTaskCount: recoverable.length
    });
  }
  return {
    tasks: recoverable,
    recovered: recoverable.length > 0,
    error: activeTasksError
  };
}

function renderStoredReviewFallback(error) {
  const list = $("reviewList");
  list.hidden = false;
  list.innerHTML = "";
  const stored = (activeReview?.tasks || []).filter(task =>
    !task?.deleted && task?.stepOverride?.visibilityOverride !== "hidden"
  );
  stored.forEach((storedTask, index) => {
    let task = storedTask;
    try { task = globalThis.T9StepEditor.resolve(storedTask); } catch {}
    const card = document.createElement("article");
    card.className = "review-card pending";
    card.dataset.reviewTaskId = task?.taskId || `stored-task-${index + 1}`;
    const instruction = String(task?.instruction || task?.description ||
      "Steget saknar instruktion.");
    card.innerHTML = `<div class="review-number">${index + 1}</div>
      <div class="review-fields"><div class="review-field-heading">Instruktion</div>
      <p>${escapeHtml(instruction)}</p></div>
      <div class="review-actions"><span class="muted">Säkert visningsläge</span></div>`;
    list.appendChild(card);
  });
  list.setAttribute("aria-rowcount", String(stored.length));
  const reason = String(error?.message || "okänt renderingsfel");
  show(`Stegen visas i säkert läge. Renderingsfel: ${reason}`, true);
  console.error("Review rendering fallback", error);
}

function knowledgeExplanationMarkup(task) {
  if (!(Number(task?.contextualExplanationConfidence) >= 0.85) ||
      !task?.contextualExplanationRuleId ||
      !(task?.contextualExplanationSources || []).some(source =>
        /^https:\/\/learn\.microsoft\.com\//i.test(source?.sourceUri || ""))) return "";
  const language = activeDocumentLanguage();
  const explanations = task.contextualExplanations || {};
  const explanation = explanations[language] || explanations[language.split("-")[0]] ||
    explanations["en-US"] || "";
  if (!explanation) return "";
  const labels = {
    "sv-SE": ["Vad åtgärden innebär", "Källa"],
    "en-US": ["What this action does", "Source"],
    "fr-FR": ["Ce que fait cette action", "Source"],
    "de-DE": ["Was diese Aktion bewirkt", "Quelle"],
    "es-ES": ["Qué hace esta acción", "Fuente"],
    "da-DK": ["Hvad handlingen gør", "Kilde"],
    "fi-FI": ["Mitä toiminto tekee", "Lähde"],
    "nb-NO": ["Hva handlingen gjør", "Kilde"]
  };
  const includeLabels = { "sv-SE": "Ta med förklaringen i Word",
    "en-US": "Include explanation in Word", "fr-FR": "Inclure l’explication dans Word",
    "de-DE": "Erklärung in Word übernehmen", "es-ES": "Incluir explicación en Word",
    "da-DK": "Medtag forklaringen i Word", "fi-FI": "Sisällytä selitys Wordiin",
    "nb-NO": "Ta med forklaringen i Word" };
  const [heading, sourceLabel] = labels[language] || labels["en-US"];
  const sources = task.contextualExplanationSources || [];
  const localePath = `/${language.toLowerCase()}/`;
  const source = sources.find(item => item.sourceUri?.includes(localePath)) ||
    sources.find(item => item.sourceUri?.includes("/en-us/")) || sources[0];
  const sourceUri = /^https:\/\/learn\.microsoft\.com\//i.test(source?.sourceUri || "")
    ? source.sourceUri : "";
  return `<aside class="review-knowledge-explanation" data-knowledge-explanation>
    <strong>${escapeHtml(heading)}</strong><p>${escapeHtml(explanation)}</p>
    ${sourceUri ? `<span class="review-knowledge-source">${escapeHtml(sourceLabel)}: <a href="${escapeHtml(sourceUri)}" target="_blank" rel="noopener noreferrer">${escapeHtml(source.title || "Microsoft Learn")}</a></span>` : ""}
    <label class="review-knowledge-export-choice"><input type="checkbox"
      data-include-knowledge-explanation-in-word
      ${task.includeKnowledgeExplanationInWord === true ? "checked" : ""}>
      <span>${escapeHtml(includeLabels[language] || includeLabels["en-US"])}</span></label>
  </aside>`;
}

function updateInstructionPreview(taskId, runs) {
  const card = [...$("reviewList").querySelectorAll("[data-review-task-id]")]
    .find(element => element.dataset.reviewTaskId === taskId);
  const preview = card?.querySelector(activeReviewEdit?.field === "userComment"
    ? "[data-comment-preview]" : "[data-instruction-preview]");
  if (preview) {
    preview.innerHTML = instructionRunsHtml(runs);
    if (preview.dataset.editing === "true") {
      restoreInstructionSelection(preview,
        activeReviewEdit.selectionStart, activeReviewEdit.selectionEnd);
    }
  }
}

function instructionSelectionOffsets(editor) {
  const selection = globalThis.getSelection?.();
  if (!selection?.rangeCount || !editor.contains(selection.anchorNode) ||
      !editor.contains(selection.focusNode)) return null;
  const offset = (node, position) => {
    const range = document.createRange();
    range.selectNodeContents(editor);
    range.setEnd(node, position);
    return range.toString().length;
  };
  const anchor = offset(selection.anchorNode, selection.anchorOffset);
  const focus = offset(selection.focusNode, selection.focusOffset);
  return { start: Math.min(anchor, focus), end: Math.max(anchor, focus) };
}

function restoreInstructionSelection(editor, start, end) {
  const range = document.createRange();
  const selection = globalThis.getSelection?.();
  let offset = 0;
  let startPoint = null;
  let endPoint = null;
  const walker = document.createTreeWalker(editor, NodeFilter.SHOW_TEXT);
  let node;
  while ((node = walker.nextNode())) {
    const next = offset + node.textContent.length;
    if (!startPoint && start <= next) startPoint = [node, start - offset];
    if (!endPoint && end <= next) { endPoint = [node, end - offset]; break; }
    offset = next;
  }
  const fallback = editor.lastChild || editor;
  const fallbackOffset = fallback.nodeType === Node.TEXT_NODE
    ? fallback.textContent.length : fallback.childNodes.length;
  startPoint ||= [fallback, fallbackOffset];
  endPoint ||= [fallback, fallbackOffset];
  range.setStart(...startPoint);
  range.setEnd(...endPoint);
  selection?.removeAllRanges();
  selection?.addRange(range);
}

function instructionRunsFromEditor(editor) {
  const runs = [];
  const visit = (node, format = {}) => {
    if (node.nodeType === Node.TEXT_NODE) {
      if (node.textContent) runs.push({ text: node.textContent, ...format });
      return;
    }
    if (node.nodeType !== Node.ELEMENT_NODE) return;
    const style = node.style || {};
    const fontFamily = node.dataset.fontFamily || style.fontFamily;
    const fontSize = Number(node.dataset.fontSize || parseFloat(style.fontSize));
    const next = {
      ...format,
      ...(node.dataset.formatBold === "true" ||
          style.fontWeight === "700" || style.fontWeight === "bold"
        ? { bold: true } : {}),
      ...(node.dataset.formatItalic === "true" || style.fontStyle === "italic"
        ? { italic: true } : {}),
      ...(node.dataset.formatMonospace === "true" ||
          style.fontFamily === "monospace" ? { monospace: true } : {}),
      ...(globalThis.T9TextFormat.FONT_FAMILIES.includes(fontFamily)
        ? { fontFamily } : {}),
      ...(globalThis.T9TextFormat.FONT_SIZES.includes(fontSize)
        ? { fontSize } : {}),
      ...(globalThis.T9TextFormat.COLORS.some(color =>
        color.value === node.dataset.textColor)
        ? { textColor: node.dataset.textColor } : {}),
      ...(globalThis.T9TextFormat.COLORS.some(color =>
        color.value === node.dataset.backgroundColor)
        ? { backgroundColor: node.dataset.backgroundColor } : {})
    };
    for (const child of node.childNodes) visit(child, next);
  };
  for (const child of editor.childNodes) visit(child);
  return runs;
}

function rememberInstructionSelection(editor) {
  if (!activeReviewEdit ||
      !["instruction", "userComment"].includes(activeReviewEdit.field)) return;
  const offsets = instructionSelectionOffsets(editor);
  if (!offsets) return;
  activeReviewEdit.selectionStart = offsets.start;
  activeReviewEdit.selectionEnd = offsets.end;
}

function restoreInstructionSelection(editor, start, end) {
  const range = document.createRange();
  const selection = globalThis.getSelection?.();
  if (!selection) return;
  let offset = 0;
  let startPoint = null;
  let endPoint = null;
  const visit = node => {
    if (node.nodeType === Node.TEXT_NODE) {
      const next = offset + node.textContent.length;
      if (!startPoint && start >= offset && start <= next) {
        startPoint = [node, start - offset];
      }
      if (!endPoint && end >= offset && end <= next) {
        endPoint = [node, end - offset];
      }
      offset = next;
      return;
    }
    for (const child of node.childNodes) visit(child);
  };
  visit(editor);
  if (!startPoint || !endPoint) return;
  range.setStart(...startPoint);
  range.setEnd(...endPoint);
  selection.removeAllRanges();
  selection.addRange(range);
}

function selectedInstructionRuns(editor) {
  if (!activeReviewEdit) return [];
  rememberInstructionSelection(editor);
  let from = activeReviewEdit.selectionStart ?? 0;
  let to = activeReviewEdit.selectionEnd ?? 0;
  if (from > to) [from, to] = [to, from];
  const collapsed = from === to;
  const runs = activeReviewEdit.instructionRuns || [];
  if (collapsed) {
    let caretOffset = 0;
    return runs.filter((run, index) => {
      const start = caretOffset;
      const end = caretOffset + run.text.length;
      caretOffset = end;
      return (from >= start && from < end) ||
        (index === runs.length - 1 && from === end);
    });
  }
  let offset = 0;
  return runs.filter(run => {
    const start = offset;
    const end = offset + run.text.length;
    offset = end;
    return start < to && end > from;
  });
}

function setFormattingSelect(select, value, mixed) {
  select.querySelector('[data-mixed-format]')?.remove();
  if (mixed) {
    const option = document.createElement("option");
    option.value = "";
    option.textContent = "Blandat";
    option.dataset.mixedFormat = "true";
    select.prepend(option);
    select.value = "";
  } else {
    select.value = String(value);
  }
  if (select.dataset.colorSelect !== undefined) {
    select.style.backgroundColor = mixed ? "" : value;
    select.style.color = !mixed && ["#000000", "#0F4C81", "#008C95",
      "#C50F1F", "#107C10", "#CA5010"].includes(value)
      ? "#FFFFFF" : "#000000";
  }
}

function updateInstructionToolbar(card, editor) {
  const prefix = activeReviewEdit?.field === "userComment"
    ? "comment" : "instruction";
  const runs = selectedInstructionRuns(editor);
  const common = (property, fallback) => {
    const values = runs.map(run => run[property] ?? fallback);
    return { value: values[0] ?? fallback,
      mixed: values.some(value => value !== (values[0] ?? fallback)) };
  };
  const font = common("fontFamily", "Arial");
  const size = common("fontSize", 11);
  const textColor = common("textColor", "#000000");
  const backgroundColor = common("backgroundColor", "#FFFFFF");
  for (const property of ["bold", "italic"]) {
    const state = common(property, false);
    const button = card.querySelector(
      `[data-${prefix}-format="${property}"]`
    );
    button?.setAttribute("aria-pressed",
      state.mixed ? "mixed" : String(Boolean(state.value)));
  }
  setFormattingSelect(card.querySelector(`[data-${prefix}-font]`),
    font.value, font.mixed);
  setFormattingSelect(card.querySelector(`[data-${prefix}-size]`),
    size.value, size.mixed);
  setFormattingSelect(card.querySelector(`[data-${prefix}-text-color]`),
    textColor.value, textColor.mixed);
  setFormattingSelect(card.querySelector(`[data-${prefix}-background-color]`),
    backgroundColor.value, backgroundColor.mixed);
}

function applyInstructionFormatting(control, editor, patch) {
  if (!activeReviewEdit ||
      !["instruction", "userComment"].includes(activeReviewEdit.field)) return;
  rememberInstructionSelection(editor);
  activeReviewEdit.instructionRuns = globalThis.T9TextFormat.applyInstructionFormat(
    activeReviewEdit.instructionRuns,
    control.value,
    activeReviewEdit.selectionStart,
    activeReviewEdit.selectionEnd,
    patch
  );
  updateInstructionPreview(activeReviewEdit.taskId,
    activeReviewEdit.instructionRuns);
  editor.focus({ preventScroll: true });
  restoreInstructionSelection(editor, activeReviewEdit.selectionStart,
    activeReviewEdit.selectionEnd);
  updateInstructionToolbar(editor.closest("[data-review-task-id]"), editor);
}

function renderExternalKnowledgeSuggestions() {
  const section = $("reviewExternalKnowledgeSuggestions");
  const list = $("reviewExternalKnowledgeSuggestionList");
  if (!section || !list) return;
  list.replaceChildren();
  const lookup = activeReviewModel?.externalKnowledgeLookup;
  const suggestions = lookup?.suggestions || [];
  section.hidden = !lookup?.enabled;
  const status = $("reviewExternalKnowledgeStatus");
  if (status) {
    status.textContent = lookup?.status === "no-unresolved"
      ? uiT("review.externalKnowledgeNoUnresolved")
      : lookup?.status === "no-suggestions"
        ? uiTf("review.externalKnowledgeNoSuggestions", {
          count: lookup.requestCount
        })
        : lookup?.status === "unavailable"
          ? uiT("review.externalKnowledgeUnavailable") : "";
    status.hidden = !status.textContent;
  }
  for (const suggestion of suggestions) {
    const item = document.createElement("li");
    const task = activeReviewModel.businessTasks.find(candidate =>
      candidate.taskId === suggestion.taskId);
    const candidate = suggestion.candidate || {};
    const value = suggestion.kind === "object"
      ? `${candidate.objectRef?.objectType || ""} ${candidate.objectRef?.objectId || ""}`.trim()
      : `${candidate.action?.semanticAction || ""} — ${candidate.action?.entity || ""}`.trim();
    const heading = document.createElement("strong");
    heading.textContent = `${suggestion.kind === "object"
      ? uiT("review.externalKnowledgeObject")
      : uiT("review.externalKnowledgeAction")}: ${value || uiT("Okänt förslag")}`;
    const details = document.createElement("p");
    const source = candidate.provenance?.sourceId || "MCP";
    const version = candidate.provenance?.sourceVersion || "";
    details.textContent = uiTf("review.externalKnowledgeMeta", {
      step: task ? String(activeReviewModel.businessTasks.indexOf(task) + 1) : "?",
      confidence: Math.round(Math.min(0.69, Number(candidate.confidence) || 0) * 100),
      source: `${source}${version ? `@${version}` : ""}`
    });
    item.append(heading, details);
    list.append(item);
  }
}

function renderReviewContent() {
  invalidateDocumentWorkspace();
  const list = $("reviewList");
  const expectedResultEditor = $("expectedResultEditor");
  if (document.activeElement !== expectedResultEditor) {
    expectedResultEditor.value = displayedExpectedResult();
  }
  $("reviewDocumentLanguage").value = activeDocumentLanguage();
  renderDocumentProfileChoice();

  const displayTasks = reviewTasksForDisplay(activeReview);
  const tasks = globalThis.T9ProcessTaskContext.enrichForDisplay(
    displayTasks.tasks, activeReviewModel?.businessTasks || []
  );
  const documentPresentations = documentInstructionPresentationsByTask();
  const screenshotQualities = screenshotQualityByTask();
  const progress = globalThis.T9Review.progress(activeReview);
  list.innerHTML = "";
  renderExternalKnowledgeSuggestions();

  $("reviewProgressBar").style.width = `${progress}%`;
  $("reviewProgress").setAttribute("aria-valuenow", String(progress));
  list.setAttribute("aria-rowcount", String(tasks.length));
  renderReviewAttention(tasks);
  $("reviewFooterText").textContent =
    annotationChangesPending
      ? "Annoteringar har ändrats. Välj Spara för att lagra dem."
      : activeReview.status === "completed"
      ? "Granskningen är slutförd."
      : "Ändringar sparas lokalt i Edge.";

  tasks.forEach((task, visibleIndex) => {
    const actualIndex = activeReview.tasks.findIndex(candidate =>
      candidate.taskId === task.taskId
    );
    const card = document.createElement("article");
    const userEdited = !task.approved && (task.reviewStatus === "edited" ||
      Boolean(task.stepOverride) || Boolean(task.userComment) ||
      Boolean(task.manualStepId) || task.provenance === "manual");
    const reviewState = task.approved ? "approved"
      : userEdited ? "edited" : "pending";
    const reviewStateLabel = task.approved ? uiT("Godkänt")
      : userEdited ? uiT("Ändrad") : uiT("Ej granskat");
    card.dataset.reviewTaskId = task.taskId;
    card.dataset.reviewState = reviewState;
    card.setAttribute("role", "row");
    card.setAttribute("aria-rowindex", String(visibleIndex + 1));
    card.setAttribute("aria-label",
      `${uiT("Steg")} ${visibleIndex + 1}, ${reviewStateLabel}`);
    card.className = `review-card ${reviewState}`;

    const images = reviewImages(task);
    const instructionPresentation = reviewInstructionPresentation(task,
      documentPresentations);
    const generatedComment = globalThis.T9StepEditor.generated(
      activeReview.tasks[actualIndex]
    ).comment;
    const commentRuns = globalThis.T9TextFormat.normalizeInstructionRuns(
      task.commentRuns, task.userComment || ""
    );
    const screenshotQuality = screenshotQualities.get(task.taskId);
    const qualityLevel = screenshotQuality?.qualityLevel || "";
    const qualityMetrics = screenshotQuality?.selectedScore === null ||
      screenshotQuality?.selectedScore === undefined ? "" :
      `${uiT("review.imageScore")}: ${screenshotQuality.selectedScore}` +
      (screenshotQuality.scoreMargin === null ||
        screenshotQuality.scoreMargin === undefined ? "" :
        ` · ${uiT("review.imageMargin")}: ${screenshotQuality.scoreMargin}`);

    card.innerHTML = `
      <div class="review-number" role="gridcell">${visibleIndex + 1}</div>
      <div class="review-fields" role="gridcell">
        <div class="review-field-heading">
          <span class="review-field-title">
            <label for="review-instruction-${visibleIndex}">Instruktion</label>
            <span class="review-state-label ${reviewState}">${reviewStateLabel}</span>
          </span>
          <button data-action="edit-instruction" class="secondary"
            aria-label="${uiTf("a11y.editInstruction", { step: visibleIndex + 1 })}">Redigera</button>
        </div>
        <div id="review-instruction-preview-${visibleIndex}"
          class="review-instruction-preview" data-field="instruction"
          data-instruction-preview tabindex="0">${instructionRunsHtml(instructionPresentation.runs)}</div>
        ${knowledgeExplanationMarkup(task)}
        <div class="instruction-format-toolbar" data-instruction-format-toolbar hidden
          role="toolbar" aria-label="${uiT("a11y.textFormatting")}">
          <button type="button" class="secondary" data-instruction-format="bold"
            aria-label="${uiT("a11y.bold")}" aria-pressed="false"><strong>F</strong></button>
          <button type="button" class="secondary" data-instruction-format="italic"
            aria-label="${uiT("a11y.italic")}" aria-pressed="false"><em>K</em></button>
          <label>Typsnitt<select data-instruction-font>
            ${globalThis.T9TextFormat.FONT_FAMILIES.map(font =>
              `<option value="${escapeHtml(font)}" ${font === "Arial" ? "selected" : ""}>${escapeHtml(font)}</option>`).join("")}
          </select></label>
          <label>Storlek<select data-instruction-size>
            ${globalThis.T9TextFormat.FONT_SIZES.map(size =>
              `<option value="${size}" ${size === 11 ? "selected" : ""}>${size} pt</option>`).join("")}
          </select></label>
          <label>Textfärg<select data-instruction-text-color data-color-select>
            ${globalThis.T9TextFormat.COLORS.map(color =>
              `<option value="${color.value}" style="background:${color.value};color:${["#000000", "#0F4C81", "#008C95", "#C50F1F", "#107C10", "#CA5010"].includes(color.value) ? "#FFFFFF" : "#000000"}">${escapeHtml(color.name)}</option>`).join("")}
          </select></label>
          <label>Bakgrund<select data-instruction-background-color data-color-select>
            ${globalThis.T9TextFormat.COLORS.map(color =>
              `<option value="${color.value}" style="background:${color.value};color:${["#000000", "#0F4C81", "#008C95", "#C50F1F", "#107C10", "#CA5010"].includes(color.value) ? "#FFFFFF" : "#000000"}">${escapeHtml(color.name)}</option>`).join("")}
          </select></label>
        </div>
        <textarea id="review-instruction-${visibleIndex}" data-edit-field="instruction" hidden
          aria-label="${uiTf("a11y.instruction", { step: visibleIndex + 1 })}"
          aria-keyshortcuts="Enter Control+Enter Meta+Enter Escape"
          title="${uiT("a11y.editorHelp")}"
          readonly>${escapeHtml(instructionPresentation.text)}</textarea>
        <div class="review-comment-section" ${task.userComment ? "" : "hidden"}>
          <div class="review-field-heading">
            <label for="review-comment-${visibleIndex}">Kommentar</label>
            <span>
              <button data-action="reset-comment" class="secondary" hidden
                ${task.userComment === generatedComment ? "disabled" : ""}
                aria-label="${uiTf("a11y.resetComment", { step: visibleIndex + 1 })}">Återställ text</button>
              <button data-action="edit-comment" class="secondary"
                aria-label="${uiTf("a11y.editComment", { step: visibleIndex + 1 })}">Redigera</button>
            </span>
          </div>
          <div id="review-comment-preview-${visibleIndex}"
            class="review-instruction-preview" data-field="userComment"
            data-comment-preview tabindex="0">${instructionRunsHtml(commentRuns)}</div>
          <div class="instruction-format-toolbar" data-comment-format-toolbar hidden
            role="toolbar" aria-label="${uiT("a11y.commentFormatting")}">
            <button type="button" class="secondary" data-comment-format="bold"
              aria-label="${uiT("a11y.bold")}" aria-pressed="false"><strong>F</strong></button>
            <button type="button" class="secondary" data-comment-format="italic"
              aria-label="${uiT("a11y.italic")}" aria-pressed="false"><em>K</em></button>
            <label>Typsnitt<select data-comment-font>
              ${globalThis.T9TextFormat.FONT_FAMILIES.map(font =>
                `<option value="${escapeHtml(font)}">${escapeHtml(font)}</option>`).join("")}
            </select></label>
            <label>Storlek<select data-comment-size>
              ${globalThis.T9TextFormat.FONT_SIZES.map(size =>
                `<option value="${size}">${size} pt</option>`).join("")}
            </select></label>
            <label>Textfärg<select data-comment-text-color data-color-select>
              ${globalThis.T9TextFormat.COLORS.map(color =>
                `<option value="${color.value}">${escapeHtml(color.name)}</option>`).join("")}
            </select></label>
            <label>Bakgrund<select data-comment-background-color data-color-select>
              ${globalThis.T9TextFormat.COLORS.map(color =>
                `<option value="${color.value}">${escapeHtml(color.name)}</option>`).join("")}
            </select></label>
          </div>
          <textarea id="review-comment-${visibleIndex}" data-field="userComment" data-edit-field="userComment" hidden
            data-original-value="${escapeHtml(generatedComment)}"
            aria-label="${uiTf("a11y.comment", { step: visibleIndex + 1 })}"
            aria-keyshortcuts="Control+Enter Meta+Enter Escape"
            title="${uiT("a11y.saveEditor")}" readonly>${escapeHtml(task.userComment || "")}</textarea>
        </div>
        <button data-action="add-comment" class="secondary review-add-comment"
          ${task.userComment ? "hidden" : ""}
          aria-label="${uiTf("a11y.addComment", { step: visibleIndex + 1 })}">Lägg till kommentar</button>
        ${task.manualStepId ? `<div class="review-field-heading">
          <label for="review-manual-type-${visibleIndex}">Informationstyp</label>
          <select id="review-manual-type-${visibleIndex}" data-action="manual-type"
            aria-label="Informationstyp för manuellt steg ${visibleIndex + 1}">
            ${globalThis.T9ManualInformationSteps.STEP_TYPES.map(type =>
              `<option value="${type}" ${task.stepType === type ? "selected" : ""}>${type}</option>`
            ).join("")}
          </select>
        </div>
        <div class="review-field-heading">
          <label for="review-callout-${visibleIndex}">Faktaruta</label>
          <button data-action="edit-callout" class="secondary"
            aria-label="Redigera faktaruta för steg ${visibleIndex + 1}">Redigera</button>
        </div>
        <input id="review-callout-${visibleIndex}" data-edit-field="manualCallout"
          aria-label="Faktaruta för manuellt steg ${visibleIndex + 1}"
          value="${escapeHtml(task.callout?.text || "")}" readonly>` : ""}
        <details class="review-technical-details">
          <summary>${uiT("Teknisk information")}</summary>
          <div class="review-meta">
            ${escapeHtml(task.taskType || "Task")}
            · Confidence ${task.confidenceScore ?? task.confidence ?? 0}%
            ${task.stepOverride ? " · Redigerad" : " · Genererad"}
            ${task.provenance === "manual"
              ? ` · Manuellt ${escapeHtml(task.stepType || "information")}` : ""}
            ${task.stepOverride?.screenshotOverride ? " · Manuell skärmbild" : ""}
            ${task.knowledgeRule
              ? ` · ${escapeHtml(task.knowledgeRule)}`
              : ""}
          </div>
          ${screenshotQuality ? `<details class="review-screenshot-quality"
            data-quality="${escapeHtml(qualityLevel)}">
            <summary>${uiT("review.imageSelection")}</summary>
            <p>${uiT(`review.imageReason.${screenshotQuality.qualityReason}`)}</p>
            ${qualityMetrics ? `<p class="metrics">${escapeHtml(qualityMetrics)}</p>` : ""}
          </details>` : ""}
        </details>
        ${task.resultVerified && task.observedResult
          ? `<p class="review-observed-result ${task.resultVerification?.status === "error"
            ? "error" : "verified"}"><strong>${uiT(task.resultVerification?.status === "error"
              ? "review.observedError" : "review.observedResult")}:</strong> ${escapeHtml(
                globalThis.T9DocumentLanguage.translateInstruction(
                  task.observedResult, applicationSettings.uiLocale
                ))}</p>`
          : ""}

        ${images.map((image, imageIndex) =>
          `<div class="review-screenshot">
            <div class="review-image-stage" data-review-image-index="${imageIndex}">
              <img class="review-image" src="${image.imageUrl}"
                alt="Skärmbild ${imageIndex + 1} för steg ${visibleIndex + 1}">
              <svg class="review-annotation-layer" aria-hidden="true"></svg>
            </div>
            <button data-action="annotate" class="secondary review-annotate-button"
              aria-label="${uiTf("a11y.editImage", { image: imageIndex + 1, step: visibleIndex + 1 })}">Redigera bild</button>
            ${images.length > 1 ? `<button data-action="select-screenshot"
              data-screenshot-index="${imageIndex}" class="secondary"
              aria-label="${uiTf("a11y.useScreenshot", { image: imageIndex + 1, step: visibleIndex + 1 })}"
              ${task.selectedScreenshotAssetId === image.path ? "disabled" : ""}>Använd</button>` : ""}
          </div>`
        ).join("")}
      </div>
      <div class="review-actions" role="gridcell">
        <label class="review-approve-action">
          <input data-action="approve" type="checkbox"
            aria-label="${uiTf("a11y.approveStep", { step: visibleIndex + 1 })}"
            ${task.approved ? "checked" : ""}>
          Godkänd
        </label>
        <div class="review-step-actions-menu">
          <button type="button" class="review-step-actions-trigger"
            aria-label="${uiT("Fler åtgärder")}" aria-expanded="false">⋯</button>
          <div class="review-step-actions-panel" role="group"
            aria-label="${uiTf("a11y.stepActions", { step: visibleIndex + 1 })}" hidden>
            <button data-drag-handle class="secondary" draggable="true"
              aria-label="${uiTf("a11y.dragStep", { step: visibleIndex + 1 })}"
              aria-keyshortcuts="Alt+ArrowUp Alt+ArrowDown">Flytta</button>
            <button data-action="add" class="secondary"
              aria-label="${uiTf("a11y.addAfter", { step: visibleIndex + 1 })}">Lägg till efter</button>
            <button data-action="repair-step" class="secondary"
              aria-label="${uiTf("a11y.changeImage", { step: visibleIndex + 1 })}">Byt bild</button>
            <button data-action="reset-instruction" class="secondary"
              ${task.fieldProvenance?.instruction === "user-edited" ? "" : "disabled"}
              aria-label="${uiTf("a11y.resetInstruction", { step: visibleIndex + 1 })}">Återställ text</button>
            <button data-action="remove" class="secondary review-hide-action"
              aria-label="${uiTf("a11y.hideStep", { step: visibleIndex + 1 })}">Dölj</button>
            ${task.manualStepId ? `<button data-action="delete-manual" class="danger"
              aria-label="Ta bort manuellt steg ${visibleIndex + 1}">Ta bort manuellt steg</button>` : ""}
            <button data-action="toggle-layout" class="secondary"
              aria-pressed="false">Komprimera</button>
          </div>
        </div>
      </div>`;

    // Make the step visible before optional enhancements and event bindings.
    // A compatibility problem in one enhancement must never blank the Review.
    list.appendChild(card);

    const stepActionsMenu = card.querySelector(".review-step-actions-menu");
    const stepActionsSummary = stepActionsMenu.querySelector(
      ".review-step-actions-trigger"
    );
    const stepActionsPanel = stepActionsMenu.querySelector(
      ".review-step-actions-panel"
    );
    const setStepActionsOpen = open => {
      stepActionsMenu.classList.toggle("is-open", open);
      stepActionsSummary.setAttribute("aria-expanded", String(open));
      stepActionsPanel.hidden = !open;
    };
    stepActionsSummary.addEventListener("click", () => {
      const shouldOpen = stepActionsSummary.getAttribute("aria-expanded") !== "true";
      for (const menu of list.querySelectorAll(
        ".review-step-actions-menu.is-open"
      )) {
        if (menu !== stepActionsMenu) {
          menu.classList.remove("is-open");
          menu.querySelector(".review-step-actions-trigger")
            .setAttribute("aria-expanded", "false");
          menu.querySelector(".review-step-actions-panel").hidden = true;
        }
      }
      setStepActionsOpen(shouldOpen);
    });
    stepActionsMenu.addEventListener("click", event => {
      const button = event.target.closest("button");
      if (button && stepActionsPanel.contains(button) && !button.disabled) {
        setTimeout(() => setStepActionsOpen(false));
      }
    });
    stepActionsMenu.addEventListener("keydown", event => {
      if (event.key !== "Escape") return;
      event.preventDefault();
      setStepActionsOpen(false);
      stepActionsSummary.focus();
    });
    stepActionsMenu.addEventListener("focusout", event => {
      if (!stepActionsMenu.contains(event.relatedTarget)) {
        setStepActionsOpen(false);
      }
    });

    initializeReviewScreenshots(card, task, images);

    card.querySelector('[data-action="approve"]')
      .addEventListener("change", event => {
        globalThis.T9Review.approveTask(
          activeReview,
          actualIndex,
          event.target.checked,
          {
            beforeSelection: activeReviewSelection,
            afterSelection: activeReviewSelection
          }
        );
        renderReview();
      });

    card.querySelector('[data-action="edit-instruction"]')
      .addEventListener("click", () => {
        editReviewField(card, task.taskId, "instruction");
      });
    const instructionControl = card.querySelector(
      '[data-edit-field="instruction"]'
    );
    const instructionEditor = card.querySelector("[data-instruction-preview]");
    card.querySelector("[data-instruction-format-toolbar]")
      .addEventListener("pointerdown", () => {
        if (instructionEditor.dataset.editing === "true") {
          rememberInstructionSelection(instructionEditor);
        }
      });
    for (const eventName of ["mouseup", "keyup"]) {
      instructionEditor.addEventListener(eventName, () => {
        rememberInstructionSelection(instructionEditor);
        if (instructionEditor.dataset.editing === "true") {
          updateInstructionToolbar(card, instructionEditor);
        }
      });
    }
    instructionEditor.addEventListener("input", () => {
      if (instructionEditor.dataset.editing !== "true" || !activeReviewEdit) return;
      const value = instructionEditor.textContent || "";
      instructionControl.value = value;
      activeReviewEdit = globalThis.T9ReviewEdit.update(activeReviewEdit, value);
      activeReviewEdit.instructionRuns = globalThis.T9TextFormat
        .normalizeInstructionRuns(instructionRunsFromEditor(instructionEditor), value);
      rememberInstructionSelection(instructionEditor);
      updateInstructionToolbar(card, instructionEditor);
    });
    instructionEditor.addEventListener("keydown", event => {
      if (instructionEditor.dataset.editing !== "true") return;
      if (event.key === "Escape" ||
          (event.key === "Enter" && (event.ctrlKey || event.metaKey))) {
        event.preventDefault();
        finishReviewEdit(instructionControl, event.key !== "Escape");
      }
    });
    instructionEditor.addEventListener("focusout", event => {
      if (instructionEditor.dataset.editing !== "true") return;
      if (event.relatedTarget?.closest?.("[data-instruction-format-toolbar]")) {
        return;
      }
      finishReviewEdit(instructionControl, true);
    });
    for (const button of card.querySelectorAll("[data-instruction-format]")) {
      button.addEventListener("mousedown", event => event.preventDefault());
      button.addEventListener("click", () => {
        const property = button.dataset.instructionFormat;
        const allRuns = activeReviewEdit?.instructionRuns || [];
        let from = activeReviewEdit?.selectionStart ?? 0;
        let to = activeReviewEdit?.selectionEnd ?? instructionControl.value.length;
        if (from === to) { from = 0; to = instructionControl.value.length; }
        let offset = 0;
        const selectedRuns = allRuns.filter(run => {
          const overlaps = offset < to && offset + run.text.length > from;
          offset += run.text.length;
          return overlaps;
        });
        const enabled = !selectedRuns.every(run => run[property] === true);
        button.setAttribute("aria-pressed", String(enabled));
        applyInstructionFormatting(instructionControl, instructionEditor,
          { [property]: enabled });
      });
    }
    card.querySelector("[data-instruction-font]")
      .addEventListener("change", event => {
        if (event.target.value) applyInstructionFormatting(instructionControl,
          instructionEditor,
          { fontFamily: event.target.value });
      });
    card.querySelector("[data-instruction-size]")
      .addEventListener("change", event => {
        if (event.target.value) applyInstructionFormatting(instructionControl,
          instructionEditor,
          { fontSize: Number(event.target.value) });
      });
    card.querySelector("[data-instruction-text-color]")
      .addEventListener("change", event => {
        if (event.target.value) applyInstructionFormatting(instructionControl,
          instructionEditor, { textColor: event.target.value });
      });
    card.querySelector("[data-instruction-background-color]")
      .addEventListener("change", event => {
        if (event.target.value) applyInstructionFormatting(instructionControl,
          instructionEditor, { backgroundColor: event.target.value });
      });
    card.querySelector('[data-action="edit-comment"]')
      .addEventListener("click", () => {
        editReviewField(card, task.taskId, "userComment");
      });
    const commentControl = card.querySelector('[data-edit-field="userComment"]');
    const commentEditor = card.querySelector("[data-comment-preview]");
    const commentToolbar = card.querySelector("[data-comment-format-toolbar]");
    commentToolbar.addEventListener("pointerdown", () => {
      if (commentEditor.dataset.editing === "true") {
        rememberInstructionSelection(commentEditor);
      }
    });
    for (const eventName of ["mouseup", "keyup"]) {
      commentEditor.addEventListener(eventName, () => {
        rememberInstructionSelection(commentEditor);
        if (commentEditor.dataset.editing === "true") {
          updateInstructionToolbar(card, commentEditor);
        }
      });
    }
    commentEditor.addEventListener("input", () => {
      if (commentEditor.dataset.editing !== "true" || !activeReviewEdit) return;
      const value = commentEditor.textContent || "";
      commentControl.value = value;
      activeReviewEdit = globalThis.T9ReviewEdit.update(activeReviewEdit, value);
      activeReviewEdit.instructionRuns = globalThis.T9TextFormat
        .normalizeInstructionRuns(instructionRunsFromEditor(commentEditor), value);
      rememberInstructionSelection(commentEditor);
      updateInstructionToolbar(card, commentEditor);
      updateCommentResetState(commentControl);
    });
    commentEditor.addEventListener("keydown", event => {
      if (commentEditor.dataset.editing !== "true") return;
      if (event.key === "Escape" ||
          (event.key === "Enter" && (event.ctrlKey || event.metaKey))) {
        event.preventDefault();
        finishReviewEdit(commentControl, event.key !== "Escape");
      }
    });
    commentEditor.addEventListener("focusout", event => {
      if (commentEditor.dataset.editing !== "true") return;
      if (event.relatedTarget?.closest?.("[data-comment-format-toolbar]")) return;
      finishReviewEdit(commentControl, true);
    });
    for (const button of card.querySelectorAll("[data-comment-format]")) {
      button.addEventListener("mousedown", event => event.preventDefault());
      button.addEventListener("click", () => {
        const property = button.dataset.commentFormat;
        const selectedRuns = selectedInstructionRuns(commentEditor);
        const enabled = !selectedRuns.every(run => run[property] === true);
        applyInstructionFormatting(commentControl, commentEditor,
          { [property]: enabled });
      });
    }
    for (const [selector, property, convert] of [
      ["[data-comment-font]", "fontFamily", value => value],
      ["[data-comment-size]", "fontSize", value => Number(value)],
      ["[data-comment-text-color]", "textColor", value => value],
      ["[data-comment-background-color]", "backgroundColor", value => value]
    ]) {
      card.querySelector(selector).addEventListener("change", event => {
        if (event.target.value) applyInstructionFormatting(commentControl,
          commentEditor, { [property]: convert(event.target.value) });
      });
    }

    const resetComment = card.querySelector('[data-action="reset-comment"]');
    resetComment.addEventListener("pointerdown", event => event.preventDefault());
    resetComment.addEventListener("click", () => {
      const control = card.querySelector('[data-edit-field="userComment"]');
      if (activeReviewEdit?.field === "userComment" &&
          activeReviewEdit.taskId === task.taskId) {
        finishReviewEdit(control, false);
      }
      globalThis.T9Review.resetTaskField(activeReview, actualIndex, "comment", {
        beforeSelection: activeReviewSelection,
        afterSelection: activeReviewSelection
      });
      reviewAutoSave.schedule();
      invalidateDocumentWorkspace();
      renderReview();
    });

    card.querySelector('[data-action="add-comment"]')
      .addEventListener("click", event => {
        card.querySelector(".review-comment-section").hidden = false;
        event.currentTarget.hidden = true;
        editReviewField(card, task.taskId, "userComment");
      });

    card.querySelector('[data-action="edit-callout"]')
      ?.addEventListener("click", () => {
        editReviewField(card, task.taskId, "manualCallout");
      });

    card.querySelector('[data-action="manual-type"]')
      ?.addEventListener("change", event => {
        globalThis.T9Review.editTask(activeReview, actualIndex, {
          stepType: event.target.value,
          ...(task.callout?.text ? { manualCallout: task.callout.text } : {})
        }, {
          beforeSelection: activeReviewSelection,
          afterSelection: activeReviewSelection
        });
        reviewAutoSave.schedule();
        renderReview();
      });

    card.querySelector("[data-include-knowledge-explanation-in-word]")
      ?.addEventListener("change", event => {
        globalThis.T9Review.editTask(activeReview, actualIndex, {
          includeKnowledgeExplanationInWord: event.target.checked === true
        }, { beforeSelection: activeReviewSelection,
          afterSelection: activeReviewSelection });
        reviewAutoSave.schedule();
        invalidateDocumentWorkspace();
      });

    card.querySelector('[data-action="add"]')
      .addEventListener("click", () => {
        addManualInformationStep(actualIndex);
      });

    card.querySelector('[data-action="repair-step"]')
      .addEventListener("click", () => openStepRepair(actualIndex));

    card.querySelector('[data-action="reset-instruction"]')
      .addEventListener("click", () => {
        globalThis.T9Review.resetTaskField(activeReview, actualIndex, "instruction", {
          beforeSelection: activeReviewSelection,
          afterSelection: activeReviewSelection
        });
        reviewAutoSave.schedule();
        renderReview();
      });

    for (const button of card.querySelectorAll('[data-action="select-screenshot"]')) {
      button.addEventListener("click", () => {
        const image = images[Number(button.dataset.screenshotIndex)];
        const result = globalThis.T9Review.selectTaskScreenshot(
          activeReview, actualIndex, image.path, {
            beforeSelection: activeReviewSelection,
            afterSelection: activeReviewSelection
          }
        );
        if (!result.ok) {
          show("Skärmbilden har annoteringar. Ta bort eller byt annoteringarna först.", true);
          return;
        }
        reviewAutoSave.schedule();
        renderReview();
      });
    }

    card.querySelector('[data-action="remove"]')
      .addEventListener("click", () => {
        deleteReviewTasks([task.taskId]);
        reviewAutoSave.schedule();
      });

    card.querySelector('[data-action="delete-manual"]')
      ?.addEventListener("click", () => {
        globalThis.T9Review.deleteManualStep(
          activeReview, task.manualStepId, {
            beforeSelection: activeReviewSelection
          }
        );
        reviewAutoSave.schedule();
        renderReview();
        show("Det manuella informationssteget togs bort.");
      });

    card.querySelector('[data-action="toggle-layout"]')
      .addEventListener("click", () => {
        reviewLayoutState = globalThis.T9ReviewLayout.toggleTask(
          reviewLayoutState,
          task.taskId
        );
        globalThis.T9ReviewLayout.apply(
          list,
          $("compactReviewSteps"),
          reviewLayoutState
        );
      });

  });
  globalThis.T9ReviewLayout.apply(
    list,
    $("compactReviewSteps"),
    reviewLayoutState
  );
  applyReviewSelection();
}

function renderReview() {
  try {
    renderReviewContent();
    if (!$('reviewList').children.length && activeReview?.tasks?.length) {
      renderStoredReviewFallback(new Error(
        "Den filtrerade steglistan blev tom trots lagrade steg."
      ));
    }
  } catch (error) {
    renderStoredReviewFallback(error);
  }
  renderProcessOverview();
}

function renderProcessOverview() {
  if (!processIntelligenceEnabled()) return;
  const container = $("processOverview");
  if (!container || !activeReview || !activeReviewSession) {
    activeProcessModel = null;
    if ($("saveProcessVersion")) $("saveProcessVersion").disabled = true;
    if ($("compareProcessVersions")) $("compareProcessVersions").disabled = true;
    if ($("exportProcessModel")) $("exportProcessModel").disabled = true;
    if ($("exportProcessDiagram")) $("exportProcessDiagram").disabled = true;
    if ($("editProcessMapRelationship")) $("editProcessMapRelationship").disabled = true;
    return;
  }
  try {
    const resolvedHierarchy = resolveReviewHierarchyForDisplay(
      activeReview.tasks || [], activeReview.hierarchy
    );
    const processMapReviewTasks = globalThis.T9ProcessTaskContext.enrichForDisplay(
      activeReview.tasks || [], activeReviewModel.businessTasks || []
    );
    const procedureModel = globalThis.T9ProcessModel.project({
      recordingId: activeReviewSession.id,
      title: activeReviewSession.name,
        steps: processMapReviewTasks,
      resolvedHierarchy,
      overrides: activeReview.processOverrides || []
    });
    const hasSemanticAnalysis = Boolean(activeProcessAnalysis?.bestMatch);
    const displayedLevel = hasSemanticAnalysis ? activeProcessMapLevel : "procedure";
    $("editProcessMapNode").disabled = displayedLevel === "procedure" || !selectedProcessMapNodeId;
    $("editProcessMapRelationship").disabled = displayedLevel === "procedure" || !selectedProcessMapNodeId;
    const english = String(applicationSettings.uiLocale || "").startsWith("en");
    processMapZoom = globalThis.T9ProcessMapViewport.normalize(processMapZoom);
    $("processMapZoomValue").textContent = `${processMapZoom}%`;
    $("processMapZoomOut").disabled = processMapZoom <=
      globalThis.T9ProcessMapViewport.MIN_ZOOM;
    $("processMapZoomIn").disabled = processMapZoom >=
      globalThis.T9ProcessMapViewport.MAX_ZOOM;
    $("processMapFit").textContent = english ? "Fit" : "Anpassa";
    processMapDirection = normalizedProcessMapDirection(processMapDirection);
    $("processMapDirection").value = processMapDirection;
    $("processMapDirection").options[0].textContent = english ? "Automatic" : "Automatisk";
    $("processMapDirection").options[1].textContent = english ? "Vertical" : "Lodrät";
    $("processMapDirection").title = english ? "Choose process map direction" :
      "Välj processkartans riktning";
    document.querySelector('label[for="processMapDirection"]').textContent = english
      ? "Layout" : "Layout";
    processMapTheme = globalThis.T9ProcessMapTheme.normalize(processMapTheme);
    const themeSelect = $("processMapTheme");
    themeSelect.innerHTML = globalThis.T9ProcessMapTheme.list(
      applicationSettings.uiLocale || "sv-SE"
    ).map(theme => `<option value="${theme.id}">${theme.label}</option>`).join("");
    themeSelect.value = processMapTheme;
    themeSelect.title = english ? "Choose the process map visual theme" :
      "Välj processkartans visuella tema";
    document.querySelector('label[for="processMapTheme"]').textContent = english ? "Theme" : "Tema";
    processMapDensity = normalizedProcessMapDensity(processMapDensity);
    $("processMapDensity").value = processMapDensity;
    $("processMapDensity").options[0].textContent = "Standard";
    $("processMapDensity").options[1].textContent = english ? "Compact" : "Kompakt";
    $("processMapDensity").title = english ? "Choose process map density" :
      "Välj processkartans täthet";
    $("processMapIncludeReferences").checked = processMapIncludeReferences;
    $("processMapIncludeReferences").parentElement.lastChild.textContent = english
      ? " Show reference suggestions" : " Visa referensförslag";
    $("processMapIncludeReferences").parentElement.hidden = displayedLevel === "procedure";
    document.querySelector('label[for="processMapDensity"]').textContent = english
      ? "Density" : "Täthet";
    const focusActive = $("processOverviewDisclosure").classList.contains("process-map-focus");
    $("processMapFocus").textContent = focusActive
      ? (english ? "Close focus" : "Stäng fokus")
      : (english ? "Focus mode" : "Fokusläge");
    $("processMapFocus").title = focusActive
      ? (english ? "Close process map focus mode (Esc)" : "Stäng processkartans fokusläge (Esc)")
      : (english ? "Show the process map in focus mode" : "Visa processkartan i fokusläge");
    $("processMapFocus").setAttribute("aria-pressed", String(focusActive));
    document.querySelector('label[for="processMapSearch"]').textContent = english
      ? "Search map" : "Sök i kartan";
    $("processMapSearch").placeholder = english
      ? "Step, document or action" : "Steg, dokument eller åtgärd";
    $("processMapSearchNext").textContent = english ? "Next match" : "Nästa träff";
    $("processMapFit").title = english ? "Fit the complete process map to the available width" :
      "Anpassa hela processkartan till tillgänglig bredd";
    $("processMapZoomOut").title = english ? "Zoom out the process map" :
      "Zooma ut processkartan";
    $("processMapZoomIn").title = english ? "Zoom in the process map" :
      "Zooma in processkartan";
    $("processMapResetZoom").title = english ? "Reset the process map to 100%" :
      "Återställ processkartan till 100 %";
    $("processMapViewportControls").setAttribute("aria-label", english
      ? "Process map size" : "Processkartans storlek");
    const descriptions = english ? {
      business: "High-level business flow derived from the confirmed process classification.",
      businessCentral: "Business Central documents and actions compared with the reference process.",
      procedure: "The actual recorded user procedure. Select an activity to open its Review step."
    } : {
      business: "Övergripande affärsflöde från den bekräftade processklassificeringen.",
      businessCentral: "Business Central-dokument och åtgärder jämförda med referensprocessen.",
      procedure: "Den faktiska inspelade användarproceduren. Välj en aktivitet för att öppna granskningssteget."
    };
    $("processMapDescription").textContent = descriptions[displayedLevel];
    $("processMapLegend").hidden = displayedLevel === "procedure";
    for (const item of $("processMapLegend").querySelectorAll(
      ".suggested,.conditional"
    )) item.hidden = !processMapIncludeReferences;
    const model = displayedLevel === "procedure"
      ? procedureModel : globalThis.T9SemanticProcessMap.project({
        recordingId: activeReviewSession.id,
        title: activeReviewSession.name,
        analysis: activeProcessAnalysis,
        decision: activeReview.processAnalysis,
        reviewTasks: processMapReviewTasks,
        procedureModel
      }, activeProcessMapLevel, { includeReferences: processMapIncludeReferences,
        includeBoundaries: true, locale: english ? "en-US" : "sv-SE" });
    activeProcessBaseModel = model;
    activeProcessModel = displayedLevel === "procedure" ? model :
      globalThis.T9ProcessMapRelationshipOverrides.apply(
        globalThis.T9ProcessMapOverrides.apply(model, activeReview.processMapOverrides || []),
        activeReview.processMapRelationshipOverrides || []);
    for (const button of $("processMapLevels").querySelectorAll(
      "[data-process-map-level]"
    )) {
      button.disabled = false;
      button.setAttribute("aria-pressed", String(
        button.dataset.processMapLevel === displayedLevel
      ));
    }
    $("saveProcessVersion").disabled = false;
    $("compareProcessVersions").disabled =
      !(activeReview.processVersions || []).length;
    $("exportProcessModel").disabled = false;
    $("exportProcessDiagram").disabled = false;
    const processMapRender = globalThis.T9ProcessOverviewView.render(container, activeProcessModel, {
      locale: applicationSettings.uiLocale || "sv-SE",
      selectedTaskIds: activeReviewSelection.selectedIds,
      reviewTasks: processMapReviewTasks,
      zoom: processMapZoom,
      direction: processMapDirection,
      theme: processMapTheme,
      density: processMapDensity,
      reorderable: displayedLevel !== "procedure"
    });
    const layoutNames = english ? { horizontal: "Horizontal", serpentine: "Multi-row",
      branched: "Branched", vertical: "Vertical" } : { horizontal: "Vågrät",
      serpentine: "Flera rader", branched: "Förgrenad", vertical: "Lodrät" };
    $("processMapLayoutStatus").textContent = layoutNames[processMapRender.layoutStrategy] || "";
    applyProcessMapSearch(false);
  } catch (error) {
    activeProcessModel = null;
    activeProcessBaseModel = null;
    $("saveProcessVersion").disabled = true;
    $("compareProcessVersions").disabled = true;
    $("exportProcessModel").disabled = true;
    $("exportProcessDiagram").disabled = true;
    container.innerHTML = `<p class="muted">${escapeHtml(uiTf(
      "process.overviewError", { detail: error.message }
    ))}</p>`;
  }
}

async function exportActiveProcess(kind) {
  if (!activeProcessModel || !activeReviewSession) return;
  try {
    const exported = globalThis.T9ProcessExport.create(activeProcessModel, {
      title: activeReviewSession.name,
      language: activeReview.documentFields?.documentLanguage || "sv-SE",
      ...(processMapDirection === "vertical" ? { columns: 1 } : {}),
      theme: processMapTheme,
      density: processMapDensity
    });
    const file = kind === "diagram" ? exported.diagram : exported.json;
    await downloadBlob(new Blob([file.content], { type: file.mimeType }),
      file.filename);
    show(kind === "diagram"
      ? uiT("Processdiagrammet har exporterats.")
      : uiT("Processen har exporterats."));
  } catch (error) {
    show(uiTf("process.exportError", { detail: error.message }), true);
  }
}

function processVersionOptionLabel(choice) {
  if (!choice.version) return uiT("Aktuellt");
  return `v${choice.version.versionNumber}${choice.version.baseline
    ? ` · ${uiT("Baslinje")}` : ""}`;
}

function renderProcessVersionComparison() {
  const fromId = $("processVersionFrom").value;
  const toId = $("processVersionTo").value;
  const container = $("processVersionComparison");
  if (fromId === toId) {
    container.innerHTML = `<p class="muted">${escapeHtml(uiT(
      "Välj två olika processversioner."
    ))}</p>`;
    return;
  }
  try {
    const comparison = globalThis.T9ProcessVersionWorkflow.compare(
      activeReview.processVersions || [], fromId, toId, activeProcessModel
    );
    globalThis.T9ProcessVersionComparisonView.render(container, comparison, {
      locale: applicationSettings.uiLocale
    });
  } catch (error) {
    container.innerHTML = `<p class="regeneration-preview-warning">${escapeHtml(
      error.message
    )}</p>`;
  }
}

function openProcessVersionComparison() {
  if (!activeReview || !activeProcessModel) return;
  const choices = globalThis.T9ProcessVersionWorkflow.choices(
    activeReview.processVersions || [], activeProcessModel
  );
  const populate = select => {
    select.replaceChildren(...choices.map(choice => {
      const option = document.createElement("option");
      option.value = choice.id;
      option.textContent = processVersionOptionLabel(choice);
      return option;
    }));
  };
  populate($("processVersionFrom"));
  populate($("processVersionTo"));
  const saved = choices.filter(choice => choice.version);
  $("processVersionFrom").value = saved.length > 1
    ? saved.at(-2).id : saved.at(-1)?.id || choices[0]?.id || "";
  $("processVersionTo").value = saved.length > 1
    ? saved.at(-1).id : globalThis.T9ProcessVersionWorkflow.CURRENT_ID;
  renderProcessVersionComparison();
  $("processVersionDialog").showModal();
}

async function saveCurrentProcessVersion() {
  if (!activeReview || !activeProcessModel || !activeReviewSession) return;
  const previous = [...(activeReview.processVersions || [])];
  try {
    const result = globalThis.T9ProcessVersionWorkflow.save(
      activeProcessModel, previous, {
        title: activeReviewSession.name,
        createdAt: new Date().toISOString(),
        status: activeReview.status === "completed" ? "approved" : "review"
      }
    );
    if (!result.created) {
      show(uiT("Processen är identisk med den senaste sparade versionen."));
      return;
    }
    activeReview.processVersions = [...previous, result.version];
    activeReview.updatedAt = result.version.createdAt;
    await saveActiveReview({ announce: false, render: false });
    try {
      await updateDocumentLibraryRecord(activeReviewSession.id, {
        processVersion: globalThis.T9ProcessVersioning.libraryMetadata(
          activeReview.processVersions
        )
      }, { render: false });
    } catch (metadataError) {
      console.warn("Process version library metadata could not be updated.",
        metadataError);
    }
    $("compareProcessVersions").disabled = false;
    show(uiTf("process.versionSaved", { version: result.version.versionNumber }));
  } catch (error) {
    activeReview.processVersions = previous;
    show(uiTf("process.versionSaveError", { detail: error.message }), true);
  }
}

async function saveActiveReview(options = {}) {
  if (!activeReviewSession || !activeReview) return;
  const savedSession = activeReviewSession;
  const savedReview = activeReview;
  const savedUpdatedAt = activeReview.updatedAt;
  const savedSnapshot = JSON.parse(JSON.stringify(activeReview));
  const queued = await reviewSaveQueue.enqueue({
    sessionId: savedSession.id,
    review: savedSnapshot
  });
  const response = queued.value;

  if (!response.ok) {
    throw new Error(response.error || "Granskningen kunde inte sparas.");
  }

  const currentSession = activeReviewSession === savedSession;
  const unchanged = globalThis.T9ReviewEdit.isCurrentSave({
    latest: queued.latest,
    currentSession,
    currentReview: activeReview,
    savedReview,
    savedUpdatedAt
  });
  if (unchanged) {
    activeReview = response.review;
    annotationChangesPending = false;
  }
  if (options.announce !== false && currentSession) {
    show(`Granskningen för "${savedSession.name}" har sparats.`);
  }
  if (options.render !== false && unchanged) renderReview();
  else if (options.render === false && currentSession) {
    $("reviewFooterText").textContent = unchanged
      ? "Alla ändringar är sparade."
      : "Nyare ändringar väntar på att sparas.";
    if (annotationEditorState && unchanged) {
      $("annotationStatus").textContent = "Annoteringarna är sparade.";
    }
  }
}

async function flushReviewPersistence() {
  await reviewPersistence.flush();
}

function resetReviewSurfaceForOpen() {
  releaseActiveAnnotationPointer();
  annotationEditorState = null;
  annotationEditorBaseline = null;
  $("annotationEditor").hidden = true;
  $("reviewList").hidden = false;
  $("reviewFooter").hidden = false;
  $("documentWorkspaceTab").disabled = false;
  $("reviewDialog").classList.remove("annotation-mode");
  $("reviewDialog").style.removeProperty("--review-header-height");
}

async function openReview(session) {
  reviewReturnFocus = document.activeElement;
  show(`Förbereder granskning av "${session.name}"...`);

  activeReviewSession = session;
  annotationChangesPending = false;
  updateFilenamePreview();
  activeReviewModel = await prepareSessionModel(session, { includeExternalKnowledge: true });

  const existing = await send({
    type: "T9_GET_REVIEW",
    sessionId: session.id
  });

  const replaceEmptyReview = existing.review &&
    (!Array.isArray(existing.review.tasks) || existing.review.tasks.length === 0) &&
    activeReviewModel.businessTasks.length > 0;
  const replacePlaceholderReview = existing.review &&
    !String(existing.review.documentFields?.expectedResult ||
      existing.review.expectedResult || "").trim() &&
    (globalThis.T9Review.isGeneratedPlaceholderOnly(existing.review) ||
      globalThis.T9Review.hasGeneratedLookupSearchLeak(existing.review) ||
      globalThis.T9Review.hasGeneratedMenuPathLeak(existing.review) ||
      globalThis.T9Review.hasGeneratedCloseScreenshotLeak(existing.review) ||
      globalThis.T9Review.hasGeneratedSearchInputLeak(existing.review) ||
      globalThis.T9Review.hasGeneratedSearchResultTypeLeak(existing.review) ||
      globalThis.T9Review.hasGeneratedSearchEvidenceDrift(existing.review,
        activeReviewModel.businessTasks)) &&
    activeReviewModel.businessTasks.length > 0;
  activeReview = existing.review && !replaceEmptyReview && !replacePlaceholderReview
    ? globalThis.T9Review.normalizeReview({
        ...existing.review,
        tasks: globalThis.T9Review.normalizeTasks(existing.review.tasks)
      })
    : globalThis.T9Review.replaceGeneratedReview(
      session,
      activeReviewModel.businessTasks,
      existing.review
    );
  activeReviewSelection = globalThis.T9ReviewSelection.create();
  activeReviewEdit = null;
  activeProcessMapLevel = "businessCentral";
  processMapIncludeReferences = false;
  workspaceContext = globalThis.T9WorkspaceContext.create();
  workspaceContextBinding = null;
  documentationIntelligenceModel = null;
  const assignedProfileId = documentLibraryRecords.find(record =>
    record.projectId === session.id
  )?.profile.profileId;
  activeDocumentProfileId = documentProfiles().some(profile =>
    profile.profileId === assignedProfileId
  ) ? assignedProfileId : "business-process";
  documentProfileVariants = new Map();
  documentWorkspaceMediaSources = {};
  documentProfileSource = null;
  workspaceState = globalThis.T9WorkspaceController.create();
  documentWorkspaceSync = null;
  documentViewState = globalThis.T9DocumentWorkspaceExperience.update(
    documentViewState,
    { currentPage: 1 }
  );
  reviewLayoutState = globalThis.T9ReviewLayout.create(
    reviewLayoutState.allCompact
  );
  reviewAutoSave.cancel();
  resetReviewSurfaceForOpen();

  $("reviewTitle").textContent = `Dokumentation: ${session.name}`;
  $("reviewOverlay").classList.add("open");
  $("reviewOverlay").setAttribute("aria-hidden", "false");
  $("documentWorkspaceTab").disabled = false;
  applyWorkspaceState();
  renderReview();
  applyReviewZoom({ persist: false, preservePosition: false });
  $("closeReview").focus();
  updateFilenamePreview();
  show("");
}

async function closeReview() {
  const returnProjectId = reviewReturnFocus?.closest?.(
    "[data-library-project-id]"
  )?.dataset.libraryProjectId;
  releaseActiveAnnotationPointer();
  if (annotationEditorState) {
    annotationEditorState = globalThis.T9ReviewAnnotationEditor.cancel(
      annotationEditorState
    );
  }
  try {
    await flushReviewPersistence();
  } catch (error) {
    show(error.message, true);
    $("reviewFooterText").textContent =
      "Granskningen kunde inte stängas eftersom sparningen misslyckades.";
    return;
  }
  annotationEditorState = null;
  annotationEditorBaseline = null;
  annotationChangesPending = false;
  reviewAutoSave.cancel();
  $("annotationEditor").hidden = true;
  $("reviewList").hidden = false;
  $("reviewFooter").hidden = false;
  $("reviewDialog").classList.remove("annotation-mode");
  $("reviewDialog").style.removeProperty("--review-header-height");
  $("reviewOverlay").classList.remove("open");
  $("reviewOverlay").setAttribute("aria-hidden", "true");
  activeReviewSession = null;
  activeReview = null;
  activeReviewModel = null;
  activeProcessModel = null;
  activeProcessAnalysis = null;
  processAnalysisRequest = null;
  activeProcessMapLevel = "businessCentral";
  processMapIncludeReferences = false;
  activeReviewSelection = globalThis.T9ReviewSelection.create();
  activeReviewEdit = null;
  activeDocumentPipelineCache.clear();
  activeDocumentPresentationCache.clear();
  activeScreenshotQualityCache.clear();
  workspaceState = globalThis.T9WorkspaceController.create();
  documentWorkspaceSync = null;
  cancelAnimationFrame(documentViewFrame);
  documentViewFrame = 0;
  cancelAnimationFrame(documentScrollFrame);
  documentScrollFrame = 0;
  clearTimeout(workspaceHighlightTimer);
  workspaceHighlightTimer = 0;
  workspaceContext = globalThis.T9WorkspaceContext.create();
  workspaceContextBinding = null;
  documentationIntelligenceModel = null;
  documentProfileVariants = new Map();
  documentWorkspaceMediaSources = {};
  documentProfileSource = null;
  globalThis.T9DocumentWorkspaceView.clear($("documentWorkspace"));
  $("documentWorkspaceStatus").textContent = "";
  applyWorkspaceState();
  updateFilenamePreview();
  refreshLibraryFilters();
  renderDocumentLibrary();
  const libraryReturnTarget = returnProjectId
    ? $("libraryResults").querySelector(
      `[data-library-project-id="${CSS.escape(returnProjectId)}"]`
    )
    : null;
  if (libraryReturnTarget) libraryReturnTarget.focus();
  else if (reviewReturnFocus?.isConnected) reviewReturnFocus.focus();
  reviewReturnFocus = null;
}

async function loadSessions() {
  const response = await send({ type: "T9_GET_DOCUMENT_LIBRARY_BOOTSTRAP" });
  const sessions = Array.isArray(response?.sessions)
    ? response.sessions
    : [];
  const body = $("sessions");
  body.innerHTML = "";
  await loadDocumentLibrary(sessions, response || {});
  if (!$("sessionTools").open) return;

  if (!sessions.length) {
    const row = document.createElement("tr");
    const cell = document.createElement("td");
    cell.colSpan = 5;
    cell.className = "muted";
    cell.textContent = "Inga sessioner har sparats ännu.";
    row.appendChild(cell);
    body.appendChild(row);
    return;
  }
  for (const session of sessions) {
    const row = document.createElement("tr");

    row.innerHTML = `
      <td>${escapeHtml(session.name)}</td>
      <td>${new Date(session.startedAt).toLocaleString("sv-SE")}</td>
      <td>${session.eventCount || 0}</td>
      <td>${session.status === "recording" ? "Pågår" : "Avslutad"}</td>
      <td></td>`;

    const actions = row.lastElementChild;

    const reviewButton = document.createElement("button");
    reviewButton.textContent = "Granska";
    reviewButton.className = "primary";
    reviewButton.disabled = session.status === "recording";
    reviewButton.addEventListener("click", async () => {
      reviewButton.disabled = true;
      try {
        await openReview(session);
      } catch (error) {
        show(error.message, true);
      } finally {
        reviewButton.disabled = false;
      }
    });

    const exportButton = document.createElement("button");
    exportButton.textContent = "Exportera ZIP";
    exportButton.className = "secondary";
    exportButton.addEventListener("click", async () => {
      exportButton.disabled = true;

      try {
        await exportSession(session);
      } catch (error) {
        show(error.message, true);
      } finally {
        exportButton.disabled = false;
      }
    });

    const deleteButton = document.createElement("button");
    deleteButton.textContent = "Ta bort";
    deleteButton.className = "danger";
    deleteButton.addEventListener("click", async () => {
      if (!confirm(`Ta bort sessionen "${session.name}"?`)) return;
      deleteButton.disabled = true;
      try {
        const response = await send({
          type: "T9_DELETE_SESSION",
          sessionId: session.id
        });
        if (!response?.ok) {
          throw new Error(response?.error || "Sessionen kunde inte tas bort.");
        }
        await loadSessions();
        show(`Sessionen "${session.name}" har tagits bort.`);
      } catch (error) {
        show(error.message, true);
        deleteButton.disabled = false;
      }
    });

    actions.append(reviewButton, exportButton, deleteButton);
    body.appendChild(row);
  }
}

async function openRequestedReview() {
  const url = new URL(globalThis.location.href);
  const projectId = url.searchParams.get("openReview");
  if (!projectId) return false;
  url.searchParams.delete("openReview");
  globalThis.history.replaceState({}, "", url.pathname + url.search + url.hash);
  const session = documentLibrarySessions.get(projectId);
  if (!session || session.status === "recording") {
    show(uiT("Den begärda dokumentationen kunde inte öppnas."), true);
    return false;
  }
  await openReview(session);
  return true;
}

$("documentationProfile").addEventListener("change", event => {
  applyProfile(event.target.value, true);
});

$("advancedToggle").addEventListener("click", () => {
  const panel = $("advancedPanel");
  panel.classList.toggle("open");
  const expanded = panel.classList.contains("open");
  $("advancedToggle").setAttribute("aria-expanded", String(expanded));
  $("advancedToggle").textContent = expanded
    ? "Dölj avancerade dataskyddsinställningar"
    : "Visa avancerade dataskyddsinställningar";
});

$("reviewWorkspaceTab").addEventListener("click", () => {
  switchWorkspace("review");
});
$("documentWorkspaceTab").addEventListener("click", () => {
  switchWorkspace("document");
});
$("processOverview").addEventListener("click", event => {
  const minimapNode = event.target.closest?.("[data-process-minimap-node]");
  if (minimapNode) {
    const nodeId = minimapNode.dataset.processMinimapNode;
    globalThis.T9ProcessOverviewView.selectNode($("processOverview"), nodeId);
    const target = [...$("processOverview").querySelectorAll("[data-process-node-action]")]
      .find(action => action.dataset.processNodeAction === nodeId);
    target?.scrollIntoView?.({ block: "nearest", inline: "center" });
    target?.focus?.();
    return;
  }
  const action = event.target.closest?.("[data-process-node-action]");
  if (!action) return;
  selectedProcessMapNodeId = action.dataset.processNodeAction;
  $("editProcessMapNode").disabled = activeProcessMapLevel === "procedure";
  $("editProcessMapRelationship").disabled = activeProcessMapLevel === "procedure";
  if (action.dataset.processTaskId) {
    activateProcessOverviewTask(action.dataset.processTaskId);
  } else {
    globalThis.T9ProcessOverviewView.selectNode(
      $("processOverview"), action.dataset.processNodeAction
    );
  }
});
$('editProcessMapNode').addEventListener("click", () => {
  const node = activeProcessModel?.nodes?.find(item => item.nodeId === selectedProcessMapNodeId);
  if (!node) return;
  $("processMapNodeName").value = node.title || "";
  $("processMapNodeType").value = node.nodeType || "processStep";
  $("processMapNodeRole").value = node.metadata?.processRole?.id || "system";
  processMapDraftOverrides = JSON.parse(JSON.stringify(activeReview.processMapOverrides || []));
  $("processMapNodeDialog").showModal();
});
function moveSelectedProcessNode(direction) {
  if (!activeProcessBaseModel || !selectedProcessMapNodeId) return;
  processMapDraftOverrides = globalThis.T9ProcessMapOverrides.move(
    processMapDraftOverrides, activeProcessBaseModel, selectedProcessMapNodeId, direction);
}
$("moveProcessNodeEarlier").addEventListener("click", () => moveSelectedProcessNode(-1));
$("moveProcessNodeLater").addEventListener("click", () => moveSelectedProcessNode(1));
$("saveProcessMapNode").addEventListener("click", () => {
  if (!activeReview || !selectedProcessMapNodeId) return;
  const roles = { purchasing: "Purchasing", warehouse: "Warehouse", sales: "Sales",
    production: "Production", finance: "Finance", system: "System" };
  const roleId = $("processMapNodeRole").value;
  activeReview.processMapOverrides = globalThis.T9ProcessMapOverrides.upsert(
    processMapDraftOverrides, { nodeId: selectedProcessMapNodeId,
      title: $("processMapNodeName").value, nodeType: $("processMapNodeType").value,
      processRole: { id: roleId, name: roles[roleId] } });
  activeReview.updatedAt = new Date().toISOString();
  reviewAutoSave.schedule();
  $("processMapNodeDialog").close();
  renderProcessOverview();
});
function processRelationshipId(edge, index) {
  return edge.transitionId || edge.relationshipId || `relationship:${index}`;
}
function populateProcessRelationshipEditor(relationshipId = "") {
  const english = String(applicationSettings.uiLocale || "").startsWith("en");
  const outgoing = (activeProcessModel?.transitions || []).map((edge, index) => ({
    ...edge, editorId: processRelationshipId(edge, index)
  })).filter(edge => edge.fromNodeId === selectedProcessMapNodeId);
  const existing = $("processMapRelationshipExisting");
  existing.replaceChildren(...[{ editorId: "", label: english ? "New connection" : "Ny koppling" },
    ...outgoing.map(edge => ({ editorId: edge.editorId, label: edge.label ||
      `${edge.transitionType}: ${activeProcessModel.nodes.find(node =>
        node.nodeId === edge.toNodeId)?.title || edge.toNodeId}` }))].map(item => {
      const option = document.createElement("option"); option.value = item.editorId;
      option.textContent = item.label; return option;
    }));
  existing.value = outgoing.some(edge => edge.editorId === relationshipId) ? relationshipId : "";
  const selected = outgoing.find(edge => edge.editorId === existing.value);
  const targets = (activeProcessModel?.nodes || []).filter(node =>
    node.nodeId !== selectedProcessMapNodeId);
  $("processMapRelationshipTarget").replaceChildren(...targets.map(node => {
    const option = document.createElement("option"); option.value = node.nodeId;
    option.textContent = node.title; return option;
  }));
  if (selected) $("processMapRelationshipTarget").value = selected.toNodeId;
  $("processMapRelationshipType").value = selected?.transitionType || "sequence";
  $("processMapRelationshipLabel").value = selected?.label || selected?.condition || "";
  $("deleteProcessMapRelationship").disabled = !selected;
}
$("editProcessMapRelationship").addEventListener("click", () => {
  if (!selectedProcessMapNodeId || activeProcessMapLevel === "procedure") return;
  populateProcessRelationshipEditor();
  $("processMapRelationshipDialog").showModal();
});
$("processMapRelationshipExisting").addEventListener("change", event =>
  populateProcessRelationshipEditor(event.currentTarget.value));
$("saveProcessMapRelationship").addEventListener("click", () => {
  const targetId = $("processMapRelationshipTarget").value;
  if (!activeReview || !selectedProcessMapNodeId || !targetId) return;
  const existingId = $("processMapRelationshipExisting").value;
  const id = existingId || globalThis.T9ProcessMapRelationshipOverrides.createId(
    selectedProcessMapNodeId, targetId,
    (activeReview.processMapRelationshipOverrides || []).length + 1);
  activeReview.processMapRelationshipOverrides =
    globalThis.T9ProcessMapRelationshipOverrides.upsert(
      activeReview.processMapRelationshipOverrides || [], { relationshipId: id,
        fromNodeId: selectedProcessMapNodeId, toNodeId: targetId,
        transitionType: $("processMapRelationshipType").value,
        label: $("processMapRelationshipLabel").value, deleted: false });
  activeReview.updatedAt = new Date().toISOString(); reviewAutoSave.schedule();
  $("processMapRelationshipDialog").close(); renderProcessOverview();
});
$("deleteProcessMapRelationship").addEventListener("click", () => {
  const id = $("processMapRelationshipExisting").value;
  const edge = (activeProcessModel?.transitions || []).find((item, index) =>
    processRelationshipId(item, index) === id);
  if (!activeReview || !edge) return;
  activeReview.processMapRelationshipOverrides =
    globalThis.T9ProcessMapRelationshipOverrides.upsert(
      activeReview.processMapRelationshipOverrides || [], { relationshipId: id,
        fromNodeId: edge.fromNodeId, toNodeId: edge.toNodeId,
        transitionType: edge.transitionType, label: edge.label || "", deleted: true });
  activeReview.updatedAt = new Date().toISOString(); reviewAutoSave.schedule();
  $("processMapRelationshipDialog").close(); renderProcessOverview();
});
$("processMapLevels").addEventListener("click", async event => {
  const button = event.target.closest("[data-process-map-level]");
  if (!button || button.disabled) return;
  if (button.dataset.processMapLevel !== "procedure" && !activeProcessAnalysis) {
    try {
      await loadProcessAnalysis();
    } catch (error) {
      $("processOverview").innerHTML = `<p class="muted">${escapeHtml(uiTf(
        "process.overviewError", { detail: error.message }
      ))}</p>`;
      return;
    }
  }
  activeProcessMapLevel = button.dataset.processMapLevel;
  renderProcessOverview();
  $("processOverview").querySelector("[data-process-node-action]")?.focus();
});
function changeProcessMapZoom(value) {
  processMapZoom = globalThis.T9ProcessMapViewport.normalize(value);
  try {
    globalThis.localStorage?.setItem(PROCESS_MAP_ZOOM_STORAGE_KEY,
      String(processMapZoom));
  } catch {
    // The selected zoom remains active for the current dashboard session.
  }
  renderProcessOverview();
}
$("processMapZoomOut").addEventListener("click", () => changeProcessMapZoom(
  processMapZoom - globalThis.T9ProcessMapViewport.STEP
));
$("processMapZoomIn").addEventListener("click", () => changeProcessMapZoom(
  processMapZoom + globalThis.T9ProcessMapViewport.STEP
));
$("processMapResetZoom").addEventListener("click", () => changeProcessMapZoom(100));
$("processMapFit").addEventListener("click", () => changeProcessMapZoom(
  globalThis.T9ProcessMapViewport.measureFit($("processOverview"), processMapZoom)
));
$("processMapDirection").addEventListener("change", event => {
  processMapDirection = normalizedProcessMapDirection(event.currentTarget.value);
  try {
    globalThis.localStorage?.setItem(PROCESS_MAP_DIRECTION_STORAGE_KEY,
      processMapDirection);
  } catch {
    // The selected direction remains active for the current dashboard session.
  }
  renderProcessOverview();
});
$("processMapTheme").addEventListener("change", event => {
  processMapTheme = globalThis.T9ProcessMapTheme.normalize(event.currentTarget.value);
  try {
    globalThis.localStorage?.setItem(PROCESS_MAP_THEME_STORAGE_KEY, processMapTheme);
  } catch {
    // The selected theme remains active for the current dashboard session.
  }
  renderProcessOverview();
});
$("processMapDensity").addEventListener("change", event => {
  processMapDensity = normalizedProcessMapDensity(event.currentTarget.value);
  try {
    globalThis.localStorage?.setItem(PROCESS_MAP_DENSITY_STORAGE_KEY, processMapDensity);
  } catch {
    // The selected density remains active for the current dashboard session.
  }
  renderProcessOverview();
});
$("processMapIncludeReferences").addEventListener("change", event => {
  processMapIncludeReferences = event.currentTarget.checked;
  renderProcessOverview();
});
$("processMapFocus").addEventListener("click", () => setProcessMapFocus(
  !$("processOverviewDisclosure").classList.contains("process-map-focus")
));
function applyProcessMapSearch(advance) {
  const actions = [...$("processOverview").querySelectorAll("[data-process-node-action]")];
  const matches = globalThis.T9ProcessMapSearch.find(
    actions.map(action => action.textContent), $("processMapSearch").value
  );
  const matchIndexes = new Set(matches.map(match => match.index));
  if (advance) processMapSearchCursor = globalThis.T9ProcessMapSearch.next(
    matches, processMapSearchCursor
  );
  if (!matchIndexes.has(processMapSearchCursor)) processMapSearchCursor = -1;
  actions.forEach((action, index) => {
    action.classList.toggle("process-map-search-match", matchIndexes.has(index));
    action.classList.toggle("process-map-search-current", index === processMapSearchCursor);
  });
  const english = String(applicationSettings.uiLocale || "").startsWith("en");
  const hasQuery = Boolean($("processMapSearch").value.trim());
  $("processMapSearchResult").textContent = hasQuery
    ? `${matches.length} ${english ? (matches.length === 1 ? "match" : "matches") :
      (matches.length === 1 ? "träff" : "träffar")}` : "";
  $("processMapSearchNext").disabled = !matches.length;
  if (processMapSearchCursor >= 0) {
    actions[processMapSearchCursor]?.scrollIntoView?.({ block: "nearest", inline: "center" });
  }
}
$("processMapSearch").addEventListener("input", () => {
  processMapSearchCursor = -1;
  applyProcessMapSearch(false);
});
$("processMapSearch").addEventListener("keydown", event => {
  if (event.key === "Enter") {
    event.preventDefault();
    applyProcessMapSearch(true);
  } else if (event.key === "Escape" && event.currentTarget.value) {
    event.stopPropagation();
    event.currentTarget.value = "";
    processMapSearchCursor = -1;
    applyProcessMapSearch(false);
  }
});
$("processMapSearchNext").addEventListener("click", () => applyProcessMapSearch(true));
document.addEventListener("keydown", event => {
  if (event.key !== "Escape" ||
      !$("processOverviewDisclosure").classList.contains("process-map-focus")) return;
  event.preventDefault();
  setProcessMapFocus(false);
});
function scheduleProcessMapLayout() {
  if (!activeReview || !$('processOverviewDisclosure')?.open || processMapResizeFrame) return;
  processMapResizeFrame = requestAnimationFrame(() => {
    processMapResizeFrame = null;
    renderProcessOverview();
  });
}
window.addEventListener("resize", scheduleProcessMapLayout);
$("processOverviewDisclosure").addEventListener("toggle", event => {
  if (event.currentTarget.open) scheduleProcessMapLayout();
});
$("processMapLevels").addEventListener("keydown", event => {
  if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
  const buttons = [...event.currentTarget.querySelectorAll(
    "[data-process-map-level]:not(:disabled)"
  )];
  const current = buttons.indexOf(event.target);
  if (current < 0) return;
  const index = event.key === "Home" ? 0 : event.key === "End" ? buttons.length - 1 :
    (current + (event.key === "ArrowLeft" ? -1 : 1) + buttons.length) % buttons.length;
  event.preventDefault();
  buttons[index].focus();
  buttons[index].click();
});
$("exportProcessModel").addEventListener("click", () =>
  exportActiveProcess("model"));
$("exportProcessDiagram").addEventListener("click", () =>
  exportActiveProcess("diagram"));
$("saveProcessVersion").addEventListener("click", saveCurrentProcessVersion);
$("compareProcessVersions").addEventListener("click",
  openProcessVersionComparison);
$("processVersionFrom").addEventListener("change",
  renderProcessVersionComparison);
$("processVersionTo").addEventListener("change",
  renderProcessVersionComparison);
$("processOverview").addEventListener("keydown", event => {
  const action = event.target.closest?.("[data-process-node-action]");
  if (!action || !["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown",
    "Home", "End"].includes(event.key)) {
    return;
  }
  const actions = [...$("processOverview").querySelectorAll(
    "[data-process-node-action]"
  )];
  const current = actions.indexOf(action);
  const next = event.key === "Home" ? 0 : event.key === "End"
    ? actions.length - 1 : Math.max(0, Math.min(actions.length - 1,
      current + (["ArrowLeft", "ArrowUp"].includes(event.key) ? -1 : 1)));
  event.preventDefault();
  actions[next]?.focus();
});
$("workspaceTabs").addEventListener("keydown", event => {
  const workspace = globalThis.T9WorkspaceController.workspaceFromKey(
    workspaceState.active,
    event.key
  );
  if (workspace === workspaceState.active) return;
  event.preventDefault();
  switchWorkspace(workspace, true);
});

$("reviewResetZoom").addEventListener("click", () => changeReviewZoom(100));
$("reviewZoomOut").addEventListener("click", () => {
  changeReviewZoom(reviewZoom - REVIEW_ZOOM_STEP);
});
$("reviewZoomIn").addEventListener("click", () => {
  changeReviewZoom(reviewZoom + REVIEW_ZOOM_STEP);
});

$("documentFitWidth").addEventListener("click", () => {
  changeDocumentView(globalThis.T9DocumentWorkspaceExperience.fit(
    documentViewState,
    "fitWidth"
  ));
});
$("documentFitPage").addEventListener("click", () => {
  changeDocumentView(globalThis.T9DocumentWorkspaceExperience.fit(
    documentViewState,
    "fitPage"
  ));
});
$("documentResetZoom").addEventListener("click", () => {
  changeDocumentView(globalThis.T9DocumentWorkspaceExperience.setZoom(
    documentViewState,
    100
  ));
});
$("documentZoomOut").addEventListener("click", () => {
  changeDocumentView(globalThis.T9DocumentWorkspaceExperience.zoomBy(
    documentViewState,
    -1
  ));
});
$("documentZoomIn").addEventListener("click", () => {
  changeDocumentView(globalThis.T9DocumentWorkspaceExperience.zoomBy(
    documentViewState,
    1
  ));
});
$("documentContinuousMode").addEventListener("click", () => {
  changeDocumentView(globalThis.T9DocumentWorkspaceExperience.setViewMode(
    documentViewState,
    "continuous"
  ), { preserveFocalPosition: false });
  documentSections()[documentViewState.currentPage - 1]
    ?.scrollIntoView({ block: "start" });
});
$("documentPageMode").addEventListener("click", () => {
  changeDocumentView(globalThis.T9DocumentWorkspaceExperience.setViewMode(
    documentViewState,
    "page"
  ), { preserveFocalPosition: false });
  $("documentWorkspaceViewport").scrollTop = 0;
});
$("documentPreviousPage").addEventListener("click", () => {
  navigateDocument("previous");
});
$("documentNextPage").addEventListener("click", () => {
  navigateDocument("next");
});
async function activateDocumentContext(target) {
  const item = target.closest?.("[data-workspace-context-target=true]");
  const itemContext = workspaceContextBinding?.byItemId?.[
    item?.dataset.documentWorkspaceItemId
  ];
  if (!itemContext?.selectedStepId) return;
  publishWorkspaceContext(itemContext, "document-selection", "document");
  await switchWorkspace("review");
  revealReviewContext({ focus: true });
}
$("documentWorkspace").addEventListener("click", event => {
  activateDocumentContext(event.target);
});
$("documentWorkspace").addEventListener("keydown", event => {
  if (!["Enter", " "].includes(event.key)) return;
  const item = event.target.closest?.("[data-workspace-context-target=true]");
  if (!item) return;
  event.preventDefault();
  activateDocumentContext(item);
});
$("documentWorkspacePanel").addEventListener("keydown", event => {
  if (event.target.closest("button,select,dialog")) return;
  if (event.key === "Home") {
    event.preventDefault();
    navigateDocument("home");
  } else if (event.key === "End") {
    event.preventDefault();
    navigateDocument("end");
  } else if (event.key === "PageUp") {
    event.preventDefault();
    navigateDocument("previous");
  } else if (event.key === "PageDown") {
    event.preventDefault();
    navigateDocument("next");
  } else if (event.ctrlKey && ["+", "="].includes(event.key)) {
    event.preventDefault();
    changeDocumentView(globalThis.T9DocumentWorkspaceExperience.zoomBy(
      documentViewState,
      1
    ));
  } else if (event.ctrlKey && event.key === "-") {
    event.preventDefault();
    changeDocumentView(globalThis.T9DocumentWorkspaceExperience.zoomBy(
      documentViewState,
      -1
    ));
  } else if (event.ctrlKey && event.key === "0") {
    event.preventDefault();
    changeDocumentView(globalThis.T9DocumentWorkspaceExperience.setZoom(
      documentViewState,
      100
    ));
  }
});
$("documentWorkspaceViewport").addEventListener(
  "scroll",
  () => {
    if (documentScrollFrame) return;
    documentScrollFrame = requestAnimationFrame(() => {
      documentScrollFrame = 0;
      updateContinuousDocumentPage();
    });
  },
  { passive: true }
);
globalThis.addEventListener("resize", () => {
  if (workspaceState.active === "document") {
    scheduleDocumentView({ persist: false });
  }
});
$("openDocumentViewSettings").addEventListener("click", () => {
  $("documentAdaptiveReading").value = documentViewState.adaptiveReading;
  $("documentToolbarLayout").value = documentViewState.toolbarLayout;
  $("documentViewSettings").showModal();
  $("documentAdaptiveReading").focus();
});
$("documentAdaptiveReading").addEventListener("change", event => {
  changeDocumentView(globalThis.T9DocumentWorkspaceExperience.update(
    documentViewState,
    { adaptiveReading: event.target.value }
  ));
});
$("documentToolbarLayout").addEventListener("change", event => {
  changeDocumentView(globalThis.T9DocumentWorkspaceExperience.update(
    documentViewState,
    { toolbarLayout: event.target.value }
  ));
});
$("closeDocumentViewSettings").addEventListener("click", () => {
  $("documentViewSettings").close();
  $("openDocumentViewSettings").focus();
});

$("closeReview").addEventListener("click", closeReview);
$("closeAnnotationEditor").addEventListener("click", async () => {
  try {
    await closeAnnotationEditor();
  } catch (error) {
    $("annotationStatus").textContent =
      `Annoteringarna kunde inte sparas: ${error.message}`;
  }
});
$("cancelAnnotationEditor").addEventListener("click", async () => {
  try {
    await closeAnnotationEditor({ cancel: true });
  } catch (error) {
    $("annotationStatus").textContent =
      `Återställningen kunde inte sparas: ${error.message}`;
  }
});
$("rectangleAnnotationTool").addEventListener("click", () => {
  annotationEditorState = globalThis.T9ReviewAnnotationEditor.selectTool(
    annotationEditorState,
    "rectangle"
  );
  renderActiveAnnotation();
  $("annotationSurface").focus();
});
$("arrowAnnotationTool").addEventListener("click", () => {
  annotationEditorState = globalThis.T9ReviewAnnotationEditor.selectTool(
    annotationEditorState,
    "arrow"
  );
  renderActiveAnnotation();
  $("annotationSurface").focus();
});
$("deleteAnnotation").addEventListener("click", deleteSelectedAnnotation);
$("annotationList").addEventListener("click", event => {
  const button = event.target.closest?.("[data-annotation-id]");
  if (!button || !annotationEditorState) return;
  annotationEditorState = globalThis.T9ReviewAnnotationEditor.select(
    annotationEditorState,
    button.dataset.annotationId
  );
  renderActiveAnnotation();
  $("annotationSurface").focus();
});
$("annotationProperties").addEventListener("click", event => {
  if (!event.target.closest?.('[data-action="apply-annotation-geometry"]')) {
    return;
  }
  const selected = annotationById(annotationEditorState?.selectedId);
  if (!selected) return;
  const geometry = { ...selected.geometry };
  for (const input of $("annotationProperties").querySelectorAll(
    "[data-annotation-geometry]"
  )) {
    geometry[input.dataset.annotationGeometry] = Number(input.value) / 100;
  }
  updateAnnotation(
    selected.annotationId,
    geometry,
    "Markeringens geometri uppdaterades.",
    { type: selected.type === "arrow" ? "annotation-endpoints" : "annotation-resize" }
  );
});
$("annotationImage").addEventListener("load", () => {
  renderActiveAnnotation(false);
});
globalThis.addEventListener("resize", updateAnnotationStickyOffset);
$("annotationSurface").addEventListener("pointerdown", event => {
  if (!annotationEditorState || event.button !== 0) return;
  const start = globalThis.T9ReviewAnnotationEditor.point(
    event.clientX,
    event.clientY,
    event.currentTarget.getBoundingClientRect()
  );
  const annotationId = event.target.dataset?.annotationId;
  const annotation = annotationById(annotationId);
  const nextState = annotation
    ? globalThis.T9ReviewAnnotationEditor.beginTranslation(
      annotationEditorState,
      annotation,
      start
    )
    : globalThis.T9ReviewAnnotationEditor.begin(annotationEditorState, start);
  annotationEditorState = { ...nextState, pointerId: event.pointerId };
  try {
    event.currentTarget.setPointerCapture?.(event.pointerId);
  } catch {
    annotationEditorState = globalThis.T9ReviewAnnotationEditor.cancel(
      annotationEditorState
    );
    releaseActiveAnnotationPointer();
    $("annotationStatus").textContent =
      "Pekgesten kunde inte startas. Försök igen.";
  }
  renderActiveAnnotation();
  event.preventDefault();
});
$("annotationSurface").addEventListener("pointermove", event => {
  if ((!annotationEditorState?.draft && !annotationEditorState?.translation) ||
      annotationEditorState.pointerId !== event.pointerId) return;
  const end = globalThis.T9ReviewAnnotationEditor.point(
    event.clientX,
    event.clientY,
    event.currentTarget.getBoundingClientRect()
  );
  annotationEditorState = annotationEditorState.translation
    ? globalThis.T9ReviewAnnotationEditor.moveTranslation(
      annotationEditorState,
      end
    )
    : globalThis.T9ReviewAnnotationEditor.move(annotationEditorState, end);
  renderActiveAnnotation(false);
});
$("annotationSurface").addEventListener("pointerup", event => {
  if ((!annotationEditorState?.draft && !annotationEditorState?.translation) ||
      annotationEditorState.pointerId !== event.pointerId) return;
  try {
    const end = globalThis.T9ReviewAnnotationEditor.point(
      event.clientX,
      event.clientY,
      event.currentTarget.getBoundingClientRect()
    );
    if (annotationEditorState.translation) {
      const movedState = globalThis.T9ReviewAnnotationEditor.moveTranslation(
        annotationEditorState,
        end
      );
      const result = globalThis.T9ReviewAnnotationEditor.finishTranslation(
        movedState
      );
      annotationEditorState = result.state;
      updateAnnotation(
        result.change.annotationId,
        result.change.geometry,
        "Markeringen flyttades.",
        { type: "annotation-move" }
      );
    } else {
      const movedState = globalThis.T9ReviewAnnotationEditor.move(
        annotationEditorState,
        end
      );
      const type = movedState.draft.type;
      const result = globalThis.T9ReviewAnnotationEditor.finish(movedState);
      annotationEditorState = result.state;
      addAnnotation(type, result.geometry);
    }
  } finally {
    releaseActiveAnnotationPointer();
  }
});
$("annotationSurface").addEventListener("pointercancel", event => {
  if (!annotationEditorState?.draft && !annotationEditorState?.translation) return;
  try {
    annotationEditorState = globalThis.T9ReviewAnnotationEditor.cancel(
      annotationEditorState
    );
    renderActiveAnnotation();
  } finally {
    releaseActiveAnnotationPointer();
  }
});
$("annotationSurface").addEventListener("keydown", event => {
  if (!annotationEditorState) return;
  if (event.key === "Enter") {
    event.preventDefault();
    const type = annotationEditorState.tool;
    addAnnotation(
      type,
      type === "arrow"
        ? globalThis.T9ReviewAnnotationEditor.centeredArrow()
        : globalThis.T9ReviewAnnotationEditor.centeredRectangle()
    );
  } else if (event.key === "Delete") {
    event.preventDefault();
    deleteSelectedAnnotation();
  } else if (event.key.startsWith("Arrow") &&
      annotationEditorState.selectedId) {
    event.preventDefault();
    const annotation = annotationById(annotationEditorState.selectedId);
    if (!annotation) {
      annotationEditorState = globalThis.T9ReviewAnnotationEditor.select(
        annotationEditorState,
        null
      );
      renderActiveAnnotation();
      return;
    }
    const image = $("annotationImage");
    const multiplier = event.shiftKey ? 10 : 1;
    const horizontal = multiplier / image.naturalWidth;
    const vertical = multiplier / image.naturalHeight;
    const deltaX = event.key === "ArrowLeft"
      ? -horizontal
      : event.key === "ArrowRight" ? horizontal : 0;
    const deltaY = event.key === "ArrowUp"
      ? -vertical
      : event.key === "ArrowDown" ? vertical : 0;
    updateAnnotation(
      annotation.annotationId,
      globalThis.T9ReviewAnnotationEditor.translatedGeometry(
        annotation.type,
        annotation.geometry,
        deltaX,
        deltaY
      ),
      "Markeringen flyttades.",
      {
        type: "annotation-move",
        groupKey: `annotation-nudge:${annotationEditorState.screenshotRef}:${annotation.annotationId}`
      }
    );
  } else if (event.key === "Escape" &&
      (annotationEditorState.draft || annotationEditorState.translation)) {
    event.preventDefault();
    annotationEditorState = globalThis.T9ReviewAnnotationEditor.cancel(
      annotationEditorState
    );
    releaseActiveAnnotationPointer();
    renderActiveAnnotation();
    $("annotationStatus").textContent = "Pågående markering avbröts.";
  }
});
let reviewWordExportPending = false;

function setReviewExportStatus(message, error = false) {
  const status = $("reviewExportStatus");
  status.hidden = false;
  status.textContent = message;
  status.classList.toggle("export-error", error);
}

async function exportReviewFromToolbar(button) {
  // DOM attributes are presentation state, not the export operation lock.
  if (reviewWordExportPending) return;
  reviewWordExportPending = true;
  const buttons = [$("exportWordReview"), $("documentExportWord")].filter(Boolean);
  buttons.forEach(control => {
    control.disabled = true;
    control.setAttribute("aria-busy", "true");
  });
  button.textContent = uiT("review.exportWorking");
  setReviewExportStatus(uiT("review.exportWorking"));
  let persistenceWarning = "";
  try {
    try {
      await reviewPersistence.saveExplicitly({ render: false });
    } catch (error) {
      persistenceWarning = error.message;
    }
    await exportActiveReviewToWord();
    setReviewExportStatus(persistenceWarning
      ? uiT("review.exportUnsaved") + " " + persistenceWarning
      : uiT("review.exportDownloaded"), Boolean(persistenceWarning));
  } catch (error) {
    const message = uiT("review.exportFailed") + " " + (error?.message || String(error));
    setReviewExportStatus(message, true);
    show(message, true);
  } finally {
    reviewWordExportPending = false;
    buttons.forEach(control => {
      control.removeAttribute("aria-busy");
      control.textContent = uiT("Exportera Word");
      control.disabled = false;
    });
    try {
      applyReviewToolbarState();
      if (activeReview) renderDocumentExportCheck();
    } catch (error) {
      console.warn("Export controls could not be refreshed", error);
    }
  }
}

globalThis.T9ReviewToolbar.bind($("reviewToolbar"), (command, button) => {
  if (command === "undo") restoreReviewHistory("undo");
  else if (command === "redo") restoreReviewHistory("redo");
  else if (command === "merge") mergeSelectedReviewTasks();
  else if (command === "split") splitSelectedReviewTask();
  else if (command === "reset-structure") {
    globalThis.T9Review.resetStructure(activeReview, {
      beforeSelection: activeReviewSelection
    });
    activeReviewSelection = globalThis.T9ReviewSelection.create();
    reviewAutoSave.schedule();
    renderReview();
    show("Dokumentstrukturen återställdes till genererad struktur.");
  } else if (command === "move-up") {
    moveReviewTasksByOffset(
      -1,
      activeReviewSelection.activeId || activeReviewSelection.selectedIds[0]
    );
  } else if (command === "move-down") {
    moveReviewTasksByOffset(
      1,
      activeReviewSelection.activeId || activeReviewSelection.selectedIds[0]
    );
  } else if (command === "export") {
    exportReviewFromToolbar(button);
  }
});

async function saveReviewExplicitly() {
  try {
    await reviewPersistence.saveExplicitly();
  } catch (error) {
    show(error.message, true);
  }
}
$("saveReview").addEventListener("click", saveReviewExplicitly);
$("saveReviewBottom").addEventListener("click", saveReviewExplicitly);
$("nextUnreviewedStep").addEventListener("click",
  activateNextUnreviewedStep);
$("openReviewDocumentFields").addEventListener("click", () => {
  setTimeout(() => {
    $("reviewDocumentFieldsDialog").showModal();
    $("reviewDocumentLanguage").focus();
  });
});
$("openProcessAnalysis").addEventListener("click", openProcessAnalysisDialog);
$("processAnalysisContent").addEventListener("change", event => {
  if (event.target.matches('input[name="processAnalysisReference"], input[name="processAnalysisVariant"]')) {
    $("useSelectedReference").disabled = false;
  }
});
$("confirmProcessAnalysis").addEventListener("click", () => {
  const model = globalThis.T9ProcessAnalysisView.normalize(
    activeProcessAnalysis || {}, activeReview?.processAnalysis
  );
  const reference = globalThis.T9ProcessAnalysisView.selectedReference(
    $("processAnalysisContent"), model
  );
  const variant = reference.id === model.referenceId
    ? globalThis.T9ProcessAnalysisView.selectedVariant(
      $("processAnalysisContent"), model)
    : null;
  persistProcessAnalysisDecision(reference, "confirmed", variant);
});
$("useSelectedReference").addEventListener("click", () => {
  const model = globalThis.T9ProcessAnalysisView.normalize(
    activeProcessAnalysis || {}, activeReview?.processAnalysis
  );
  const reference = globalThis.T9ProcessAnalysisView.selectedReference(
    $("processAnalysisContent"), model
  );
  const variant = globalThis.T9ProcessAnalysisView.selectedVariant(
    $("processAnalysisContent"), model);
  persistProcessAnalysisDecision(reference, "selected", variant);
});
$("expectedResultEditor").addEventListener("input", event => {
  globalThis.T9Review.setDocumentField(
    activeReview,
    "expectedResult",
    event.currentTarget.value,
    { beforeSelection: activeReviewSelection,
      afterSelection: activeReviewSelection }
  );
  reviewAutoSave.schedule();
  invalidateDocumentWorkspace();
  applyReviewToolbarState();
});
$("reviewDocumentProfile").addEventListener("change", async event => {
  const profile = documentProfiles().find(value => value.profileId === event.currentTarget.value);
  if (!profile || !activeReviewSession || !activeReview) return;
  const session = activeReviewSession;
  const review = activeReview;
  const select = event.currentTarget;
  select.disabled = true;
  $("reviewDocumentProfileStatus").textContent = uiT("review.profileSaving");
  try {
    await updateDocumentLibraryRecord(session.id, {
      profile: { profileId: profile.profileId, displayName: profile.displayName },
      theme: { themeId: profile.theme.themeId, displayName: profile.theme.themeId }
    });
    if (activeReview !== review || activeReviewSession !== session) return;
    activeDocumentProfileId = profile.profileId;
    invalidateDocumentWorkspace();
    renderReviewContent();
    await synchronizeDocumentWorkspace();
    if (activeReview === review && activeReviewSession === session) {
      $("reviewDocumentProfileStatus").textContent = uiT("review.profileSaved");
    }
  } catch (error) {
    if (activeReview === review && activeReviewSession === session) {
      renderDocumentProfileChoice();
      $("reviewDocumentProfileStatus").textContent = error.message;
    }
  } finally {
    select.disabled = false;
  }
});

$("reviewDocumentLanguage").addEventListener("change", event => {
  const documentLanguage = globalThis.T9LanguageRegistry.normalize(
    event.currentTarget.value, "document"
  );
  globalThis.T9Review.setDocumentField(
    activeReview,
    "documentLanguage",
    documentLanguage,
    { beforeSelection: activeReviewSelection,
      afterSelection: activeReviewSelection,
      groupKey: "document-field:documentLanguage" }
  );
  reviewAutoSave.schedule();
  invalidateDocumentWorkspace();
  renderReviewContent();
  applyReviewToolbarState();
  if (activeReviewSession?.id) {
    updateDocumentLibraryRecord(activeReviewSession.id, {
      documentLanguage
    }).catch(error => show(error.message, true));
  }
});
$("resetExpectedResult").addEventListener("click", () => {
  globalThis.T9Review.setDocumentField(
    activeReview,
    "expectedResult",
    "",
    { beforeSelection: activeReviewSelection,
      afterSelection: activeReviewSelection,
      groupKey: "document-field-reset:expectedResult" }
  );
  $("expectedResultEditor").value =
    displayedExpectedResult();
  reviewAutoSave.schedule();
  invalidateDocumentWorkspace();
  applyReviewToolbarState();
  show("Förväntat resultat återställdes till standardtexten.");
});
$("reviewMoreActions").addEventListener("toggle", event => {
  event.currentTarget.querySelector("summary").setAttribute(
    "aria-expanded",
    String(event.currentTarget.open)
  );
});
$("reviewMoreActions").addEventListener("click", event => {
  const button = event.target.closest?.("button");
  if (!button || button.disabled) return;
  event.currentTarget.open = false;
  event.currentTarget.querySelector("summary").focus();
});
$("compactReviewSteps").addEventListener("click", () => {
  reviewLayoutState = globalThis.T9ReviewLayout.toggleAll(
    reviewLayoutState,
    reviewTaskIds()
  );
  globalThis.T9ReviewLayout.apply(
    $("reviewList"),
    $("compactReviewSteps"),
    reviewLayoutState
  );
});
$("addReviewStep").addEventListener("click", () => {
  addManualInformationStep(undefined);
});

function regenerationStepLabel(step) {
  return String(step?.instruction || "").trim() ||
    `Steg ${String(step?.stepId || "utan namn")}`;
}

function regenerationChangeGroup(title, items) {
  if (!items.length) return "";
  return `<section class="regeneration-preview-group"><h4>${escapeHtml(title)}</h4>` +
    `<ul>${items.map(item => `<li>${escapeHtml(item)}</li>`).join("")}</ul></section>`;
}

function regenerationBlockingMessage(reasons = []) {
  if (reasons.includes("empty-generated-result")) {
    return "Den nya tolkningen gav inga steg. Den sparade granskningen kommer inte att \u00e4ndras.";
  }
  if (reasons.includes("selection-structure-change")) {
    return uiT("Urvalet inneh\u00e5ller steg som har slagits samman, delats eller tagits bort. Anv\u00e4nd full regenerering f\u00f6r att granska struktur\u00e4ndringen s\u00e4kert.");
  }
  if (reasons.includes("selection-annotated-image")) {
    return uiT("En vald sk\u00e4rmbild har markeringar och skulle bytas. Byt bilden manuellt eller anv\u00e4nd full regenerering s\u00e5 att markeringarna inte tappas bort.");
  }
  if (reasons.includes("selection-approved")) {
    return uiT("Ett valt steg \u00e4r godk\u00e4nt. Ta bort godk\u00e4nnandet innan steget regenereras.");
  }
  if (reasons.some(reason => reason.startsWith("selection-"))) {
    return uiT("De valda stegen kan inte mappas exakt till den nya tolkningen. Ingen dokumentation har \u00e4ndrats.");
  }
  return "Granskningen inneh\u00e5ller manuella \u00e4ndringar som inte kan flyttas s\u00e4kert. Regenereringen \u00e4r blockerad s\u00e5 att inget konsultarbete skrivs \u00f6ver.";
}

function showRegenerationPreview(preview) {
  const dialog = $("regenerationPreviewDialog");
  const selective = preview.scope === "selected-steps";
  $("regenerationPreviewTitle").textContent = selective
    ? uiT("F\u00f6rhandsgranska valda steg")
    : uiT("F\u00f6rhandsgranska regenerering");
  $("regenerationPreviewDescription").textContent = selective
    ? uiT("Endast de valda stegen uppdateras. Alla andra steg l\u00e4mnas of\u00f6r\u00e4ndrade.")
    : uiT("Granska vad som \u00e4ndras innan dokumentationen uppdateras.");
  $("applyRegenerationPreview").textContent = selective
    ? uiT("Godk\u00e4nn valda steg") : uiT("Godk\u00e4nn och regenerera");
  const changes = preview.changeSet || {};
  const stats = [
    [preview.previousStepCount, "Nuvarande"],
    [preview.nextStepCount, "Efter"],
    [preview.addedStepCount, "Tillagda"],
    [preview.removedStepCount, "Borttagna"],
    [preview.changedStepCount, "\u00c4ndrade"],
    ...(preview.scope === "selected-steps"
      ? [[preview.generatedBaselineChangeCount, uiT("Ny standardtext")]] : []),
    [preview.screenshotChangeCount, "Nya bilder"],
    [preview.preservedStepEditCount, "Bevarade redigeringar"]
  ];
  $("regenerationPreviewSummary").innerHTML = stats.map(([value, label]) =>
    `<div class="regeneration-preview-stat"><strong>${Number(value) || 0}</strong>` +
      `<span>${escapeHtml(label)}</span></div>`).join("");
  const groups = [
    regenerationChangeGroup("Tillagda steg", (changes.added || [])
      .map(regenerationStepLabel)),
    regenerationChangeGroup("Borttagna steg", (changes.removed || [])
      .map(regenerationStepLabel)),
    regenerationChangeGroup("\u00c4ndrad instruktion", (changes.changed || [])
      .map(item => `${regenerationStepLabel(item.before)} \u2192 ${regenerationStepLabel(item.after)}`)),
    regenerationChangeGroup(uiT("Ny standardtext bakom redigering"),
      (changes.generatedChanges || [])
        .map(item => `${regenerationStepLabel(item.before)} \u2192 ${regenerationStepLabel(item.after)}`)),
    regenerationChangeGroup("Sammanslagna steg", (changes.merges || [])
      .map(item => `${item.before.map(regenerationStepLabel).join(" + ")} \u2192 ${item.after.map(regenerationStepLabel).join(" + ")}`)),
    regenerationChangeGroup("Delade steg", (changes.splits || [])
      .map(item => `${item.before.map(regenerationStepLabel).join(" + ")} \u2192 ${item.after.map(regenerationStepLabel).join(" + ")}`)),
    regenerationChangeGroup("Bytt sk\u00e4rmbild", (changes.screenshotChanges || [])
      .map(item => regenerationStepLabel(item.after)))
  ].filter(Boolean);
  $("regenerationPreviewChanges").innerHTML = groups.join("") ||
    `<p class="muted">Inga inneh\u00e5lls\u00e4ndringar uppt\u00e4cktes.</p>`;
  const warning = $("regenerationPreviewWarning");
  warning.hidden = !preview.blocked;
  warning.textContent = preview.blocked
    ? regenerationBlockingMessage(preview.blockingReasons) : "";
  $("applyRegenerationPreview").hidden = preview.blocked;
  $("applyRegenerationPreview").disabled = preview.blocked;
  dialog.returnValue = "cancel";
  dialog.showModal();
  return new Promise(resolve => dialog.addEventListener("close", () => {
    resolve(dialog.returnValue === "apply" && !preview.blocked);
  }, { once: true }));
}

async function runReviewRegeneration(selectedIds = null) {
  if (!activeReview || !activeReviewSession || !activeReviewModel) return;
  try {
    const preview = selectedIds
      ? globalThis.T9ReviewRegeneration.selectivePreview(
        activeReview, activeReviewSession, activeReviewModel.businessTasks,
        selectedIds
      )
      : globalThis.T9ReviewRegeneration.preview(
        activeReview, activeReviewSession, activeReviewModel.businessTasks
      );
    if (!await showRegenerationPreview(preview)) {
      if (preview.blocked) show(regenerationBlockingMessage(
        preview.blockingReasons), true);
      return;
    }
    activeReview = selectedIds
      ? globalThis.T9ReviewRegeneration.applySelective(activeReview, preview)
      : globalThis.T9ReviewRegeneration.apply(activeReview, preview);
    if (!selectedIds) {
      activeReviewSelection = globalThis.T9ReviewSelection.create();
    }
    activeReviewEdit = null;
    invalidateDocumentWorkspace();
    await saveActiveReview({ announce: false, render: false });
    renderReview();
    show(selectedIds
      ? uiTf("review.selectedRegenerated", { count: preview.nextStepCount })
      : `Dokumentationen har regenererats fr\u00e5n inspelningen. ` +
        `${preview.previousStepCount} steg blev ${preview.nextStepCount}.`);
  } catch (error) {
    if (error?.code === "STALE_REGENERATION_PREVIEW") {
      show(uiT("Granskningen ändrades efter förhandsgranskningen. " +
        "Öppna en ny förhandsgranskning och kontrollera ändringarna igen."), true);
      return;
    }
    show(`Dokumentationen kunde inte regenereras: ${error.message}`, true);
  }
}

$("regenerateReview").addEventListener("click", () =>
  runReviewRegeneration());
$("regenerateSelectedReview").addEventListener("click", () =>
  runReviewRegeneration([...activeReviewSelection.selectedIds]));
$("completeReview").addEventListener("click", async () => {
  globalThis.T9Review.complete(activeReview, {
    beforeSelection: activeReviewSelection,
    afterSelection: activeReviewSelection
  });
  try {
    await saveActiveReview();
  } catch (error) {
    show(error.message, true);
  }
});
globalThis.T9ReviewAccessibility.bindDialog($("reviewDialog"), async () => {
  try {
    if (annotationEditorState) await closeAnnotationEditor();
    else await closeReview();
  } catch (error) {
    const target = annotationEditorState
      ? $("annotationStatus")
      : $("reviewFooterText");
    target.textContent = `Det gick inte att stänga: ${error.message}`;
  }
});
$("reviewOverlay").addEventListener("click", event => {
  if (event.target === $("reviewOverlay")) closeReview();
});
$("reviewOverlay").addEventListener("keydown", event => {
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "s") {
    event.preventDefault();
    saveReviewExplicitly();
    return;
  }
  if (event.target.closest?.('[data-editing="true"]')) return;
  if (event.altKey && !event.ctrlKey && !event.metaKey &&
      event.key.toLowerCase() === "n") {
    event.preventDefault();
    activateNextUnreviewedStep();
    return;
  }
  const direction = globalThis.T9Review.historyDirectionFromKey(event);
  if (!direction) return;
  event.preventDefault();
  restoreReviewHistory(direction);
});
globalThis.T9ReviewSelection.bind($("reviewList"), {
  dispatch: dispatchReviewSelection,
  move: moveReviewTasksByOffset
});
globalThis.T9ProcessMapDrag.bind($("processOverview"), {
  move({ draggedId, targetId, position }) {
    if (!activeReview || !activeProcessBaseModel || activeProcessMapLevel === "procedure") return;
    activeReview.processMapOverrides = globalThis.T9ProcessMapOverrides.moveTo(
      activeReview.processMapOverrides || [], activeProcessBaseModel,
      draggedId, targetId, position
    );
    activeReview.updatedAt = new Date().toISOString();
    reviewAutoSave.schedule();
    selectedProcessMapNodeId = draggedId;
    renderProcessOverview();
    globalThis.T9ProcessOverviewView.selectNode($("processOverview"), draggedId);
  }
});

globalThis.T9ReviewMove.bind($("reviewList"), {
  move: moveReviewTasksTo
});

$("save").addEventListener("click", saveSettings);
$("testKnowledgeMcp").addEventListener("click", testKnowledgeMcpConnection);
$("testKnowledgeMcpSampleLookup").addEventListener("click", testKnowledgeMcpSampleLookup);
$("saveSupportEmail").addEventListener("click", saveSupportEmail);
$("uiLocale").addEventListener("change", changeUiLocale);
$("refresh").addEventListener("click", loadSessions);
$("sessionTools").addEventListener("toggle", () => {
  if ($("sessionTools").open) {
    loadSessions().catch(error => show(error.message, true));
  } else {
    $("sessions").replaceChildren();
  }
});
for (const id of ["librarySearch", "libraryProfileFilter",
  "libraryThemeFilter", "libraryLanguageFilter", "librarySort",
  "libraryFavouriteFilter", "libraryRecentFilter", "libraryGroupProfiles",
  "libraryCreatedFrom", "libraryCreatedTo", "libraryModifiedFrom",
  "libraryModifiedTo"]) {
  $(id)?.addEventListener(id === "librarySearch" ? "input" : "change",
    renderDocumentLibrary);
}
$("libraryResetFilters").addEventListener("click",
  resetDocumentLibraryFilters);
$("librarySearch").addEventListener("keydown", event => {
  if (event.key !== "Escape" || !event.currentTarget.value) return;
  event.preventDefault();
  event.currentTarget.value = "";
  renderDocumentLibrary();
  $("libraryStatus").textContent += " Sökningen rensades.";
});
$("libraryResults").addEventListener("click", async event => {
  const card = event.target.closest?.("[data-library-project-id]");
  if (!card) return;
  const projectId = card.dataset.libraryProjectId;
  const visibleIds = [...$("libraryResults").querySelectorAll(
    "[data-library-project-id]"
  )].map(element => element.dataset.libraryProjectId);
  const selectionControl = event.target.closest?.('[data-library-action="select"]');
  const cardAction = event.target.closest?.("[data-library-action]");
  if (selectionControl || !cardAction) {
    documentLibrarySelection = globalThis.T9DocumentBatchOperations.select(
      documentLibrarySelection, visibleIds, projectId, {
        shift: event.shiftKey,
        toggle: Boolean(selectionControl || event.ctrlKey || event.metaKey)
      }
    );
    renderDocumentLibrarySelection();
    $("libraryResults").querySelector(
      `[data-library-project-id="${CSS.escape(projectId)}"]`
    )?.focus();
    return;
  }
  if (event.target.closest?.('[data-library-action="favourite"]')) {
    const record = documentLibraryRecords.find(value => value.projectId === projectId);
    try {
      await updateDocumentLibraryRecord(projectId, {
        favourite: !record?.favourite
      });
    } catch (error) {
      show(error.message, true);
    }
    $("libraryResults").querySelector(
      `[data-library-project-id="${CSS.escape(projectId)}"]`
    )?.focus();
    return;
  }
  if (!event.target.closest?.('[data-library-action="open"]')) return;
  const session = documentLibrarySessions.get(projectId);
  if (!session || session.status === "recording") return;
  const libraryRecord = documentLibraryRecords.find(record =>
    record.projectId === projectId);
  const bugReport = session.recordingPurpose === "bug-report" ||
    libraryRecord?.metadata?.recordingPurpose === "bug-report";
  try {
    await updateDocumentLibraryRecord(projectId, {
      lastOpenedAt: new Date().toISOString(),
      recentActivity: [bugReport
        ? "Felrapporten öppnades" : "Dokumentationen öppnades"]
    }, { render: false });
  } catch (error) {
    show(error.message, true);
  }
  try {
    if (bugReport) {
      await send({ type: "T9_OPEN_TECHNICAL_REPORT",
        bugReportId: `bug-report:${session.id}` });
    } else {
      await openReview(session);
    }
  } catch (error) {
    show(error.message, true);
  }
});
$("libraryResults").addEventListener("keydown", event => {
  const card = event.target.closest?.("[data-library-project-id]");
  const visibleIds = visibleDocumentLibraryRecords.map(record => record.projectId);
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "a") {
    const matches = globalThis.T9DocumentLibrary.query(
      documentLibraryIndex, libraryOptions()
    );
    event.preventDefault();
    documentLibrarySelection = globalThis.T9DocumentBatchOperations.selectAll(
      documentLibrarySelection, matches.map(record => record.projectId)
    );
    renderDocumentLibrarySelection();
    renderLibraryBatchToolbar(`${matches.length} dokument valdes.`);
    return;
  }
  if (event.key === "Escape" && documentLibrarySelection.selectedIds.length) {
    event.preventDefault();
    documentLibrarySelection = globalThis.T9DocumentBatchOperations.clear();
    renderDocumentLibrarySelection();
    renderLibraryBatchToolbar("Dokumentvalet rensades.");
    return;
  }
  if (event.key === " " && event.target === card) {
    event.preventDefault();
    documentLibrarySelection = globalThis.T9DocumentBatchOperations.select(
      documentLibrarySelection, visibleIds, card.dataset.libraryProjectId,
      { toggle: true }
    );
    renderDocumentLibrarySelection();
    return;
  }
  if (event.key === "Enter" && event.target === card) {
    event.preventDefault();
    card.querySelector('[data-library-action="open"]')?.click();
    return;
  }
  if (!["ArrowDown", "ArrowUp", "ArrowLeft", "ArrowRight", "Home", "End"]
    .includes(event.key)) return;
  event.preventDefault();
  const focused = globalThis.T9DocumentBatchOperations.focus(
    documentLibrarySelection, visibleIds, event.key
  );
  documentLibrarySelection = event.shiftKey
    ? globalThis.T9DocumentBatchOperations.select(
      documentLibrarySelection, visibleIds, focused.activeId, { shift: true }
    )
    : focused;
  renderDocumentLibrarySelection();
  $("libraryResults").querySelector(
    `[data-library-project-id="${CSS.escape(documentLibrarySelection.activeId)}"]`
  )?.focus();
});
$("libraryBatchSelectAll").addEventListener("click", () => {
  const matches = globalThis.T9DocumentLibrary.query(
    documentLibraryIndex, libraryOptions()
  );
  documentLibrarySelection = globalThis.T9DocumentBatchOperations.selectAll(
    documentLibrarySelection, matches.map(record => record.projectId)
  );
  renderDocumentLibrarySelection();
  renderLibraryBatchToolbar(`${matches.length} dokument valdes.`);
});
$("libraryBatchClear").addEventListener("click", () => {
  documentLibrarySelection = globalThis.T9DocumentBatchOperations.clear();
  renderDocumentLibrarySelection();
  $("librarySearch").focus();
  $("libraryBatchStatus").textContent = "Dokumentvalet rensades.";
});
$("libraryBatchExport").addEventListener("click", async () => {
  const records = selectedLibraryRecords();
  if (!records.length || !confirm(
    `Exportera ${records.length} dokument till separata Word-filer? ` +
    "Dokumenten ändras inte. Välj Avbryt för att stoppa innan exporten startar."
  )) return;
  const progress = $("libraryBatchProgress");
  const controls = [...$("libraryBatchToolbar").querySelectorAll("button")];
  progress.hidden = false;
  progress.max = records.length;
  progress.value = 0;
  $("libraryBatchToolbar").setAttribute("aria-busy", "true");
  controls.forEach(button => { button.disabled = true; });
  let exported = 0;
  try {
    const settingsResponse = await send({ type: "T9_GET_SETTINGS" });
    const exportSettings = { ...DEFAULTS,
      ...(settingsResponse?.settings || {}) };
    const recordsById = new Map(records.map(record =>
      [record.projectId, record]
    ));
    const plan = globalThis.T9DocumentBatchOperations.exportPlan(
      documentLibraryRecords, documentLibrarySelection
    );
    const result = await globalThis.T9DocumentBatchOperations.execute(
      plan,
      projectId => exportLibraryDocument(recordsById.get(projectId),
        exportSettings),
      { onProgress(value) {
        const record = recordsById.get(value.projectId);
        if (value.phase === "starting") {
          $("libraryBatchStatus").textContent =
            `Exporterar ${value.completed + 1} av ${value.total}: ${record.title}.`;
        } else {
          exported = value.completed;
          progress.value = exported;
        }
      } }
    );
    exported = result.completed;
    $("libraryBatchStatus").textContent =
      `✓ ${exported} dokument exporterades.`;
  } catch (error) {
    exported = Number.isInteger(error.completed) ? error.completed : exported;
    show(`${error.message} ${exported} dokument exporterades innan felet.`, true);
    $("libraryBatchStatus").textContent =
      `Exporten avbröts efter ${exported} av ${records.length} dokument.`;
  } finally {
    controls.forEach(button => { button.disabled = false; });
    progress.hidden = true;
    $("libraryBatchToolbar").setAttribute("aria-busy", "false");
  }
});
$("libraryBatchFavourite").addEventListener("click", async () => {
  try {
    const result = globalThis.T9DocumentBatchOperations.favourite(
      documentLibraryRecords, documentLibrarySelection, true
    );
    await commitLibraryBatch(result, "✓ {count} dokument favoritmarkerades.");
  } catch (error) {
    show(error.message, true);
  }
});
for (const [id, mode] of [["libraryBatchTags", "tags"],
  ["libraryBatchProfile", "profile"], ["libraryBatchTheme", "theme"],
  ["libraryBatchMetadata", "metadata"]]) {
  $(id).addEventListener("click", () => openBatchMetadataDialog(mode));
}
$("libraryBatchMetadataDialog").addEventListener("close", async event => {
  if (event.target.returnValue !== "apply") return;
  try {
    const result = globalThis.T9DocumentBatchOperations.apply(
      documentLibraryRecords, documentLibrarySelection,
      batchMetadataOperation()
    );
    await commitLibraryBatch(result, "✓ Metadata uppdaterades för {count} dokument.");
  } catch (error) {
    show(error.message, true);
  }
});
$("libraryBatchArchive").addEventListener("click", async () => {
  const count = documentLibrarySelection.selectedIds.length;
  if (!confirm(`Arkivera ${count} dokument? Åtgärden ändrar endast metadata ` +
      "och kan återställas via metadataredigering.")) return;
  try {
    const result = globalThis.T9DocumentBatchOperations.apply(
      documentLibraryRecords, documentLibrarySelection, { type: "archive",
        fields: { archived: { selected: true, value: true } } }
    );
    await commitLibraryBatch(result, "✓ {count} dokument arkiverades.");
  } catch (error) {
    show(error.message, true);
  }
});
$("libraryBatchDelete").addEventListener("click", async () => {
  const count = documentLibrarySelection.selectedIds.length;
  if (!confirm(`Ta bort ${count} dokument och tillhörande sessioner permanent? ` +
      "Åtgärden kan inte ångras.")) return;
  const plan = globalThis.T9DocumentBatchOperations.remove(
    documentLibraryRecords, documentLibrarySelection
  );
  let deleted = 0;
  try {
    for (const projectId of plan.projectIds) {
      const response = await send({ type: "T9_DELETE_SESSION",
        sessionId: projectId });
      if (!response?.ok) throw new Error(
        response?.error || "Ett dokument kunde inte tas bort."
      );
      deleted += 1;
    }
    documentLibrarySelection = globalThis.T9DocumentBatchOperations.clear();
    await loadSessions();
    $("libraryBatchStatus").textContent = `✓ ${deleted} dokument togs bort.`;
  } catch (error) {
    await loadSessions();
    show(`${error.message} ${deleted} dokument hann tas bort.`, true);
  }
});
$("exportFileNamePattern").addEventListener("input", updateFilenamePreview);
$("environmentName").addEventListener("input", updateFilenamePreview);
$("companyName").addEventListener("input", updateFilenamePreview);
document.addEventListener("keydown", event => {
  if (event.key !== "/" || event.ctrlKey || event.metaKey || event.altKey ||
      $("reviewOverlay").classList.contains("open") ||
      document.querySelector("dialog[open]") ||
      event.target.closest?.("input, textarea, select, [contenteditable=true]")) {
    return;
  }
  event.preventDefault();
  $("librarySearch").focus();
  $("librarySearch").select();
});


async function initializeDashboard() {
  initializeFilenameVariables();
  populateBatchMetadataOptions();
  try {
    await loadSettings();
  } catch (error) {
    console.error("BC Process Studio loadSettings failed", error);

    // Keep the UI usable even if stored settings cannot be read.
    for (const [key, value] of Object.entries(DEFAULTS)) {
      const element = $(key);
      if (!element) continue;

      if (typeof value === "boolean") {
        element.checked = value;
      } else {
        element.value = value;
      }
    }

    const documentationProfile = $("documentationProfile");
    if (documentationProfile) {
      documentationProfile.value = DEFAULTS.documentationProfile || "generic";
    }
    applyProfile(documentationProfile?.value ||
      DEFAULTS.documentationProfile || "generic", false);
    updateFilenamePreview();
    show(
      "Inställningarna kunde inte läsas. Standardvärden visas.",
      true
    );
  }

  let sessionsLoaded = false;
  try {
    await loadSessions();
    sessionsLoaded = true;
  } catch (error) {
    console.error("BC Process Studio loadSessions failed", error);
    show(
      uiT("Saved recordings could not be loaded. Reload the page and try again."),
      true
    );
  }
  if (sessionsLoaded) {
    try {
      await openRequestedReview();
    } catch (error) {
      console.error("BC Process Studio openRequestedReview failed", error);
      show(uiT("Den begärda dokumentationen kunde inte öppnas."), true);
    }
  }
}

initializeDashboard();
